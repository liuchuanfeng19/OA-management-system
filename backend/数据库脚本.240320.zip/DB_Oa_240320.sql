/*
SQLyog Professional v13.1.1 (64 bit)
MySQL - 8.0.34 : Database - DB_OA
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`DB_OA` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `DB_OA`;

/*Table structure for table `tb_apply_applybusi` */

DROP TABLE IF EXISTS `tb_apply_applybusi`;

CREATE TABLE `tb_apply_applybusi` (
  `ApplyBusiId` char(36) NOT NULL COMMENT '主键ID',
  `ApplyId` char(36) DEFAULT NULL,
  `ApplyFormName` varchar(32) DEFAULT NULL,
  `StaffId` char(36) DEFAULT NULL,
  `StaffName` varchar(32) DEFAULT NULL,
  `Mobile` varchar(32) DEFAULT NULL,
  `CompanyId` char(36) DEFAULT NULL COMMENT '公司ID',
  `CompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称',
  `DeptId` char(36) DEFAULT NULL COMMENT '申请人部门ID',
  `DeptName` varchar(32) DEFAULT NULL,
  `ApplyReason` varchar(100) DEFAULT NULL,
  `CancelReason` varchar(100) DEFAULT NULL,
  `ApplyTime` datetime DEFAULT NULL,
  `ApplyDate` datetime DEFAULT NULL COMMENT '申请日期',
  `ApplyStatus` int DEFAULT NULL,
  `ApprovedTime` datetime DEFAULT NULL COMMENT '最终审核通过时间',
  `CurApplyNodeId` varchar(50) DEFAULT NULL,
  `CurMyApplyNodeId` varchar(50) DEFAULT NULL COMMENT '下一个审核人节点(自定义)',
  `CurReviewers` varchar(2000) DEFAULT NULL COMMENT '当前审核人(审核人ID组、审核人角色组)',
  `CurRoles` varchar(2000) DEFAULT NULL COMMENT '当前审核人(审核人角色code组)',
  `HReviewerIds` varchar(2000) DEFAULT NULL COMMENT '历史痕迹审核人Id组',
  `HCcIds` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `HCcIds2` varchar(2500) DEFAULT NULL COMMENT '抄送人2(由英文点号分隔)',
  `ReviewerIdsEx` varchar(2000) DEFAULT NULL COMMENT '扩展审核人Id组',
  `PredictReviewersJson` varchar(4000) DEFAULT NULL COMMENT '预测审核人',
  `ReviewerIdsExIndex` int DEFAULT NULL COMMENT '扩展审核人Json(索引)',
  `CanTemp` bit(1) DEFAULT NULL,
  `CanApprove` bit(1) DEFAULT NULL COMMENT '是否可以审核',
  `CanReject` bit(1) DEFAULT NULL COMMENT '是否可以驳回（驳回之后流程结束）',
  `CanCancel` bit(1) DEFAULT NULL COMMENT '是否可以取消（针对发起人）',
  `CanReturnBack` bit(1) DEFAULT NULL COMMENT '是否可以退回（由审批人退回）（退回后仍然可以继续提交申请）',
  `CanEdit` bit(1) DEFAULT NULL COMMENT '能不能编辑',
  `CanDel` bit(1) DEFAULT NULL COMMENT '能不能删除',
  `CurStaffNoticeId` varchar(2000) DEFAULT NULL COMMENT '当前指向的通知ID组',
  `CurReqNoticeId` char(36) DEFAULT NULL COMMENT '当前指向的工作待办通知ID(针对申请人)(一对一)',
  `MsgTitle` varchar(50) DEFAULT NULL COMMENT '消息标题',
  `MsgJsonContent` varchar(2000) DEFAULT NULL COMMENT '消息Json内容',
  `BusiType` varchar(32) DEFAULT NULL COMMENT '业务类型',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `AbIsConfirm` bit(1) DEFAULT NULL COMMENT '特殊字段：0-正常 1-代表流程审批通过',
  `AbReqAutoPass` bit(1) DEFAULT NULL COMMENT '审核节点（申请人自己）是否自动审核通过',
  `MenuId` char(36) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`ApplyBusiId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='审核业务主表V2';

/*Table structure for table `tb_apply_applybusidetail` */

DROP TABLE IF EXISTS `tb_apply_applybusidetail`;

CREATE TABLE `tb_apply_applybusidetail` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ApplyBusiId` char(36) DEFAULT NULL COMMENT '主表Id',
  `ReviewerId` char(36) DEFAULT NULL COMMENT '审批人Id',
  `ReviewerName` varchar(32) DEFAULT NULL COMMENT '审批人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `IsApproved` bit(1) DEFAULT NULL COMMENT '是否同意',
  `ApproveTime` datetime DEFAULT NULL COMMENT '同意/不同意时间',
  `Comment` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsReturnBack` bit(1) DEFAULT NULL,
  `NodeName` varchar(32) DEFAULT NULL COMMENT '节点名称',
  `ApplyNodeId` varchar(50) DEFAULT NULL COMMENT '审核人节点ID',
  `MyApplyNodeId` varchar(50) DEFAULT NULL COMMENT '审核人节点ID(自定义)',
  `SortOrder` int DEFAULT NULL COMMENT '序号',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_apply_applyconfig` */

DROP TABLE IF EXISTS `tb_apply_applyconfig`;

CREATE TABLE `tb_apply_applyconfig` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(32) DEFAULT NULL,
  `Code` varchar(32) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='审批流程配置(主表)';

/*Table structure for table `tb_apply_applyconfigitem` */

DROP TABLE IF EXISTS `tb_apply_applyconfigitem`;

CREATE TABLE `tb_apply_applyconfigitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ApplyConfigId` char(36) DEFAULT NULL,
  `SortOrder` int DEFAULT NULL,
  `Type` int DEFAULT NULL COMMENT '1-指定某个人审批 2-指定某个角色审批 3-指定部门主管审批',
  `TypeValue` varchar(2000) DEFAULT NULL,
  `CanTemp` bit(1) DEFAULT NULL,
  `CanApprove` bit(1) DEFAULT NULL COMMENT '是否可以审核',
  `CanReject` bit(1) DEFAULT NULL COMMENT '是否可以驳回（驳回之后流程结束）',
  `CanCancel` bit(1) DEFAULT NULL COMMENT '是否可以取消（针对发起人）',
  `CanReturnBack` bit(1) DEFAULT NULL COMMENT '是否可以退回（由审批人退回）（退回后仍然可以继续提交申请）',
  `ReturnBackItemId` char(36) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='审批流程配置(字表)';

/*Table structure for table `tb_apply_applyconfigitemrel` */

DROP TABLE IF EXISTS `tb_apply_applyconfigitemrel`;

CREATE TABLE `tb_apply_applyconfigitemrel` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `PrevId` char(36) DEFAULT NULL,
  `NextId` char(36) DEFAULT NULL,
  `TrueOrFalse` bit(1) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `TB_Apply_ApplyForm` */

DROP TABLE IF EXISTS `TB_Apply_ApplyForm`;

CREATE TABLE `TB_Apply_ApplyForm` (
  `FormId` char(36) NOT NULL COMMENT '主键ID',
  `FormName` varchar(100) DEFAULT NULL,
  `FormCode` varchar(100) DEFAULT NULL COMMENT '表单编号',
  `Logo` varchar(1000) DEFAULT NULL,
  `Settings` varchar(1000) DEFAULT NULL,
  `GroupId` char(36) DEFAULT NULL,
  `FormItems` text,
  `Process` text,
  `IsStop` bit(1) DEFAULT NULL,
  `Sort` int DEFAULT NULL,
  `CcIds` varchar(1000) DEFAULT NULL COMMENT '抄送人Id数组',
  `Remark` varchar(1000) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  `ApplyMenuId` char(36) DEFAULT NULL COMMENT '申请菜单',
  `AuditMenuId` char(36) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '审核菜单',
  PRIMARY KEY (`FormId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_apply_applygroup` */

DROP TABLE IF EXISTS `tb_apply_applygroup`;

CREATE TABLE `tb_apply_applygroup` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(100) DEFAULT NULL,
  `Sort` int DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_assets_assets` */

DROP TABLE IF EXISTS `tb_assets_assets`;

CREATE TABLE `tb_assets_assets` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Code` varchar(32) DEFAULT NULL,
  `Name` varchar(32) DEFAULT NULL,
  `ParentCatId` char(36) DEFAULT NULL COMMENT '父分类ID',
  `CatId` char(36) DEFAULT NULL,
  `CatType` int DEFAULT NULL,
  `BuyTime` datetime DEFAULT NULL,
  `Price` decimal(11,2) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `Amount` decimal(11,2) DEFAULT NULL,
  `ApplyQty` int DEFAULT NULL,
  `UsedQty` int DEFAULT NULL,
  `DutyStaffId` char(36) DEFAULT NULL,
  `StoreAddress` varchar(100) DEFAULT NULL,
  `StoreInTime` datetime DEFAULT NULL,
  `SpecExpr` varchar(100) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Img` varchar(4096) DEFAULT NULL COMMENT '图片',
  `UserId` char(36) DEFAULT NULL,
  `UserName` varchar(32) DEFAULT NULL,
  `UserDepart` varchar(32) DEFAULT NULL,
  `UserTime` datetime DEFAULT NULL,
  `IsNeedReturn` bit(1) DEFAULT NULL,
  `BrokenComment` varchar(200) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_assets_assetsapply` */

DROP TABLE IF EXISTS `tb_assets_assetsapply`;

CREATE TABLE `tb_assets_assetsapply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL COMMENT '1-固定资产 2-低值易耗品',
  `AssetsId` char(36) DEFAULT NULL,
  `Reason` varchar(100) DEFAULT NULL,
  `CancelReason` char(10) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `Comment` varchar(100) DEFAULT NULL,
  `CcIds` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `ApplyTime` datetime DEFAULT NULL,
  `ApplyStatus` int DEFAULT NULL,
  `CurrentReviewerId` char(36) DEFAULT NULL,
  `CurrentReviewerIds` varchar(200) DEFAULT NULL,
  `ReviewerIds` varchar(200) DEFAULT NULL,
  `HReviewerIds` varchar(200) DEFAULT NULL COMMENT '历史痕迹审核人',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_assets_assetsapplydetail` */

DROP TABLE IF EXISTS `tb_assets_assetsapplydetail`;

CREATE TABLE `tb_assets_assetsapplydetail` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AssetsApplyId` char(36) NOT NULL COMMENT '请假表Id',
  `ReviewerId` char(36) NOT NULL COMMENT '审批人Id',
  `ReviewerName` varchar(32) DEFAULT NULL COMMENT '审批人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `IsApproved` bit(1) DEFAULT NULL COMMENT '是否同意',
  `ApproveTime` datetime DEFAULT NULL COMMENT '同意/不同意时间',
  `Comment` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_assets_assetscat` */

DROP TABLE IF EXISTS `tb_assets_assetscat`;

CREATE TABLE `tb_assets_assetscat` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ParentId` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(32) DEFAULT NULL,
  `SeqId` int DEFAULT NULL,
  `Path` varchar(400) DEFAULT NULL,
  `CatType` int DEFAULT NULL COMMENT '1-固定资产 2-低值易耗品',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_assets_assetsflow` */

DROP TABLE IF EXISTS `tb_assets_assetsflow`;

CREATE TABLE `tb_assets_assetsflow` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL COMMENT '主键ID',
  `StaffName` varchar(32) DEFAULT NULL,
  `AssetsId` char(36) DEFAULT NULL,
  `AssetsName` varchar(32) DEFAULT NULL,
  `UserTime` datetime DEFAULT NULL,
  `ReturnTime` datetime DEFAULT NULL,
  `ApplyTime` datetime DEFAULT NULL,
  `MyAssetsId` char(36) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='资产流转记录';

/*Table structure for table `tb_assets_buyassetsapply` */

DROP TABLE IF EXISTS `tb_assets_buyassetsapply`;

CREATE TABLE `tb_assets_buyassetsapply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AyStaffId` char(36) DEFAULT NULL COMMENT '申请人ID',
  `AyStaffName` varchar(32) DEFAULT NULL COMMENT '申请人',
  `AyDeptId` char(36) DEFAULT NULL COMMENT '申请部门ID',
  `AyDeptName` varchar(32) DEFAULT NULL COMMENT '申请部门',
  `AyTime` datetime DEFAULT NULL COMMENT '申请日期',
  `AyType` int DEFAULT NULL COMMENT '类型 1-计算机 2-办公用品',
  `AyCount` int DEFAULT NULL COMMENT '项数',
  `AyAmount` decimal(11,2) DEFAULT NULL COMMENT '合计',
  `AyAmountCHN` varchar(50) DEFAULT NULL COMMENT '合计(大写)',
  `InStockState` int DEFAULT NULL COMMENT '入库状态 1-未入库 2-已入库',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='资产采购申请（主表）';

/*Table structure for table `tb_assets_buyassetsapplyitem` */

DROP TABLE IF EXISTS `tb_assets_buyassetsapplyitem`;

CREATE TABLE `tb_assets_buyassetsapplyitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BuyAssetsApplyId` char(36) DEFAULT NULL COMMENT '主表ID',
  `InnerSeq` int DEFAULT NULL COMMENT '内部序号',
  `AssetsName` varchar(100) DEFAULT NULL COMMENT '物品名称',
  `Qty` int DEFAULT NULL COMMENT '数量',
  `AssetsSpec` varchar(256) DEFAULT NULL COMMENT '规格型号及技术指标',
  `AssetsUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `Amount` decimal(11,2) DEFAULT NULL COMMENT '金额',
  `JsonData` varchar(2048) DEFAULT NULL COMMENT '自定义json字段',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='资产采购申请(明细表)';

/*Table structure for table `tb_assets_computer` */

DROP TABLE IF EXISTS `tb_assets_computer`;

CREATE TABLE `tb_assets_computer` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BelongCompanyId` char(36) DEFAULT NULL COMMENT '归属公司ID',
  `BelongCompanyName` varchar(100) DEFAULT NULL COMMENT '归属公司名称',
  `State` int DEFAULT NULL COMMENT '状态 1-可领用申请 2-领用申请中 3-已领用',
  `Name` varchar(100) DEFAULT NULL COMMENT '设备名称',
  `Code` varchar(100) DEFAULT NULL COMMENT '设备编号',
  `Brand` varchar(100) DEFAULT NULL COMMENT '设备品牌',
  `Spec` varchar(100) DEFAULT NULL COMMENT '型号',
  `DeviceType` varchar(100) DEFAULT NULL COMMENT '类型',
  `Box` varchar(100) DEFAULT NULL COMMENT '机箱',
  `Board` varchar(100) DEFAULT NULL COMMENT '主板',
  `Memory` varchar(100) DEFAULT NULL COMMENT '内存',
  `HardDisk` varchar(100) DEFAULT NULL COMMENT '硬盘',
  `Screen` varchar(100) DEFAULT NULL COMMENT '显示器',
  `Keyboard` varchar(100) DEFAULT NULL COMMENT '键盘',
  `Mouse` varchar(100) DEFAULT NULL COMMENT '鼠标',
  `Mac` varchar(100) DEFAULT NULL COMMENT 'MAC地址',
  `CurCollectStaffName` varchar(32) DEFAULT NULL COMMENT '当前领用人',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='计算机资产';

/*Table structure for table `tb_assets_computercollect` */

DROP TABLE IF EXISTS `tb_assets_computercollect`;

CREATE TABLE `tb_assets_computercollect` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ComputerId` char(36) DEFAULT NULL COMMENT '计算机ID',
  `CollectTime` datetime DEFAULT NULL COMMENT '领用日期',
  `CollectDeptId` char(36) DEFAULT NULL COMMENT '领用部门ID',
  `CollectDeptName` varchar(32) DEFAULT NULL COMMENT '领用部门',
  `CollectStaffId` char(36) DEFAULT NULL COMMENT '领用人ID',
  `CollectStaffName` varchar(32) DEFAULT NULL COMMENT '领用人',
  `CollectPlace` varchar(100) DEFAULT NULL COMMENT '存放位置(领用)',
  `CollectDeptStaffId` char(36) DEFAULT NULL COMMENT '领用部门主管ID',
  `CollectDeptStaffName` varchar(32) DEFAULT NULL COMMENT '领用部门主管',
  `CollectAdminStaffId` char(36) DEFAULT NULL,
  `CollectAdminStaffName` varchar(32) DEFAULT NULL,
  `State` int DEFAULT NULL COMMENT '状态 1-已领用 2-已归还',
  `ReturnTime` datetime DEFAULT NULL COMMENT '交还日期',
  `ReturnDeptId` char(36) DEFAULT NULL COMMENT '交还部门ID',
  `ReturnDeptName` varchar(32) DEFAULT NULL COMMENT '交还部门',
  `ReturnStaffId` char(36) DEFAULT NULL COMMENT '交还人ID',
  `ReturnStaffName` varchar(32) DEFAULT NULL COMMENT '交还人',
  `ReturnDeptStaffId` char(36) DEFAULT NULL COMMENT '交换人部门主管ID',
  `ReturnDeptStaffName` varchar(32) DEFAULT NULL COMMENT '交换人部门主管',
  `ReturnAdminStaffId` char(36) DEFAULT NULL,
  `ReturnAdminStaffName` varchar(32) DEFAULT NULL,
  `ReturnPlace` varchar(100) DEFAULT NULL COMMENT '存放位置(交还)',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='领用计算机';

/*Table structure for table `tb_assets_computerpart` */

DROP TABLE IF EXISTS `tb_assets_computerpart`;

CREATE TABLE `tb_assets_computerpart` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ComputerId` char(36) NOT NULL COMMENT '计算机ID',
  `PartName` varchar(100) DEFAULT NULL COMMENT '配件名称',
  `ReplaceReason` varchar(100) DEFAULT NULL COMMENT '更换原因',
  `ReplaceTime` datetime DEFAULT NULL COMMENT '更换时间',
  `AdminStaffId` char(36) DEFAULT NULL COMMENT '管理员ID',
  `AdminStaffName` varchar(32) DEFAULT NULL COMMENT '管理员',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='计算机配件';

/*Table structure for table `tb_assets_myassets` */

DROP TABLE IF EXISTS `tb_assets_myassets`;

CREATE TABLE `tb_assets_myassets` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL,
  `StaffName` varchar(32) DEFAULT NULL,
  `DeptId` char(36) DEFAULT NULL,
  `DeptName` varchar(32) DEFAULT NULL,
  `AssetsId` char(36) DEFAULT NULL,
  `Price` decimal(11,2) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `Amount` decimal(11,2) DEFAULT NULL,
  `SpecExpr` varchar(32) DEFAULT NULL,
  `UserTime` datetime DEFAULT NULL,
  `IsNeedReturn` bit(1) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_assets_officeassets` */

DROP TABLE IF EXISTS `tb_assets_officeassets`;

CREATE TABLE `tb_assets_officeassets` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AssetsName` varchar(100) DEFAULT NULL COMMENT '物品名称',
  `AssetsCode` varchar(100) DEFAULT NULL COMMENT '设备编号',
  `AssetsSpec` varchar(256) DEFAULT NULL COMMENT '型号/参数',
  `AssetsValue` varchar(256) DEFAULT NULL COMMENT '价值',
  `AyStaffId` char(36) DEFAULT NULL COMMENT '领用人ID',
  `AyStaffName` varchar(32) DEFAULT NULL COMMENT '领用人',
  `AyDeptId` char(36) DEFAULT NULL COMMENT '领用部门ID',
  `AyDeptName` varchar(32) DEFAULT NULL COMMENT '领用部门',
  `AyTime` datetime DEFAULT NULL COMMENT '领用日期',
  `AyReturnTime` datetime DEFAULT NULL COMMENT '交还日期',
  `AyPlace` varchar(128) DEFAULT NULL COMMENT '存放位置',
  `AdminStaffId` char(36) DEFAULT NULL COMMENT '管理员ID',
  `AdminStaffName` varchar(32) DEFAULT NULL COMMENT '管理员',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='办公用品';

/*Table structure for table `tb_assets_officeobject` */

DROP TABLE IF EXISTS `tb_assets_officeobject`;

CREATE TABLE `tb_assets_officeobject` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AssetsName` varchar(100) DEFAULT NULL COMMENT '物品名称',
  `AssetsCode` varchar(100) DEFAULT NULL COMMENT '编号',
  `Qty` int DEFAULT NULL COMMENT '数量',
  `UsedQty` int DEFAULT NULL COMMENT '使用数量',
  `AssetsSpec` varchar(256) DEFAULT NULL COMMENT '规格型号及技术指标',
  `AssetsUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `Amount` decimal(11,2) DEFAULT NULL COMMENT '金额',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='办公用品日志';

/*Table structure for table `tb_assets_officestuff` */

DROP TABLE IF EXISTS `tb_assets_officestuff`;

CREATE TABLE `tb_assets_officestuff` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `OfficeObjectId` char(36) DEFAULT NULL COMMENT '办公设备ID',
  `AssetsName` varchar(100) DEFAULT NULL COMMENT '设备名称',
  `AssetsCode` varchar(100) DEFAULT NULL COMMENT '设备编号',
  `AssetsSpec` varchar(256) DEFAULT NULL COMMENT '型号/参数',
  `AssetsValue` varchar(256) DEFAULT NULL COMMENT '价值',
  `Qty` int DEFAULT NULL COMMENT '数量',
  `State` int DEFAULT NULL COMMENT '状态 1-已领用 2-已归还',
  `AyStaffId` char(36) DEFAULT NULL COMMENT '领用人ID',
  `AyStaffName` varchar(32) DEFAULT NULL COMMENT '领用人',
  `AyDeptId` char(36) DEFAULT NULL COMMENT '领用部门ID',
  `AyDeptName` varchar(32) DEFAULT NULL COMMENT '领用部门',
  `AyTime` datetime DEFAULT NULL COMMENT '领用日期',
  `AyReturnTime` datetime DEFAULT NULL COMMENT '交还日期',
  `AyPlace` varchar(128) DEFAULT NULL COMMENT '存放位置',
  `AdminStaffId` char(36) DEFAULT NULL COMMENT '管理员ID',
  `AdminStaffName` varchar(32) DEFAULT NULL COMMENT '管理员',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='办公用品（登记）';

/*Table structure for table `tb_basic_basiccity` */

DROP TABLE IF EXISTS `tb_basic_basiccity`;

CREATE TABLE `tb_basic_basiccity` (
  `CityName` varchar(50) NOT NULL,
  `ProvinceName` varchar(50) NOT NULL,
  `SortOrder` int NOT NULL,
  PRIMARY KEY (`CityName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_basic_basicprovince` */

DROP TABLE IF EXISTS `tb_basic_basicprovince`;

CREATE TABLE `tb_basic_basicprovince` (
  `ProvinceName` varchar(50) NOT NULL,
  `SortOrder` int NOT NULL,
  PRIMARY KEY (`ProvinceName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_borrow_sealborrow` */

DROP TABLE IF EXISTS `tb_borrow_sealborrow`;

CREATE TABLE `tb_borrow_sealborrow` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Company` varchar(56) DEFAULT NULL COMMENT '公司/单位',
  `SealType` varchar(24) DEFAULT NULL COMMENT '用章类型',
  `Purpose` varchar(256) DEFAULT NULL COMMENT '用途',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `Status` int DEFAULT NULL COMMENT '领用/归还状态 1 待领用 2 待归还 3 已归还',
  `UseTime` datetime DEFAULT NULL COMMENT '领用时间',
  `ReturnTime` datetime DEFAULT NULL COMMENT '归还时间',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='印章借阅';

/*Table structure for table `tb_build_buildboss` */

DROP TABLE IF EXISTS `tb_build_buildboss`;

CREATE TABLE `tb_build_buildboss` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(32) DEFAULT NULL,
  `IdCard` varchar(32) DEFAULT NULL,
  `Mobile` varchar(32) DEFAULT NULL,
  `IdCardFront` varchar(300) DEFAULT NULL,
  `IdCardBack` varchar(300) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='房东';

/*Table structure for table `tb_build_builds` */

DROP TABLE IF EXISTS `tb_build_builds`;

CREATE TABLE `tb_build_builds` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(32) DEFAULT NULL COMMENT '房屋名称',
  `Description` varchar(200) DEFAULT NULL COMMENT '描述',
  `Address` varchar(32) DEFAULT NULL COMMENT '地址',
  `Area` decimal(11,2) DEFAULT NULL COMMENT '面积',
  `AddTime` datetime DEFAULT NULL COMMENT '添加时间',
  `Type` int DEFAULT NULL COMMENT '房屋来源  1-自有  2-租赁',
  `DutyStaffId` char(36) DEFAULT NULL COMMENT '房屋经手人ID',
  `DutyStaffMobile` varchar(32) DEFAULT NULL COMMENT '房屋经手人电话',
  `BuildBossId` char(36) DEFAULT NULL COMMENT '房东ID',
  `BossName` varchar(32) DEFAULT NULL,
  `BossMobile` varchar(32) DEFAULT NULL,
  `BossIdCardFront` varchar(300) DEFAULT NULL,
  `BossIdCardBack` varchar(300) DEFAULT NULL,
  `Amount` decimal(11,2) DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `Img` varchar(300) DEFAULT NULL,
  `BuildsImg` varchar(300) DEFAULT NULL,
  `Status` int DEFAULT NULL COMMENT '状态 1-闲置   2-已租出',
  `LeaseType` int DEFAULT NULL COMMENT '租赁方式  1-整租  2-散租',
  `RoomQty` int DEFAULT NULL,
  `UsedRoomQty` int DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='房屋';

/*Table structure for table `TB_Build_BuildsLease` */

DROP TABLE IF EXISTS `TB_Build_BuildsLease`;

CREATE TABLE `TB_Build_BuildsLease` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL,
  `StaffName` varchar(32) DEFAULT NULL,
  `DeptId` char(36) DEFAULT NULL,
  `DeptName` varchar(32) DEFAULT NULL,
  `Mobile` varchar(32) DEFAULT NULL,
  `IdCard` varchar(32) DEFAULT NULL,
  `IdCardFront` varchar(300) DEFAULT NULL,
  `IdCardBack` varchar(300) DEFAULT NULL,
  `BuildsId` char(36) DEFAULT NULL,
  `BuildsName` varchar(32) DEFAULT NULL,
  `RoomId` char(36) DEFAULT NULL,
  `RoomName` varchar(32) DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `LeaseType` int DEFAULT NULL,
  `AddGoods` varchar(300) DEFAULT NULL,
  `RenterCount` int DEFAULT NULL,
  `RenterMethod` int DEFAULT NULL,
  `RenterAmount` decimal(11,2) DEFAULT NULL,
  `Comment` varchar(200) DEFAULT NULL,
  `CcIds` varchar(500) DEFAULT NULL,
  `IsValid` bit(1) DEFAULT NULL COMMENT '暂时不用该字段',
  `LeaseStatus` int DEFAULT NULL,
  `StopAmount` decimal(11,2) DEFAULT NULL,
  `StopTime` datetime DEFAULT NULL,
  `StopComment` varchar(200) DEFAULT NULL,
  `Attach` varchar(512) DEFAULT NULL COMMENT '附件',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CcRemark` varchar(128) DEFAULT NULL COMMENT '抄送人备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='房屋租赁';

/*Table structure for table `tb_build_buildsnotifyreceiverstate` */

DROP TABLE IF EXISTS `tb_build_buildsnotifyreceiverstate`;

CREATE TABLE `tb_build_buildsnotifyreceiverstate` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ReceiverId` char(36) DEFAULT NULL,
  `BuildsLeaseId` char(36) DEFAULT NULL,
  `BuildsId` char(36) DEFAULT NULL,
  `LastReceiveTime` datetime DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `TB_Build_BuildsNotifySetting` */

DROP TABLE IF EXISTS `TB_Build_BuildsNotifySetting`;

CREATE TABLE `TB_Build_BuildsNotifySetting` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Type` int DEFAULT NULL,
  `AdvancedPeriod` int DEFAULT NULL,
  `NotifyInterval` int DEFAULT NULL,
  `ReceiverIds` text,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CcRemark` varchar(128) DEFAULT NULL COMMENT '抄送人备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='房屋提醒';

/*Table structure for table `tb_build_buildsrenter` */

DROP TABLE IF EXISTS `tb_build_buildsrenter`;

CREATE TABLE `tb_build_buildsrenter` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL,
  `Name` varchar(32) DEFAULT NULL,
  `IdCard` varchar(32) DEFAULT NULL,
  `Mobile` varchar(32) DEFAULT NULL,
  `IdCardFront` varchar(300) DEFAULT NULL,
  `IdCardBack` varchar(300) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='租客';

/*Table structure for table `tb_build_buildsroom` */

DROP TABLE IF EXISTS `tb_build_buildsroom`;

CREATE TABLE `tb_build_buildsroom` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BuildsId` char(36) DEFAULT NULL,
  `Name` varchar(32) DEFAULT NULL,
  `Area` decimal(11,2) DEFAULT NULL,
  `Direction` varchar(32) DEFAULT NULL,
  `Description` varchar(300) DEFAULT NULL,
  `AddGoods` varchar(300) DEFAULT NULL,
  `Img` varchar(300) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='房间';

/*Table structure for table `tb_buy_buyapply` */

DROP TABLE IF EXISTS `tb_buy_buyapply`;

CREATE TABLE `tb_buy_buyapply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL,
  `StaffName` varchar(32) DEFAULT NULL,
  `DeptName` varchar(32) DEFAULT NULL,
  `Mobile` varchar(32) DEFAULT NULL,
  `Code` varchar(32) DEFAULT NULL,
  `BidCompany` varchar(50) DEFAULT NULL,
  `RecvAddress` varchar(200) DEFAULT NULL,
  `TotalQty` int DEFAULT NULL,
  `Attach` text,
  `ApplyReason` varchar(200) DEFAULT NULL,
  `CancelReason` varchar(200) DEFAULT NULL,
  `ApplyStatus` int DEFAULT NULL,
  `ApplyTime` datetime DEFAULT NULL,
  `CurrentReviewerId` char(36) DEFAULT NULL,
  `CurrentReviewerIds` varchar(200) DEFAULT NULL,
  `ReviewerIds` varchar(200) DEFAULT NULL,
  `HReviewerIds` varchar(200) DEFAULT NULL COMMENT '历史痕迹审核人',
  `CurStaffNoticeId` char(36) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='下采单申请';

/*Table structure for table `tb_buy_buyapplydetail` */

DROP TABLE IF EXISTS `tb_buy_buyapplydetail`;

CREATE TABLE `tb_buy_buyapplydetail` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BuyApplyId` char(36) NOT NULL COMMENT '请假表Id',
  `ReviewerId` char(36) NOT NULL COMMENT '审批人Id',
  `ReviewerName` varchar(32) DEFAULT NULL COMMENT '审批人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `IsApproved` bit(1) DEFAULT NULL COMMENT '是否同意',
  `ApproveTime` datetime DEFAULT NULL COMMENT '同意/不同意时间',
  `Comment` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_buy_buyapplyitem` */

DROP TABLE IF EXISTS `tb_buy_buyapplyitem`;

CREATE TABLE `tb_buy_buyapplyitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BuyApplyId` char(36) DEFAULT NULL,
  `DeviceName` varchar(32) DEFAULT NULL,
  `DeviceSpec` varchar(100) DEFAULT NULL,
  `DeviceModel` varchar(100) DEFAULT NULL,
  `DeviceParams` varchar(300) DEFAULT NULL,
  `Unit` varchar(32) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `RecvTime` datetime DEFAULT NULL,
  `Comment` varchar(300) DEFAULT NULL,
  `IsCollect` bit(1) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='下采单申请明细';

/*Table structure for table `tb_buy_buyattach` */

DROP TABLE IF EXISTS `tb_buy_buyattach`;

CREATE TABLE `tb_buy_buyattach` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `JoinSignId` char(36) DEFAULT NULL COMMENT '会签合同ID',
  `AttachContract` text COMMENT '附件合同',
  `AttachInvoice` text COMMENT '附件发票',
  `AttachPay` text COMMENT '附件付款单',
  `AttachRecvSign` text COMMENT '附件到货签收单',
  `AttachCheck` text COMMENT '附件验收单',
  `AttachOther` text COMMENT '附件其他',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购附件';

/*Table structure for table `tb_buy_buycontractapply` */

DROP TABLE IF EXISTS `tb_buy_buycontractapply`;

CREATE TABLE `tb_buy_buycontractapply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(100) DEFAULT NULL,
  `PartA` varchar(100) DEFAULT NULL,
  `PartB` varchar(100) DEFAULT NULL,
  `AContractCode` varchar(50) DEFAULT NULL,
  `BContractCode` varchar(50) DEFAULT NULL,
  `HasTax` bit(1) DEFAULT NULL,
  `Amount` decimal(18,2) DEFAULT NULL,
  `PayMethod` varchar(32) DEFAULT NULL,
  `Address` varchar(800) DEFAULT NULL,
  `BearDeptId` char(36) DEFAULT NULL,
  `BearDeptName` varchar(32) DEFAULT NULL,
  `BearStaffId` char(36) DEFAULT NULL,
  `BearStaffName` varchar(32) DEFAULT NULL,
  `DutyStaffId` char(36) DEFAULT NULL,
  `DutyStaffName` varchar(32) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购合同审批';

/*Table structure for table `tb_buy_buycontractapplyitem` */

DROP TABLE IF EXISTS `tb_buy_buycontractapplyitem`;

CREATE TABLE `tb_buy_buycontractapplyitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BuyContractApplyId` char(36) DEFAULT NULL,
  `BuyApplyItemId` char(36) DEFAULT NULL,
  `DeviceName` varchar(32) DEFAULT NULL,
  `DeviceSpec` varchar(100) DEFAULT NULL,
  `DeviceModel` varchar(100) DEFAULT NULL,
  `DeviceParams` varchar(300) DEFAULT NULL,
  `Unit` varchar(32) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `Price` decimal(18,2) DEFAULT NULL,
  `TaxPrice` decimal(18,2) DEFAULT NULL,
  `Total` decimal(18,2) DEFAULT NULL,
  `TaxTotal` decimal(18,2) DEFAULT NULL,
  `Comment` varchar(300) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购合同审批明细';

/*Table structure for table `tb_buy_buyinstock` */

DROP TABLE IF EXISTS `tb_buy_buyinstock`;

CREATE TABLE `tb_buy_buyinstock` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BuyContractApplyId` char(36) DEFAULT NULL,
  `Code` varchar(50) DEFAULT NULL,
  `Sequence` int DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `Company` varchar(50) DEFAULT NULL,
  `KeepStaffId` char(36) DEFAULT NULL,
  `KeepStaffName` varchar(32) DEFAULT NULL,
  `HandStaffId` char(36) DEFAULT NULL,
  `HandStaffName` varchar(32) DEFAULT NULL,
  `Comment` varchar(300) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购入库';

/*Table structure for table `tb_buy_buyinstockitem` */

DROP TABLE IF EXISTS `tb_buy_buyinstockitem`;

CREATE TABLE `tb_buy_buyinstockitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BuyInStockId` char(36) DEFAULT NULL,
  `BuyContractApplyItemId` char(36) DEFAULT NULL,
  `DeviceName` varchar(32) DEFAULT NULL,
  `DeviceSpec` varchar(100) DEFAULT NULL,
  `DeviceModel` varchar(100) DEFAULT NULL,
  `Unit` varchar(32) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `Price` decimal(18,2) DEFAULT NULL,
  `Total` decimal(18,2) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购入库明细';

/*Table structure for table `tb_buy_buypay` */

DROP TABLE IF EXISTS `tb_buy_buypay`;

CREATE TABLE `tb_buy_buypay` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `PayCompany` varchar(50) DEFAULT NULL COMMENT '付款单位',
  `FeeType` varchar(32) DEFAULT NULL COMMENT '费用类型',
  `PayMethod` varchar(32) DEFAULT NULL COMMENT '付款方式',
  `PayPurpose` varchar(32) DEFAULT NULL COMMENT '付款用途',
  `SupplyId` char(36) DEFAULT NULL COMMENT '供应商ID',
  `SupplyName` varchar(50) DEFAULT NULL COMMENT '收款单位',
  `JoinSignId` char(36) DEFAULT NULL COMMENT '会签合同ID',
  `IsPrePay` tinyint(1) DEFAULT NULL COMMENT '是否预付款',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID（若不是预付款 则填充该字段）',
  `SellContractCode` varchar(50) DEFAULT NULL COMMENT '买方合同编号',
  `SupplyContractCode` varchar(50) DEFAULT NULL COMMENT '卖方合同编号/供应商合同编号',
  `InBank` varchar(100) DEFAULT NULL COMMENT '收款单位开户行',
  `InBankAccount` varchar(50) DEFAULT NULL COMMENT '收款单位银行账户',
  `ProjectName` varchar(50) DEFAULT NULL COMMENT '项目名称',
  `ContractAmount` decimal(18,2) DEFAULT NULL COMMENT '合同金额',
  `PayAmount` decimal(18,2) DEFAULT NULL COMMENT '累计已付金额',
  `PayTime` datetime DEFAULT NULL COMMENT '付款时间',
  `InvoiceType` varchar(32) DEFAULT NULL COMMENT '发票类型',
  `Amount` decimal(18,2) DEFAULT NULL COMMENT '申请金额',
  `AmountCHN` varchar(32) DEFAULT NULL COMMENT '申请金额(大写)',
  `InvoicePayAmount` decimal(18,2) DEFAULT NULL COMMENT '累计发票金额',
  `BusiStaffId` char(36) DEFAULT NULL COMMENT '业务经办人ID',
  `BusiStaffName` varchar(32) DEFAULT NULL COMMENT '业务经办人',
  `BusiDeptId` char(36) DEFAULT NULL COMMENT '所属部门ID',
  `BusiDeptName` varchar(32) DEFAULT NULL COMMENT '所属部门',
  `Attach` text COMMENT '附件(发票)',
  `AttachRecvSign` text COMMENT '附件(签收单)',
  `AttachCheck` text COMMENT '附件(验收单)',
  `AttachPay` text COMMENT '附件(付款单)',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `InnerStatus` int DEFAULT NULL COMMENT '内部状态 0-审批前  1-审批通过',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='付款流程';

/*Table structure for table `tb_buy_buypayproject` */

DROP TABLE IF EXISTS `tb_buy_buypayproject`;

CREATE TABLE `tb_buy_buypayproject` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `JoinSignId` char(36) DEFAULT NULL COMMENT '会签合同ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `BuyPayId` char(36) DEFAULT NULL COMMENT '付款流程ID',
  `Amount` decimal(18,2) DEFAULT NULL COMMENT '付款金额',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='付款流程（每个项目）';

/*Table structure for table `tb_buy_buyrecv` */

DROP TABLE IF EXISTS `tb_buy_buyrecv`;

CREATE TABLE `tb_buy_buyrecv` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BuyContractApplyId` char(36) DEFAULT NULL,
  `BuyContractCode` varchar(80) DEFAULT NULL,
  `RecvCompany` varchar(50) DEFAULT NULL,
  `RecvAddress` varchar(200) DEFAULT NULL,
  `RecvStaffId` char(36) DEFAULT NULL,
  `RecvStaffName` varchar(32) DEFAULT NULL,
  `RecvMobile` varchar(32) DEFAULT NULL,
  `RecvPlanTime` datetime DEFAULT NULL,
  `RecvTime` datetime DEFAULT NULL,
  `SendCompany` varchar(50) DEFAULT NULL,
  `SendAddress` varchar(200) DEFAULT NULL,
  `SendName` varchar(32) DEFAULT NULL,
  `SendMobile` varchar(32) DEFAULT NULL,
  `SendTime` datetime DEFAULT NULL,
  `HandStaffId` char(36) DEFAULT NULL,
  `HandStaffName` varchar(32) DEFAULT NULL,
  `Attach` text,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购收货';

/*Table structure for table `tb_buy_buyrecvaddress` */

DROP TABLE IF EXISTS `tb_buy_buyrecvaddress`;

CREATE TABLE `tb_buy_buyrecvaddress` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL COMMENT '创建人员ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `RecvName` varchar(32) DEFAULT NULL COMMENT '收货人姓名',
  `RecvMobile` varchar(32) DEFAULT NULL COMMENT '收货人联系方式',
  `RecvAddress` varchar(128) DEFAULT NULL COMMENT '收货地址',
  `RecvArea` varchar(128) DEFAULT NULL COMMENT '所在地区',
  `IsDefault` bit(1) DEFAULT NULL COMMENT '是否默认',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购收货地址';

/*Table structure for table `tb_buy_buyrecvitem` */

DROP TABLE IF EXISTS `tb_buy_buyrecvitem`;

CREATE TABLE `tb_buy_buyrecvitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BuyRecvId` char(36) DEFAULT NULL,
  `BuyContractApplyItemId` char(36) DEFAULT NULL,
  `DeviceName` varchar(32) DEFAULT NULL,
  `DeviceSpec` varchar(100) DEFAULT NULL,
  `DeviceModel` varchar(100) DEFAULT NULL,
  `Unit` varchar(32) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `Comment` varchar(300) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购收货明细';

/*Table structure for table `tb_buy_joinsign` */

DROP TABLE IF EXISTS `tb_buy_joinsign`;

CREATE TABLE `tb_buy_joinsign` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ContractType` int DEFAULT NULL COMMENT '合同类型',
  `BusinessType` int DEFAULT NULL COMMENT '业务类型',
  `Title` varchar(4000) DEFAULT NULL COMMENT '合同内容',
  `ContractContent` varchar(4000) DEFAULT NULL COMMENT '合同内容',
  `HasTax` bit(1) DEFAULT NULL COMMENT '是否含税',
  `TaxRate` decimal(18,2) DEFAULT NULL COMMENT '税率',
  `TaxRateStr` varchar(32) DEFAULT NULL COMMENT '税率(字符串)',
  `Qty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `Amount` decimal(11,2) DEFAULT NULL COMMENT '合同价款',
  `AmountCHN` varchar(32) DEFAULT NULL COMMENT '合同价款（大写）',
  `UnTaxAmount` decimal(18,2) DEFAULT NULL COMMENT '未税金额',
  `TaxAmount` decimal(18,2) DEFAULT NULL COMMENT '税金',
  `PayMethod` varchar(32) DEFAULT NULL COMMENT '付款方式',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractCode` varchar(50) DEFAULT NULL COMMENT '买方合同编号',
  `ReBidCompanyId` char(36) DEFAULT NULL COMMENT '投标公司ID/中标公司ID/甲方单位ID',
  `Customer` varchar(50) DEFAULT NULL COMMENT '甲方单位',
  `SupplyId` char(36) DEFAULT NULL COMMENT '乙方单位ID',
  `SupplyName` varchar(50) DEFAULT NULL COMMENT '供应商',
  `SupplyContractCode` varchar(50) DEFAULT NULL COMMENT '卖方合同编号',
  `SupplyContractTime` datetime DEFAULT NULL COMMENT '供应商合同日期',
  `AttachSupplyDoc` varchar(1024) DEFAULT NULL COMMENT '供方资信履历材料',
  `AttachContract` varchar(1024) DEFAULT NULL COMMENT '附件合同资料',
  `WorkAddress` varchar(100) DEFAULT NULL COMMENT '实施地点',
  `DutyBusiStaff` varchar(200) DEFAULT NULL COMMENT '项目商务负责人（逗号分隔）',
  `HandDeptId` char(36) DEFAULT NULL COMMENT '承办部门ID',
  `HandDeptName` varchar(32) DEFAULT NULL COMMENT '承办部门',
  `HandStaffId` char(36) DEFAULT NULL COMMENT '承办人ID',
  `HandStaffName` varchar(32) DEFAULT NULL COMMENT '承办人',
  `Remark` varchar(128) DEFAULT NULL COMMENT '规格型号修改备注',
  `JoinSignRemark` varchar(128) DEFAULT NULL COMMENT '备注',
  `QualityPercent` decimal(11,2) DEFAULT NULL COMMENT '质保比例',
  `QualityTime` datetime DEFAULT NULL COMMENT '质保期',
  `QualityMoneyTime` datetime DEFAULT NULL COMMENT '质保金到期日',
  `UnPayTime` datetime DEFAULT NULL COMMENT '未付款到期日',
  `PayAmount` decimal(18,2) DEFAULT NULL COMMENT '合同已付',
  `UnPayAmount` decimal(18,2) DEFAULT NULL COMMENT '合同未付',
  `InvoiceAmount` decimal(18,2) DEFAULT NULL COMMENT '发票已开',
  `UnInvoiceAmount` decimal(18,2) DEFAULT NULL COMMENT '发票未开',
  `InnerStatus` int DEFAULT NULL COMMENT '内部状态 0-审批前  1-审批通过',
  `JoinSignProjectIds` varchar(2048) DEFAULT NULL COMMENT '项目ID组',
  `OriginAttach` varchar(1024) DEFAULT NULL COMMENT '原始附件',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='会签合同';

/*Table structure for table `tb_buy_joinsignhistoryitem` */

DROP TABLE IF EXISTS `tb_buy_joinsignhistoryitem`;

CREATE TABLE `tb_buy_joinsignhistoryitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectName` varchar(100) DEFAULT NULL COMMENT '项目名称',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `MaterialParams` varchar(4096) DEFAULT NULL COMMENT '参数要求',
  `MaterialPrice` decimal(18,2) DEFAULT NULL COMMENT '采购单价',
  `SubTotal` decimal(18,2) DEFAULT NULL COMMENT '小计',
  `SupplyName` varchar(50) DEFAULT NULL COMMENT '供应商名称',
  `HandStaffName` varchar(32) DEFAULT NULL COMMENT '采购负责人/承办人',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `Seq` int DEFAULT NULL COMMENT '序号',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购历史明细';

/*Table structure for table `tb_buy_joinsignitem` */

DROP TABLE IF EXISTS `tb_buy_joinsignitem`;

CREATE TABLE `tb_buy_joinsignitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `JoinSignId` char(36) DEFAULT NULL COMMENT '会签合同ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractItemId` char(36) DEFAULT NULL COMMENT '销售合同清单明细ID',
  `ReqOrderItemId` char(36) DEFAULT NULL COMMENT '下采单明细ID',
  `MyCollectItemId` char(36) DEFAULT NULL COMMENT '我的代采明细ID',
  `PreInStockQty` decimal(18,4) DEFAULT NULL COMMENT '选择的已入库数量',
  `InStockQty` decimal(18,4) DEFAULT NULL COMMENT '已入库数量',
  `PreRecvSignQty` decimal(18,4) DEFAULT NULL COMMENT '选择的发货数量',
  `RecvSignQty` decimal(18,4) DEFAULT NULL COMMENT '已发货数量',
  `Seq` varchar(32) DEFAULT NULL COMMENT '序号',
  `MaterialType` int DEFAULT NULL COMMENT '物资类型 1-正常 2-配件 3-额外采购',
  `PreId` char(36) DEFAULT NULL COMMENT '购物车明细ID（上一步）',
  `PreParentId` char(36) DEFAULT NULL COMMENT '购物车明细父ID（上一步）',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号（实采）',
  `OldMaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号（下采）',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `MaterialParams` varchar(128) DEFAULT NULL COMMENT '参数要求',
  `MaterialPrice` decimal(18,2) DEFAULT NULL COMMENT '采购单价',
  `MaterialBrand` varchar(100) DEFAULT NULL COMMENT '品牌',
  `SubTotal` decimal(18,2) DEFAULT NULL COMMENT '小计',
  `ReceiveTime` datetime DEFAULT NULL COMMENT '到货日期',
  `ReqOrderItemRemark` varchar(128) DEFAULT NULL COMMENT '下采单明细备注',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购合同物资明细';

/*Table structure for table `tb_buy_joinsignitemsite` */

DROP TABLE IF EXISTS `tb_buy_joinsignitemsite`;

CREATE TABLE `tb_buy_joinsignitemsite` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractItemId` char(36) DEFAULT NULL COMMENT '销售合同清单明细ID（暂时保留）',
  `JoinSignId` char(36) DEFAULT NULL COMMENT '会签ID',
  `JoinSignItemId` char(36) DEFAULT NULL COMMENT '会签明细ID',
  `ReqOrderItemId` char(36) DEFAULT NULL COMMENT '下采单明细ID',
  `SiteId` char(36) DEFAULT NULL COMMENT '站点ID',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `PreRecvSignQty` decimal(18,4) DEFAULT NULL COMMENT '选择的发货数量',
  `RecvSignQty` decimal(18,4) DEFAULT NULL COMMENT '已发货数量',
  `ReceiveTime` datetime DEFAULT NULL COMMENT '到货日期（来自下采）',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='会签明细(分站点数量)';

/*Table structure for table `tb_buy_joinsignproject` */

DROP TABLE IF EXISTS `tb_buy_joinsignproject`;

CREATE TABLE `tb_buy_joinsignproject` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `JoinSignId` char(36) DEFAULT NULL COMMENT '会签合同ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `ContractContent` varchar(4000) DEFAULT NULL COMMENT '合同内容',
  `Amount` decimal(18,2) DEFAULT NULL COMMENT '合同价款/合同金额',
  `UnTaxAmount` decimal(18,2) DEFAULT NULL COMMENT '未税金额',
  `TaxAmount` decimal(18,2) DEFAULT NULL COMMENT '税金',
  `QualityPercent` decimal(11,2) DEFAULT NULL COMMENT '质保比例',
  `QualityTime` datetime DEFAULT NULL COMMENT '质保期',
  `QualityAmount` decimal(18,2) DEFAULT NULL COMMENT '质保金额',
  `PayAmount` decimal(18,2) DEFAULT NULL COMMENT '合同已付',
  `UnPayAmount` decimal(18,2) DEFAULT NULL COMMENT '合同未付',
  `InvoiceAmount` decimal(18,2) DEFAULT NULL COMMENT '发票已开',
  `UnInvoiceAmount` decimal(18,2) DEFAULT NULL COMMENT '发票未开',
  `IsContractReturn` tinyint(1) DEFAULT NULL COMMENT '合同是否返回',
  `IsRecvSignReturn` tinyint(1) DEFAULT NULL COMMENT '签收/验收是否返回',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='会签合同项目关系表';

/*Table structure for table `tb_buy_mycollectitem` */

DROP TABLE IF EXISTS `tb_buy_mycollectitem`;

CREATE TABLE `tb_buy_mycollectitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractItemId` char(36) DEFAULT NULL COMMENT '销售合同清单明细ID',
  `ReqOrderId` char(36) DEFAULT NULL COMMENT '下采订单ID',
  `ReqOrderItemId` char(36) DEFAULT NULL COMMENT '下采订单明细ID',
  `PmStaffId` char(36) DEFAULT NULL COMMENT '项目经理ID(冗余)',
  `PmStaffName` varchar(32) DEFAULT NULL COMMENT '项目经理(冗余)',
  `IsPmAdd` tinyint(1) DEFAULT NULL COMMENT '是否是项目经理增加',
  `Seq` varchar(32) DEFAULT NULL COMMENT '序号',
  `MaterialType` int DEFAULT NULL COMMENT '物资类型 1-正常 2-配件 3-额外采购',
  `PreId` char(36) DEFAULT NULL COMMENT '购物车明细ID（上一步）',
  `PreParentId` char(36) DEFAULT NULL COMMENT '购物车明细父ID（上一步）',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号',
  `OldMaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号（原始）',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `MaterialParams` varchar(128) DEFAULT NULL COMMENT '参数要求',
  `MaterialPrice` decimal(18,2) DEFAULT NULL COMMENT '采购单价',
  `MaterialBrand` varchar(100) DEFAULT NULL COMMENT '品牌',
  `SubTotal` decimal(18,2) DEFAULT NULL COMMENT '小计',
  `ReceiveTime` datetime DEFAULT NULL COMMENT '到货日期',
  `CollectStaffId` char(36) DEFAULT NULL COMMENT '领取人ID（采购专员）',
  `CollectStaffName` varchar(32) DEFAULT NULL COMMENT '领取人（采购专员）',
  `CollectTime` datetime DEFAULT NULL COMMENT '领取时间',
  `IsJoinSign` bit(1) DEFAULT NULL COMMENT '是否已关联采购会签',
  `IsVirtual` tinyint(1) DEFAULT NULL COMMENT '是否虚拟（主商品（且子商品未被全部会签）被会签完后设置成true）',
  `IsFromPre` tinyint(1) DEFAULT NULL COMMENT '是否选自上一步',
  `SiteItemsJson` text COMMENT '分站点数量json',
  `ReqOrderItemRemark` varchar(128) DEFAULT NULL COMMENT '下采单备注',
  `BuyRecvAddressId` char(36) DEFAULT NULL COMMENT '收货地址ID',
  `RecvName` varchar(32) DEFAULT NULL COMMENT '收货人姓名',
  `RecvMobile` varchar(32) DEFAULT NULL COMMENT '收货人联系方式',
  `RecvAddress` varchar(128) DEFAULT NULL COMMENT '收货地址',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='我的待采单';

/*Table structure for table `tb_buy_recvinstock` */

DROP TABLE IF EXISTS `tb_buy_recvinstock`;

CREATE TABLE `tb_buy_recvinstock` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `JoinSignId` char(36) DEFAULT NULL COMMENT '会签合同ID',
  `SupplyId` char(36) DEFAULT NULL COMMENT '供应商ID',
  `SupplyName` varchar(50) DEFAULT NULL COMMENT '供应商',
  `InStockCode` varchar(50) DEFAULT NULL COMMENT '入库单号',
  `RecvName` varchar(32) DEFAULT NULL COMMENT '收货人',
  `RecvMobile` varchar(32) DEFAULT NULL COMMENT '收货人电话',
  `RecvAddress` varchar(200) DEFAULT NULL COMMENT '收货地址',
  `HandStaffId` char(36) DEFAULT NULL COMMENT '经办人ID',
  `HandStaffName` varchar(32) DEFAULT NULL COMMENT '经办人',
  `KeepStaffId` char(36) DEFAULT NULL COMMENT '保管员ID',
  `KeepStaffName` varchar(32) DEFAULT NULL COMMENT '保管员',
  `AuditStaffId` char(36) DEFAULT NULL COMMENT '审核员ID',
  `AuditStaffName` varchar(32) DEFAULT NULL COMMENT '审核员',
  `InStockTime` datetime DEFAULT NULL COMMENT '入库时间',
  `InStockStatus` int DEFAULT NULL COMMENT '入库状态',
  `Attach` varchar(1024) DEFAULT NULL COMMENT '附件',
  `TotalAmount` decimal(18,2) DEFAULT NULL COMMENT '合计金额（未税）',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购收货入库';

/*Table structure for table `tb_buy_recvinstockitem` */

DROP TABLE IF EXISTS `tb_buy_recvinstockitem`;

CREATE TABLE `tb_buy_recvinstockitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractItemId` char(36) DEFAULT NULL COMMENT '销售合同清单明细ID',
  `JoinSignId` char(36) DEFAULT NULL COMMENT '会签合同ID',
  `JoinSignItemId` char(36) DEFAULT NULL COMMENT '会签合同明细ID',
  `RecvInStockId` char(36) DEFAULT NULL COMMENT '采购收货入库ID',
  `Seq` varchar(32) DEFAULT NULL COMMENT '序号',
  `MaterialType` int DEFAULT NULL COMMENT '物资类型 1-正常 2-配件 3-额外采购',
  `PreId` char(36) DEFAULT NULL COMMENT '购物车明细ID（上一步）',
  `PreParentId` char(36) DEFAULT NULL COMMENT '购物车明细父ID（上一步）',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `MaterialParams` varchar(4096) DEFAULT NULL COMMENT '参数要求',
  `MaterialPrice` decimal(18,2) DEFAULT NULL COMMENT '单价(未税)',
  `MaterialPriceNoTax` decimal(18,2) DEFAULT NULL COMMENT '单价(未税)',
  `SubTotal` decimal(18,2) DEFAULT NULL COMMENT '金额/小计',
  `SubTotalNoTax` decimal(18,2) DEFAULT NULL COMMENT '金额/小计(未税)',
  `MaterialState` int DEFAULT NULL COMMENT '货物状态',
  `TaxCategory` varchar(50) DEFAULT NULL COMMENT '税收类别',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  `InTax` decimal(18,2) DEFAULT NULL COMMENT '进项税',
  `PriceTaxTotal` decimal(18,2) DEFAULT NULL COMMENT '价税合计',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购收货入库明细';

/*Table structure for table `tb_buy_recvsign` */

DROP TABLE IF EXISTS `tb_buy_recvsign`;

CREATE TABLE `tb_buy_recvsign` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `JoinSignId` char(36) DEFAULT NULL COMMENT '会签合同ID',
  `SiteId` char(36) DEFAULT NULL COMMENT '站点ID',
  `ReqOrderId` char(36) DEFAULT NULL COMMENT '下采单ID（不可靠，临时顶一下）',
  `SellContractCode` varchar(50) DEFAULT NULL COMMENT '买方合同编号',
  `SupplyContractCode` varchar(50) DEFAULT NULL COMMENT '卖方合同编号',
  `HandStaffId` char(36) DEFAULT NULL COMMENT '采购经办人ID',
  `HandStaffName` varchar(32) DEFAULT NULL COMMENT '采购经办人',
  `RecvCompany` varchar(50) DEFAULT NULL COMMENT '收货单位',
  `RecvStaffId` char(36) DEFAULT NULL COMMENT '收货人ID',
  `RecvName` varchar(32) DEFAULT NULL COMMENT '收货人',
  `RecvMobile` varchar(32) DEFAULT NULL COMMENT '收货人电话',
  `RecvAddress` varchar(200) DEFAULT NULL COMMENT '收货地址',
  `ReceiveTime` datetime DEFAULT NULL COMMENT '要求到达时间',
  `RealReceiveTime` datetime DEFAULT NULL COMMENT '实际到达时间',
  `SendTime` datetime DEFAULT NULL COMMENT '发货日期',
  `SendCompany` varchar(50) DEFAULT NULL COMMENT '发货单位',
  `SendAddress` varchar(200) DEFAULT NULL COMMENT '发货地址',
  `Sender` varchar(32) DEFAULT NULL COMMENT '发货人',
  `SenderMobile` varchar(32) DEFAULT NULL COMMENT '发货人电话',
  `Attach` varchar(512) DEFAULT NULL COMMENT '收货单',
  `RecvStatus` int DEFAULT NULL COMMENT '收货状态',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='收货签收/发货签收';

/*Table structure for table `tb_buy_recvsignitem` */

DROP TABLE IF EXISTS `tb_buy_recvsignitem`;

CREATE TABLE `tb_buy_recvsignitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractItemId` char(36) DEFAULT NULL COMMENT '销售合同清单明细ID',
  `JoinSignId` char(36) DEFAULT NULL COMMENT '会签合同ID',
  `JoinSignItemId` char(36) DEFAULT NULL COMMENT '会签合同明细ID',
  `JoinSignItemSiteId` char(36) DEFAULT NULL COMMENT '会签合同明细站点ID',
  `RecvSignId` char(36) DEFAULT NULL COMMENT '发货签收ID',
  `SiteId` char(36) DEFAULT NULL COMMENT '站点ID',
  `Seq` varchar(32) DEFAULT NULL COMMENT '序号',
  `MaterialType` int DEFAULT NULL COMMENT '物资类型 1-正常 2-配件 3-额外采购',
  `PreId` char(36) DEFAULT NULL COMMENT '购物车明细ID（上一步）',
  `PreParentId` char(36) DEFAULT NULL COMMENT '购物车明细父ID（上一步）',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `MaterialParams` varchar(128) DEFAULT NULL COMMENT '参数要求',
  `RecvItemStatus` int DEFAULT NULL COMMENT '收货状态',
  `ReceiveTime` datetime DEFAULT NULL COMMENT '要求到货日期',
  `RealReceiveTime` datetime DEFAULT NULL COMMENT '实际到达时间',
  `ReqOrderItemRemark` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='收货签收明细/发货签收明细';

/*Table structure for table `tb_buy_reqcart` */

DROP TABLE IF EXISTS `tb_buy_reqcart`;

CREATE TABLE `tb_buy_reqcart` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `OwnerStaffId` char(36) DEFAULT NULL COMMENT '购物车所属人ID',
  `OwnerStaffName` varchar(32) DEFAULT NULL COMMENT '购物车所属人',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='下采购物车';

/*Table structure for table `tb_buy_reqcartitem` */

DROP TABLE IF EXISTS `tb_buy_reqcartitem`;

CREATE TABLE `tb_buy_reqcartitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractItemId` char(36) DEFAULT NULL COMMENT '销售合同清单明细ID',
  `PmStaffId` char(36) DEFAULT NULL COMMENT '项目经理ID(申请人)',
  `PmStaffName` varchar(32) DEFAULT NULL COMMENT '项目经理(申请人)',
  `IsPmAdd` tinyint(1) DEFAULT NULL COMMENT '是否是项目经理增加',
  `Seq` varchar(32) DEFAULT NULL COMMENT '序号',
  `MaterialType` int DEFAULT NULL COMMENT '物资类型 1-正常 2-配件 3-额外采购',
  `ParentId` char(36) DEFAULT NULL COMMENT '父商品ID',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `MaterialParams` varchar(128) DEFAULT NULL COMMENT '参数要求',
  `ReceiveTime` datetime DEFAULT NULL COMMENT '到货日期(已废弃)',
  `SiteItemsJson` text COMMENT '分站点数量json',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='下采购物车明细';

/*Table structure for table `tb_buy_reqorder` */

DROP TABLE IF EXISTS `tb_buy_reqorder`;

CREATE TABLE `tb_buy_reqorder` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `BuyRecvAddressId` char(36) DEFAULT NULL COMMENT '收货地址ID',
  `RecvName` varchar(32) DEFAULT NULL COMMENT '收货人姓名',
  `RecvMobile` varchar(32) DEFAULT NULL COMMENT '收货人联系方式',
  `RecvAddress` varchar(128) DEFAULT NULL COMMENT '收货地址',
  `PmStaffId` char(36) DEFAULT NULL COMMENT '项目经理ID(申请人)',
  `PmStaffName` varchar(32) DEFAULT NULL COMMENT '项目经理(申请人)',
  `ReqOrderStatus` bit(1) DEFAULT NULL COMMENT '是否是待下采状态',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='下采单';

/*Table structure for table `tb_buy_reqorderitem` */

DROP TABLE IF EXISTS `tb_buy_reqorderitem`;

CREATE TABLE `tb_buy_reqorderitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractItemId` char(36) DEFAULT NULL COMMENT '销售合同清单明细ID',
  `ReqOrderId` char(36) DEFAULT NULL COMMENT '下采订单ID',
  `PmStaffId` char(36) DEFAULT NULL COMMENT '项目经理ID(申请人)',
  `PmStaffName` varchar(32) DEFAULT NULL COMMENT '项目经理(申请人)',
  `IsPmAdd` tinyint(1) DEFAULT NULL COMMENT '是否是项目经理增加',
  `Seq` varchar(32) DEFAULT NULL COMMENT '序号',
  `MaterialType` int DEFAULT NULL COMMENT '物资类型 1-正常 2-配件 3-额外采购',
  `PreId` char(36) DEFAULT NULL COMMENT '购物车明细ID（上一步）',
  `PreParentId` char(36) DEFAULT NULL COMMENT '购物车明细父ID（上一步）',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号',
  `OldMaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号（原始）',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `MaterialParams` varchar(128) DEFAULT NULL COMMENT '参数要求',
  `MaterialPrice` decimal(18,2) DEFAULT NULL COMMENT '采购单价',
  `MaterialBrand` varchar(100) DEFAULT NULL COMMENT '品牌',
  `SubTotal` decimal(18,2) DEFAULT NULL COMMENT '小计',
  `ReceiveTime` datetime DEFAULT NULL COMMENT '到货日期',
  `IsCollect` bit(1) DEFAULT NULL COMMENT '是否领取',
  `CollectStaffId` char(36) DEFAULT NULL COMMENT '领取人ID（采购专员）',
  `CollectStaffName` varchar(32) DEFAULT NULL COMMENT '领取人（采购专员）',
  `CollectTime` datetime DEFAULT NULL COMMENT '领取时间',
  `IsJoinSign` bit(1) DEFAULT NULL COMMENT '是否已关联采购会签',
  `SiteItemsJson` text COMMENT '分站点数量json',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='下采单明细/待采单';

/*Table structure for table `tb_buy_supply` */

DROP TABLE IF EXISTS `tb_buy_supply`;

CREATE TABLE `tb_buy_supply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `CatId` varchar(300) DEFAULT NULL COMMENT '供应商类别',
  `Level` varchar(32) DEFAULT NULL COMMENT '供应商级别',
  `Name` varchar(32) DEFAULT NULL COMMENT '供应商名称',
  `Contact` varchar(32) DEFAULT NULL COMMENT '销售员',
  `Phone` varchar(32) DEFAULT NULL COMMENT '销售员电话',
  `Contact2` varchar(32) DEFAULT NULL COMMENT '销售员领导',
  `Phone2` varchar(32) DEFAULT NULL COMMENT '销售员领导电话',
  `AddDate` datetime DEFAULT NULL COMMENT '添加时间',
  `InCompany` varchar(100) DEFAULT NULL COMMENT '收款单位',
  `InBank` varchar(100) DEFAULT NULL COMMENT '收款开户行',
  `InBankAccount` varchar(100) DEFAULT NULL COMMENT '收款开户行账号',
  `BusiLicense` text COMMENT '供应商营业执照',
  `AuthLicense` text COMMENT '管理认证体系',
  `TaxLicense` text COMMENT '一般纳税人证明',
  `CreditLicense` text COMMENT '国家企业信用信息公示系统相关公示信息',
  `Comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='供应商';

/*Table structure for table `tb_buy_supplyapply` */

DROP TABLE IF EXISTS `tb_buy_supplyapply`;

CREATE TABLE `tb_buy_supplyapply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ApplyType` int DEFAULT NULL COMMENT '申请类型',
  `SupplyId` char(36) DEFAULT NULL COMMENT '供应商ID',
  `CatId` varchar(300) DEFAULT NULL COMMENT '供应商类别',
  `Level` varchar(32) DEFAULT NULL COMMENT '供应商级别',
  `Name` varchar(32) DEFAULT NULL COMMENT '供应商名称',
  `Contact` varchar(32) DEFAULT NULL COMMENT '供应商销售人员',
  `Phone` varchar(32) DEFAULT NULL COMMENT '供应商销售人员联系电话',
  `Contact2` varchar(32) DEFAULT NULL COMMENT '供应商上级领导',
  `Phone2` varchar(32) DEFAULT NULL COMMENT '供应商上级领导联系电话',
  `InCompany` varchar(100) DEFAULT NULL COMMENT '收款单位',
  `InBank` varchar(100) DEFAULT NULL COMMENT '收款开户行',
  `InBankAccount` varchar(100) DEFAULT NULL COMMENT '收款开户行账号',
  `BusiLicense` text COMMENT '供应商营业执照',
  `AuthLicense` text COMMENT '管理认证体系',
  `TaxLicense` text COMMENT '一般纳税人证明',
  `CreditLicense` text COMMENT '国家企业信用信息公示系统相关公示信息',
  `Comment` varchar(200) DEFAULT NULL COMMENT '供应商备注',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='供应商申请';

/*Table structure for table `tb_buy_supplyapplydetail` */

DROP TABLE IF EXISTS `tb_buy_supplyapplydetail`;

CREATE TABLE `tb_buy_supplyapplydetail` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ApplyId` char(36) DEFAULT NULL COMMENT '请假表Id',
  `ReviewerId` char(36) DEFAULT NULL COMMENT '审批人Id',
  `ReviewerName` varchar(32) DEFAULT NULL COMMENT '审批人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `IsApproved` bit(1) DEFAULT NULL COMMENT '是否同意',
  `ApproveTime` datetime DEFAULT NULL COMMENT '同意/不同意时间',
  `IsReturnBack` bit(1) DEFAULT NULL,
  `Comment` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_buy_supplycat` */

DROP TABLE IF EXISTS `tb_buy_supplycat`;

CREATE TABLE `tb_buy_supplycat` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(32) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_car_applynote` */

DROP TABLE IF EXISTS `tb_car_applynote`;

CREATE TABLE `tb_car_applynote` (
  `Id` char(36) NOT NULL COMMENT '申请id',
  `UserId` varchar(36) DEFAULT NULL COMMENT '申请人Id',
  `DepartmentId` varchar(36) DEFAULT NULL COMMENT '申请人所属部门',
  `ApplyName` varchar(32) DEFAULT NULL COMMENT '申请人名称',
  `ApplyPhone` varchar(16) DEFAULT NULL COMMENT '申请人手机号码',
  `ApplyIdCard` varchar(32) DEFAULT NULL COMMENT '申请人身份证号码',
  `ApplyLicenceFront` varchar(255) DEFAULT NULL COMMENT '申请人驾驶证正面',
  `ApplyLicenceBehind` varchar(255) DEFAULT NULL COMMENT '申请人驾驶证反面',
  `ApplyStatus` int DEFAULT NULL COMMENT '1.表示申请中 2.表示通过 3.表示失败 4.已取消',
  `CarId` char(36) DEFAULT NULL COMMENT '关联车子的id',
  `DriverId` char(36) DEFAULT NULL COMMENT '输入电话号码后查询，如果存在驾驶员信息 就不需要驾驶证正反面，取到驾驶员id',
  `ApplyReason` varchar(255) DEFAULT NULL COMMENT '申请事由',
  `ApplyUseDate` datetime DEFAULT NULL COMMENT '用车时间',
  `ApplyBackDate` datetime DEFAULT NULL COMMENT '预计归还',
  `ActualUseDate` datetime DEFAULT NULL COMMENT '实际用车时间',
  `ActualBackDate` datetime DEFAULT NULL COMMENT '实际还车时间',
  `ReviewerId1` varchar(128) DEFAULT NULL COMMENT '审核人1',
  `ReviewerId2` varchar(128) DEFAULT NULL COMMENT '审核人2',
  `CcId1` varchar(128) DEFAULT NULL COMMENT '抄送人1',
  `ApplyResult` varchar(255) DEFAULT NULL COMMENT '审核结果说明  如果是审核通过则为空，如果是审核失败则是失败原因',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `TB_Car_CarApplyRecord` */

DROP TABLE IF EXISTS `TB_Car_CarApplyRecord`;

CREATE TABLE `TB_Car_CarApplyRecord` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `CarInformationId` char(36) DEFAULT NULL COMMENT '车辆Id',
  `FromAddress` varchar(128) DEFAULT NULL COMMENT '出发地',
  `DestAddress` varchar(128) DEFAULT NULL COMMENT '目的地',
  `PlanPickTime` datetime DEFAULT NULL COMMENT '预计取车时间',
  `PlanReturnTime` datetime DEFAULT NULL COMMENT '预计换车时间',
  `Attachment` varchar(255) DEFAULT NULL COMMENT '附件',
  `IsNeedDriver` bit(1) DEFAULT NULL,
  `DriverId` char(36) DEFAULT NULL,
  `UseStaffId` char(36) DEFAULT NULL COMMENT '车辆使用人ID',
  `UseStaffName` varchar(32) DEFAULT NULL COMMENT '车辆使用人',
  `ReturnStatus` int DEFAULT NULL COMMENT '还车状态 1-未还 2-已还',
  `ReturnTime` datetime DEFAULT NULL COMMENT '还车时间',
  `ReturnStaffId` char(36) DEFAULT NULL COMMENT '还车人ID',
  `ReturnStaffName` varchar(32) DEFAULT NULL COMMENT '还车人',
  `CcIds` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `ProjectName` varchar(128) DEFAULT NULL COMMENT '项目名称',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='车辆审核记录';

/*Table structure for table `tb_car_cardriverinformation` */

DROP TABLE IF EXISTS `tb_car_cardriverinformation`;

CREATE TABLE `tb_car_cardriverinformation` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) NOT NULL COMMENT '人员Id',
  `DriverName` varchar(32) DEFAULT NULL COMMENT '驾驶员姓名',
  `DrivePhone` varchar(32) DEFAULT NULL COMMENT '驾驶员手机',
  `DriveIdCard` varchar(32) DEFAULT NULL COMMENT '驾驶员身份证号',
  `DriverLicenceDocNo` varchar(32) DEFAULT NULL COMMENT '机动车驾驶证号',
  `DriverLicenceCarNo` varchar(32) DEFAULT NULL COMMENT '机动车驾驶证号',
  `DriverLicenceType` varchar(32) DEFAULT NULL COMMENT '驾驶证类型',
  `DriverLicenceFront` varchar(255) DEFAULT NULL COMMENT '驾驶证正面',
  `DriverLicenceBehind` varchar(255) DEFAULT NULL COMMENT '驾驶证反面',
  `ContactAddress` varchar(255) DEFAULT NULL,
  `DriverStatus` int DEFAULT NULL COMMENT '司机状态 0-空闲 1-出车 2-不可用',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='驾驶员';

/*Table structure for table `tb_car_carillegal` */

DROP TABLE IF EXISTS `tb_car_carillegal`;

CREATE TABLE `tb_car_carillegal` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `CarInformationId` char(36) NOT NULL COMMENT '车辆Id',
  `IllegalAction` varchar(512) DEFAULT NULL COMMENT '违章行为',
  `IllegalTime` datetime DEFAULT NULL COMMENT '违章时间',
  `IllegalAddress` varchar(512) DEFAULT NULL COMMENT '违章地点',
  `IllegalAmount` decimal(11,2) DEFAULT NULL COMMENT '罚款金额',
  `IllegalPoint` int DEFAULT NULL COMMENT '记分',
  `IllegalPunishUnit` varchar(1024) DEFAULT NULL COMMENT '处罚机关',
  `IllegalPunishTime` datetime DEFAULT NULL COMMENT '处罚时间',
  `IllegalPunishContent` varchar(200) DEFAULT NULL COMMENT '处罚内容',
  `StaffId` char(36) DEFAULT NULL COMMENT '违章人Id',
  `LateFee` decimal(11,2) DEFAULT NULL COMMENT '滞纳金',
  `StaffName` varchar(32) DEFAULT NULL COMMENT '违章人姓名',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='车辆违章记录';

/*Table structure for table `tb_car_carinfo` */

DROP TABLE IF EXISTS `tb_car_carinfo`;

CREATE TABLE `tb_car_carinfo` (
  `Id` char(36) NOT NULL COMMENT '车子id',
  `CarName` varchar(32) DEFAULT NULL COMMENT '车子名称',
  `CarImage` varchar(255) DEFAULT NULL COMMENT '车子图片',
  `CarType` varchar(32) DEFAULT NULL COMMENT '车辆型号',
  `CarLicensePlate` varchar(10) DEFAULT NULL COMMENT '车辆牌照',
  `CarColor` varchar(8) DEFAULT NULL COMMENT '车辆颜色',
  `CarBuyDate` date DEFAULT NULL COMMENT '车辆购买时间',
  `CarForm` int DEFAULT NULL COMMENT '1: 表示专车 0: 表示公车',
  `UserName` varchar(32) DEFAULT NULL COMMENT '专车使用人姓名',
  `UserMobile` varchar(20) DEFAULT NULL COMMENT '专车使用人手机号',
  `CarStall` varchar(8) DEFAULT NULL COMMENT '车位号',
  `CarPreMaintainDate` date DEFAULT NULL COMMENT '上次保养时间',
  `CarPreMaintainContent` varchar(512) DEFAULT NULL COMMENT '上次保养内容',
  `CarNextMaintainDate` date DEFAULT NULL COMMENT '下次保养时间',
  `CarInsurance` varchar(50) DEFAULT NULL COMMENT '投保的保险公司',
  `CarInsuranceDate` date DEFAULT NULL COMMENT '投保时间',
  `CarPreAnnualSurveyDate` date DEFAULT NULL COMMENT '上次年检的时间',
  `CarNextAnnualSurveyDate` date DEFAULT NULL COMMENT '下次年检的时间',
  `CarTrafficControl` int DEFAULT NULL COMMENT '车辆是否限号1:表示限号 0：表示不限号',
  `CarStatus` int DEFAULT NULL COMMENT '0: 表示未使用 1: 表示使用中',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_car_carinformation` */

DROP TABLE IF EXISTS `tb_car_carinformation`;

CREATE TABLE `tb_car_carinformation` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `CarName` varchar(32) DEFAULT NULL COMMENT '车辆名称',
  `CarImage` text COMMENT '车辆图片',
  `CarBrand` varchar(32) DEFAULT NULL COMMENT '车辆品牌',
  `CarType` varchar(32) DEFAULT NULL COMMENT '车辆车型 ex: 小型轿车',
  `CarLicensePlate` varchar(10) DEFAULT NULL COMMENT '车辆牌照',
  `CarLicenseUnit` varchar(10) DEFAULT NULL COMMENT '发证机关',
  `CarLicenceDocNo` varchar(32) DEFAULT NULL COMMENT '车辆行驶证编号',
  `CarColor` varchar(32) DEFAULT NULL COMMENT '车辆颜色',
  `CarBuyDate` date DEFAULT NULL COMMENT '车辆购买时间',
  `CarForm` int DEFAULT NULL COMMENT '1-专车 0-公车',
  `UserId` char(36) DEFAULT NULL COMMENT '驾驶员ID',
  `UserName` varchar(32) DEFAULT NULL COMMENT '专车使用人姓名',
  `UserMobile` varchar(32) DEFAULT NULL COMMENT '专车使用人手机号',
  `CarStall` varchar(32) DEFAULT NULL COMMENT '车位号',
  `CarPreMaintainDate` date DEFAULT NULL COMMENT '上次保养时间',
  `CarPreMaintainDateContent` varchar(512) DEFAULT NULL COMMENT '上次保养内容',
  `CarNextMaintainDate` date DEFAULT NULL COMMENT '下次保养时间',
  `CarInsurance` varchar(50) DEFAULT NULL COMMENT '投保的保险公司',
  `CarInsuranceDate` date DEFAULT NULL COMMENT '投保时间',
  `CarPreAnnualSurveyDate` date DEFAULT NULL COMMENT '上次年检的时间',
  `CarNextAnnualSurveyDate` date DEFAULT NULL COMMENT '下次年检的时间',
  `CarTrafficControl` int DEFAULT NULL COMMENT '车辆是否限号 1-限号 0-不限号',
  `CarStatus` int DEFAULT NULL COMMENT '1-正常使用2-已报废',
  `InUse` bit(1) DEFAULT NULL COMMENT '是否在使用中',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='驾驶员';

/*Table structure for table `tb_car_carinsurance` */

DROP TABLE IF EXISTS `tb_car_carinsurance`;

CREATE TABLE `tb_car_carinsurance` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `CarInformationId` char(36) NOT NULL COMMENT '车辆Id',
  `InsuranceCompany` varchar(32) DEFAULT NULL COMMENT '保险公司',
  `InsuranceContent` text COMMENT '保险内容',
  `InsuranceNo` varchar(32) DEFAULT NULL COMMENT '保险单号',
  `InsuranceFee` varchar(32) DEFAULT NULL COMMENT '保险费用',
  `StartTime` datetime DEFAULT NULL COMMENT '保险开始日期',
  `EndTime` datetime DEFAULT NULL COMMENT '保险结束日期',
  `YearTime` datetime DEFAULT NULL COMMENT '年度',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='车辆保险记录';

/*Table structure for table `tb_car_carmaintain` */

DROP TABLE IF EXISTS `tb_car_carmaintain`;

CREATE TABLE `tb_car_carmaintain` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `CarInformationId` char(36) NOT NULL COMMENT '车辆Id',
  `MaintainType` int DEFAULT NULL COMMENT '类型 1-保养 2-维修',
  `MaintainContent` varchar(1024) DEFAULT NULL COMMENT '内容',
  `MaintainDate` date DEFAULT NULL COMMENT '日期',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='车辆保养/维修记录';

/*Table structure for table `tb_car_driverinfo` */

DROP TABLE IF EXISTS `tb_car_driverinfo`;

CREATE TABLE `tb_car_driverinfo` (
  `Id` char(36) NOT NULL COMMENT '驾驶员id',
  `DriverName` varchar(32) DEFAULT NULL COMMENT '驾驶员名称',
  `DriverPhone` varchar(16) DEFAULT NULL COMMENT '驾驶员手机号码',
  `DriverIdCard` varchar(32) DEFAULT NULL COMMENT '驾驶员身份证号码',
  `DrivingLicenceFront` varchar(255) DEFAULT NULL COMMENT '驾驶证正面',
  `DrivingLicenceBehind` varchar(255) DEFAULT NULL COMMENT '驾驶证反面',
  `STATUS` int DEFAULT NULL COMMENT '驾驶员状态，0-闲置，1-出车，2-不可用',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_car_parkingplace` */

DROP TABLE IF EXISTS `tb_car_parkingplace`;

CREATE TABLE `tb_car_parkingplace` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `CompanyId` char(36) DEFAULT NULL COMMENT '公司Id',
  `CompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称',
  `DeptId` char(36) DEFAULT NULL,
  `DeptName` varchar(256) DEFAULT NULL,
  `StaffId` char(36) DEFAULT NULL COMMENT '人员Id',
  `StaffName` varchar(32) DEFAULT NULL,
  `ParkingSpaceNumber` varchar(32) DEFAULT NULL COMMENT '车位号',
  `CarNumber` varchar(32) DEFAULT NULL COMMENT '车牌号',
  `StartDate` date DEFAULT NULL COMMENT '租赁开始日期',
  `EndDate` date DEFAULT NULL COMMENT '租赁开结束日期',
  `LeaseFile` varchar(1024) DEFAULT NULL COMMENT '租赁文件',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='车位管理';

/*Table structure for table `tb_carapply_review` */

DROP TABLE IF EXISTS `tb_carapply_review`;

CREATE TABLE `tb_carapply_review` (
  `Id` char(36) NOT NULL COMMENT '主键',
  `ApplyId` char(36) NOT NULL COMMENT '车辆申请Id',
  `ReviewerId` varchar(128) NOT NULL COMMENT '审核人Id',
  `STATUS` int NOT NULL DEFAULT '0' COMMENT '审核状态，0-待审核，1-审核通过，2-审核不通过',
  `CreateTime` datetime NOT NULL COMMENT '创建时间',
  `ReviewTime` datetime DEFAULT NULL COMMENT '审核时间',
  `ReviewRemark` varchar(500) DEFAULT NULL COMMENT '审核备注',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Table structure for table `tb_certificate_companycert` */

DROP TABLE IF EXISTS `tb_certificate_companycert`;

CREATE TABLE `tb_certificate_companycert` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `QualiTypeName` varchar(32) DEFAULT NULL COMMENT '资质类型名称',
  `CompanyDeptId` char(36) DEFAULT NULL,
  `CompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称',
  `CertName` varchar(32) DEFAULT NULL COMMENT '证书名称',
  `CertNo` varchar(64) DEFAULT NULL COMMENT '证书编号',
  `StartTime` datetime DEFAULT NULL COMMENT '证书颁发时间',
  `EndTime` datetime DEFAULT NULL COMMENT '证书过期时间',
  `AnnualTime` datetime DEFAULT NULL COMMENT '年检日期',
  `IssuingUnit` varchar(32) DEFAULT NULL COMMENT '证书颁发机构',
  `CertImages` text COMMENT '证书封面和内容页高清图片',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='公司资质证书';

/*Table structure for table `tb_certificate_notifyreceiverstate` */

DROP TABLE IF EXISTS `tb_certificate_notifyreceiverstate`;

CREATE TABLE `tb_certificate_notifyreceiverstate` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ReceiverId` char(36) NOT NULL COMMENT '资质分类 1-个人 2-公司',
  `QuliTypeId` varchar(32) DEFAULT NULL COMMENT '资质类型Id',
  `LastReceiveTime` datetime DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='资质到期通知人员状态';

/*Table structure for table `tb_certificate_patent` */

DROP TABLE IF EXISTS `tb_certificate_patent`;

CREATE TABLE `tb_certificate_patent` (
  `Id` char(36) NOT NULL COMMENT '主键',
  `PatentNo` varchar(50) DEFAULT NULL COMMENT '专利号',
  `PatentName` varchar(256) DEFAULT NULL COMMENT '专利名称',
  `PatentType` int DEFAULT NULL COMMENT '专利类型',
  `PatentPics` text COMMENT '专利图片',
  `ApplyTime` datetime DEFAULT NULL COMMENT '证书申请时间',
  `AuthNoticeTime` datetime DEFAULT NULL COMMENT '授权公告时间',
  `RenewTime` datetime DEFAULT NULL COMMENT '续费时间',
  `HoldYears` int DEFAULT NULL COMMENT '持有年限',
  `RenewMoney` decimal(18,2) DEFAULT NULL COMMENT '续费金额',
  `PatentHolder` varchar(50) DEFAULT NULL COMMENT '专利持有人',
  `PayeeName` varchar(128) DEFAULT NULL COMMENT '收款机构',
  `PayeeAccount` varchar(128) DEFAULT NULL COMMENT '收款账户',
  `STATUS` int DEFAULT NULL COMMENT '状态',
  `IsDeleted` tinyint(1) DEFAULT NULL COMMENT '是否已删除',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='专利表';

/*Table structure for table `tb_certificate_qualificationinfo` */

DROP TABLE IF EXISTS `tb_certificate_qualificationinfo`;

CREATE TABLE `tb_certificate_qualificationinfo` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `CertCategory` int NOT NULL COMMENT '资质证书分类 1-员工 2-公司',
  `CompanyCertType` int DEFAULT NULL COMMENT '公司证书类型枚举 1-高新技术证书 2-单位认证',
  `CompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称',
  `StaffCertType` int DEFAULT NULL COMMENT '员工证书类型 1-身份证 2-学历证书 3-职称类证件 4-安全证 5-运维证 6-一级建造师 7-二级建造师',
  `StaffId` char(36) DEFAULT NULL COMMENT '员工Id',
  `StaffName` varchar(32) DEFAULT NULL,
  `CertName` varchar(32) DEFAULT NULL COMMENT '证书名称',
  `CertNo` varchar(64) DEFAULT NULL COMMENT '证书编号',
  `CertStartTime` datetime DEFAULT NULL COMMENT '证书有效期',
  `CertEndTime` datetime DEFAULT NULL COMMENT '证书有效期',
  `CertUnit` varchar(32) DEFAULT NULL COMMENT '证书签发机构',
  `CertImages` text COMMENT '证书封面和内容页高清图片',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='资质证书';

/*Table structure for table `tb_fund_info` */

DROP TABLE IF EXISTS `tb_fund_info`;

CREATE TABLE `tb_fund_info` (
  `Id` char(36) NOT NULL,
  `FundExplain` varchar(32) DEFAULT NULL COMMENT '款项用途',
  `FundPrice` decimal(10,2) DEFAULT NULL COMMENT '款项金额',
  `ApplyName` varchar(16) DEFAULT NULL COMMENT '款项申请人',
  `PurchaseApplyId` varchar(36) DEFAULT NULL COMMENT '采购申请Id',
  `DepartmentId` varchar(36) DEFAULT NULL COMMENT '申请人部门Id',
  `ApplyPhone` varchar(16) DEFAULT NULL COMMENT '申请人电话',
  `ApplyDate` datetime DEFAULT NULL COMMENT '申请时间',
  `SupplierId` varchar(36) DEFAULT NULL COMMENT '供应商Id',
  `SupplierName` varchar(32) DEFAULT NULL COMMENT '供应商名称',
  `SupplierConnact` varchar(16) DEFAULT NULL COMMENT '供应商联系人',
  `SupplierPhone` varchar(32) DEFAULT NULL COMMENT '供应商联系电话',
  `PayStatus` int DEFAULT NULL COMMENT '支付状态，0-未支付，1-支付成功，2-支付失败',
  `PurchaseBill` varchar(128) DEFAULT NULL COMMENT '采购发票',
  `CompleteDate` datetime DEFAULT NULL,
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='款项信息';

/*Table structure for table `TB_House_HouseInfo-del` */

DROP TABLE IF EXISTS `TB_House_HouseInfo-del`;

CREATE TABLE `TB_House_HouseInfo-del` (
  `Id` char(36) NOT NULL COMMENT '房屋Id',
  `HouseName` varchar(32) NOT NULL COMMENT '房屋名字',
  `HouseAddress` varchar(32) NOT NULL COMMENT '房屋地址',
  `HouseFrom` int NOT NULL COMMENT '房源来源，0-租进，1-租出',
  `HouseImage` varchar(1024) NOT NULL COMMENT '房屋图片',
  `HouseAddDate` date DEFAULT NULL COMMENT '房屋添加时间',
  `Landlord` varchar(32) NOT NULL COMMENT '房东',
  `LandlordPhone` varchar(16) DEFAULT NULL COMMENT '房东电话',
  `LandlordLicence_front` varchar(255) DEFAULT NULL COMMENT '房东有效证件正面',
  `LandlordLicence_behind` varchar(255) DEFAULT NULL COMMENT '房东有效证件反面',
  `LeaseMode` int NOT NULL COMMENT '租赁方式，0-整租，1-零租',
  `OriginalGoods` text COMMENT '原有物品',
  `AddGoods` text COMMENT '添置物品',
  `STATUS` int NOT NULL COMMENT '房源状态，0-闲置，1-在租，2-已下架',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreateTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `TB_House_HouseLease-del` */

DROP TABLE IF EXISTS `TB_House_HouseLease-del`;

CREATE TABLE `TB_House_HouseLease-del` (
  `Id` char(36) NOT NULL COMMENT '主键',
  `HouseId` char(36) DEFAULT NULL COMMENT '房屋Id',
  `RoomId` char(36) DEFAULT NULL COMMENT '房间Id',
  `LeasePrice` decimal(18,2) DEFAULT NULL COMMENT '租赁价格',
  `Deposit` decimal(18,2) DEFAULT NULL COMMENT '押金',
  `ResidentsAmount` int DEFAULT NULL COMMENT '租赁人数',
  `LeaseBeginTime` datetime DEFAULT NULL COMMENT '租赁起始时间',
  `LeaseEndTime` datetime DEFAULT NULL COMMENT '租赁截止时间',
  `LeasePerson` varchar(500) DEFAULT NULL COMMENT '租赁人',
  `LeasePersonPhone` varchar(200) DEFAULT NULL COMMENT '租赁人电话',
  `LeasePersonIdCard` text COMMENT '租赁人身份证正反面照片',
  `ManagerName` varchar(50) DEFAULT NULL COMMENT '负责人姓名',
  `ManagerPhone` varchar(20) DEFAULT NULL COMMENT '负责人电话',
  `LeaseContract` varchar(2048) DEFAULT NULL COMMENT '租赁合同图片地址',
  `AdditionalLeaseInfo` text COMMENT '附加租赁信息',
  `GiveupTime` datetime DEFAULT NULL COMMENT '退租时间',
  `CancelTime` datetime DEFAULT NULL COMMENT '取消时间',
  `STATUS` int DEFAULT NULL COMMENT '状态，0-在租，1-退租，2-取消',
  `IsDeleted` tinyint(1) DEFAULT NULL COMMENT '是否已删除',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Creater` varchar(50) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='房屋租赁表';

/*Table structure for table `TB_House_RoomInfo-del` */

DROP TABLE IF EXISTS `TB_House_RoomInfo-del`;

CREATE TABLE `TB_House_RoomInfo-del` (
  `Id` char(36) NOT NULL COMMENT '主键',
  `HouseId` char(36) DEFAULT NULL COMMENT '房子Id',
  `NAME` varchar(50) DEFAULT NULL COMMENT '房间名称',
  `AREA` int DEFAULT NULL COMMENT '房间面积',
  `Orientation` varchar(10) DEFAULT NULL COMMENT '房间朝向',
  `MaxResidents` int DEFAULT '1' COMMENT '最多居住人数',
  `STATUS` int DEFAULT NULL COMMENT '房间状态，0-空闲，1-在租',
  `IsDeleted` tinyint(1) DEFAULT NULL COMMENT '是否已删除',
  `Creater` varchar(50) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='房间表';

/*Table structure for table `tb_hr_decasualization` */

DROP TABLE IF EXISTS `tb_hr_decasualization`;

CREATE TABLE `tb_hr_decasualization` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AyCompanyId` char(36) DEFAULT NULL COMMENT '公司Id',
  `AyCompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称',
  `AyDeptId` char(36) DEFAULT NULL COMMENT '申请部门Id',
  `AyDeptName` varchar(256) DEFAULT NULL COMMENT '申请部门',
  `InnerCompayType` int DEFAULT NULL COMMENT '公司类型 1-总公司 2-子公司',
  `AyStaffId` char(36) DEFAULT NULL COMMENT '申请人Id',
  `AyStaffName` varchar(32) DEFAULT NULL COMMENT '申请人',
  `AyPostId` char(36) DEFAULT NULL COMMENT '申请岗位Id',
  `AyPost` varchar(16) DEFAULT NULL COMMENT '申请岗位',
  `Gender` varchar(6) DEFAULT NULL COMMENT '性别',
  `HireDate` datetime DEFAULT NULL COMMENT '入职日期',
  `DecasualizationDate` datetime DEFAULT NULL COMMENT '转正日期',
  `ProbationSalary` decimal(10,2) DEFAULT NULL COMMENT '试用薪资',
  `Salary` decimal(10,2) DEFAULT NULL COMMENT '转正薪资',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='试用期转正审批';

/*Table structure for table `TB_HR_InterviewEvaluation` */

DROP TABLE IF EXISTS `TB_HR_InterviewEvaluation`;

CREATE TABLE `TB_HR_InterviewEvaluation` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Candidate` varchar(32) NOT NULL COMMENT '应聘人员',
  `AyMethod` varchar(16) DEFAULT NULL COMMENT '应聘方式',
  `AyDeptId` char(36) DEFAULT NULL COMMENT '应聘部门Id',
  `AyDeptName` varchar(256) DEFAULT NULL COMMENT '应聘部门',
  `AyPostId` char(36) DEFAULT NULL COMMENT '申请岗位Id',
  `AyPost` varchar(16) DEFAULT NULL COMMENT '应聘职位',
  `FirstInterviewRecord` varchar(2048) DEFAULT NULL COMMENT '初试记录',
  `FirstInterviewSuggest` varchar(2048) DEFAULT NULL COMMENT '初试建议',
  `FirstInterviewerId` char(36) DEFAULT NULL COMMENT '面试人ID',
  `FirstInterviewer` varchar(32) DEFAULT NULL COMMENT '面试人',
  `FirstInterviewDate` datetime DEFAULT NULL COMMENT '日期',
  `FirstInterviewer2Id` char(36) DEFAULT NULL COMMENT '面试人2ID',
  `FirstInterviewer2` varchar(32) DEFAULT NULL COMMENT '面试人2',
  `FirstInterviewDate2` datetime DEFAULT NULL COMMENT '日期2',
  `SecondInterviewRecord` varchar(2048) DEFAULT NULL COMMENT '复试记录',
  `SecondInterviewSuggest` varchar(2048) DEFAULT NULL COMMENT '复试建议',
  `SecondInterviewerId` char(36) DEFAULT NULL COMMENT '面试人ID',
  `SecondInterviewer` varchar(32) DEFAULT NULL COMMENT '面试人',
  `SecondInterviewDate` datetime DEFAULT NULL COMMENT '日期',
  `SecondInterviewer2Id` char(36) DEFAULT NULL COMMENT '面试人2ID',
  `SecondInterviewer2` varchar(32) DEFAULT NULL COMMENT '面试人2',
  `SecondInterviewDate2` datetime DEFAULT NULL COMMENT '日期2',
  `HireDate` datetime DEFAULT NULL COMMENT '入职日期',
  `ProbationSalary` decimal(10,2) DEFAULT NULL COMMENT '试用薪资',
  `Salary` decimal(10,2) DEFAULT NULL COMMENT '转正薪资',
  `ProbationPeriod` int DEFAULT NULL COMMENT '试用期',
  `SocialSecurityBase` decimal(10,2) DEFAULT NULL COMMENT '社保及公积金缴纳基数',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `ReqIsDisplay` tinyint(1) DEFAULT NULL COMMENT '申请人是否可见',
  `IsDeleted` tinyint DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='面试评价与录用';

/*Table structure for table `TB_HR_PersonnelRequirements` */

DROP TABLE IF EXISTS `TB_HR_PersonnelRequirements`;

CREATE TABLE `TB_HR_PersonnelRequirements` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `InnerCompanyId` char(36) DEFAULT NULL COMMENT '公司Id',
  `InnerCompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称',
  `AyDeptId` char(36) DEFAULT NULL COMMENT '申请部门Id',
  `AyDeptName` varchar(256) DEFAULT NULL COMMENT '申请部门',
  `AyPostId` char(36) DEFAULT NULL COMMENT '岗位ID',
  `AyPost` varchar(16) DEFAULT NULL COMMENT '申请岗位',
  `ExistingStaffing` int DEFAULT NULL COMMENT '现有编制',
  `ActualNumber` int DEFAULT NULL COMMENT '实际在岗',
  `AyIncrease` int DEFAULT NULL COMMENT '申请增加',
  `RecruitReason` varchar(1024) DEFAULT NULL COMMENT '招聘理由',
  `OtherRecruitReason` varchar(1024) DEFAULT NULL COMMENT '招聘理由(其他)',
  `JobRequirements` varchar(2048) DEFAULT NULL COMMENT '岗位要求',
  `EducationalRequirements` varchar(16) DEFAULT NULL COMMENT '学历要求',
  `ExperienceRequirements` varchar(1024) DEFAULT NULL COMMENT '经验要求',
  `TechRequirements` varchar(2048) DEFAULT NULL COMMENT '技能要求',
  `OtherRequirements` varchar(1024) DEFAULT NULL COMMENT '其他要求',
  `StartSalary` decimal(10,2) DEFAULT NULL COMMENT '建议薪资起始',
  `EndSalary` decimal(10,2) DEFAULT NULL COMMENT '建议薪资截止',
  `RecruitmentMethods` varchar(16) DEFAULT NULL COMMENT '招聘方式',
  `AyStaffId` char(36) DEFAULT NULL COMMENT '申请人Id',
  `AyStaffName` varchar(32) DEFAULT NULL COMMENT '申请人',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `ReqIsDisplay` tinyint(1) DEFAULT NULL COMMENT '申请人是否显示',
  `IsDeleted` tinyint DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='人员需求审批';

/*Table structure for table `TB_Notice_ActiveNotice` */

DROP TABLE IF EXISTS `TB_Notice_ActiveNotice`;

CREATE TABLE `TB_Notice_ActiveNotice` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `RecvStaffId` char(36) NOT NULL COMMENT '接收人员Id（预留）',
  `RecvStaffName` varchar(32) DEFAULT NULL COMMENT '接收人员（预留）',
  `NoticeType` varchar(32) DEFAULT NULL COMMENT '通知类型（预留）',
  `Title` varchar(32) DEFAULT NULL COMMENT '标题',
  `Content` text COMMENT '内容',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='员工动态通知';

/*Table structure for table `tb_notice_alarmnotice` */

DROP TABLE IF EXISTS `tb_notice_alarmnotice`;

CREATE TABLE `tb_notice_alarmnotice` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `RecvStaffId` char(36) NOT NULL COMMENT '接收人员Id',
  `RecvStaffName` varchar(32) DEFAULT NULL COMMENT '接收人员',
  `RecvDeptId` char(36) DEFAULT NULL COMMENT '接收部门ID',
  `RecvDeptName` varchar(32) DEFAULT NULL COMMENT '接收部门',
  `NoticeType` varchar(32) DEFAULT NULL COMMENT '通知类型',
  `Title` varchar(32) DEFAULT NULL COMMENT '标题',
  `Content` text COMMENT '内容',
  `IsProcessed` tinyint(1) DEFAULT NULL COMMENT '是否办理',
  `Attachment` varchar(512) DEFAULT NULL COMMENT '附件',
  `BusiType` varchar(32) DEFAULT NULL COMMENT '业务类型',
  `BusiId` char(36) DEFAULT NULL COMMENT '业务ID',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='告警通知表';

/*Table structure for table `tb_notice_auditnotice` */

DROP TABLE IF EXISTS `tb_notice_auditnotice`;

CREATE TABLE `tb_notice_auditnotice` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `RecvStaffId` char(36) NOT NULL COMMENT '接收人员Id',
  `RecvStaffName` varchar(32) DEFAULT NULL COMMENT '接收人员',
  `RecvDeptId` char(36) DEFAULT NULL COMMENT '接收部门ID',
  `RecvDeptName` varchar(32) DEFAULT NULL COMMENT '接收部门',
  `Title` varchar(32) DEFAULT NULL COMMENT '标题',
  `Content` text COMMENT '内容',
  `IsProcessed` tinyint(1) DEFAULT NULL COMMENT '是否办理',
  `ProcessTime` datetime DEFAULT NULL COMMENT '办理时间',
  `IsRead` tinyint(1) DEFAULT NULL COMMENT '是否已读',
  `ReadTime` datetime DEFAULT NULL COMMENT '读取时间',
  `Attachment` varchar(512) DEFAULT NULL COMMENT '附件',
  `BelongType` int DEFAULT NULL COMMENT '当前这条数据归属类型:1-申请人自己 2-当前审核人',
  `ApplyStatus` int DEFAULT NULL COMMENT '申请状态(当前这条数据归属于申请人自己时，需要联动更新)',
  `ApplyTime` datetime DEFAULT NULL COMMENT '申请时间',
  `CurReviewerName` varchar(32) DEFAULT NULL COMMENT '当前审核人(当前这条数据归属于申请人自己时，需要联动更新)',
  `BusiType` varchar(32) DEFAULT NULL COMMENT '业务类型',
  `BusiId` char(36) DEFAULT NULL COMMENT '业务ID',
  `ApplyBusiId` char(36) DEFAULT NULL COMMENT '通用审核ID',
  `ApplyStaffId` char(36) DEFAULT NULL COMMENT '申请人员Id',
  `ApplyStaffName` varchar(32) DEFAULT NULL COMMENT '申请人员',
  `ApplyCompanyId` char(36) DEFAULT NULL COMMENT '申请公司ID',
  `ApplyCompanyName` varchar(32) DEFAULT NULL COMMENT '申请公司',
  `ApplyDeptId` char(36) DEFAULT NULL COMMENT '申请部门ID',
  `ApplyDeptName` varchar(32) DEFAULT NULL COMMENT '申请部门',
  `SendMsgCount` int DEFAULT NULL COMMENT '发送消息次数',
  `Level` int DEFAULT NULL COMMENT '消息紧急程度 1-正常 10-紧急',
  `LastSendMsgTime` datetime DEFAULT NULL COMMENT '最后一次发送消息时间',
  `IsDisplay` tinyint(1) DEFAULT NULL COMMENT '是否首页显示',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  `MenuId` char(36) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='工作待办（审核待办通知表）';

/*Table structure for table `tb_notice_noticeconfig` */

DROP TABLE IF EXISTS `tb_notice_noticeconfig`;

CREATE TABLE `tb_notice_noticeconfig` (
  `Id` char(36) NOT NULL COMMENT '主键',
  `NoticeType` int DEFAULT NULL COMMENT '消息类型，1-车辆年检通知，2-房屋到期通知',
  `LimitDays` int DEFAULT NULL COMMENT '限制最大通知天数',
  `IntervalDays` int DEFAULT NULL COMMENT '发送消息的间隔天数',
  `DayTimeBegin` time DEFAULT NULL COMMENT '每天发送的起始时间',
  `DayTimeEnd` time DEFAULT NULL COMMENT '每天发送的截止时间',
  `ReceiverList` text COMMENT '消息接收用户的Id列表',
  `ReceiverNames` text COMMENT '消息接收用户名列表',
  `IsValid` tinyint(1) DEFAULT NULL COMMENT '是否有效',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Table structure for table `tb_notice_noticereceiver` */

DROP TABLE IF EXISTS `tb_notice_noticereceiver`;

CREATE TABLE `tb_notice_noticereceiver` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `NoticeSenderId` char(36) NOT NULL COMMENT '公告主表Id',
  `RecvStaffId` char(36) NOT NULL COMMENT '接收人员Id',
  `RecvStaffName` varchar(32) DEFAULT NULL COMMENT '接收人员',
  `RecvCompanyId` char(36) DEFAULT NULL COMMENT '接收公司ID',
  `RecvCompanyName` varchar(32) DEFAULT NULL COMMENT '接收公司',
  `RecvDeptId` char(36) DEFAULT NULL COMMENT '接收部门ID',
  `RecvDeptName` varchar(32) DEFAULT NULL COMMENT '接收部门',
  `IsRead` tinyint(1) DEFAULT NULL COMMENT '是否已读',
  `ReadTime` datetime DEFAULT NULL COMMENT '阅读时间',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='公告子表（接收通知表）';

/*Table structure for table `tb_notice_noticerule` */

DROP TABLE IF EXISTS `tb_notice_noticerule`;

CREATE TABLE `tb_notice_noticerule` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `NoticeRuleType` int DEFAULT NULL COMMENT '通知规则类别 1 审核类 2 系统提醒类',
  `BusinessCode` varchar(32) DEFAULT NULL COMMENT '业务名称代码',
  `BusinessName` varchar(32) DEFAULT NULL COMMENT '业务名称',
  `FirstNoticeTime` int DEFAULT NULL COMMENT '首次提醒时间',
  `FirstNoticeUnit` varchar(32) DEFAULT NULL COMMENT '首次提醒时间单位',
  `CycleNoticeTime` int DEFAULT NULL COMMENT '间隔提醒周期',
  `CycleNoticeUnit` varchar(32) DEFAULT NULL COMMENT '间隔提醒周期单位',
  `BeforeExpirationTime` int DEFAULT NULL COMMENT '到期前时间提醒',
  `BeforeExpirationUnit` varchar(32) DEFAULT NULL COMMENT '到期前时间提醒单位',
  `NoticeStartTime` varchar(6) DEFAULT NULL COMMENT '通知开始时间',
  `NoticeEndTime` varchar(6) DEFAULT NULL COMMENT '通知结束时间',
  `ApplicantNoticeContent` varchar(256) DEFAULT NULL COMMENT '申请人申请结果提醒文案',
  `AuditorNoticeContent` varchar(256) DEFAULT NULL COMMENT '审核人提醒文案',
  `NoticeContent` varchar(256) DEFAULT NULL COMMENT '提醒文案',
  `IsEnable` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `LastExecutionTime` datetime DEFAULT NULL COMMENT '最后执行时间',
  `IsAppNotice` tinyint(1) DEFAULT NULL COMMENT 'App提醒方式',
  `IsWebNotice` tinyint(1) DEFAULT NULL COMMENT 'web提醒方式',
  `IsMessageNotice` tinyint(1) DEFAULT NULL COMMENT '短信提醒方式',
  `IsMailNotice` tinyint(1) DEFAULT NULL COMMENT '邮件提醒方式',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_notice_noticesender` */

DROP TABLE IF EXISTS `tb_notice_noticesender`;

CREATE TABLE `tb_notice_noticesender` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `SendStaffId` char(36) NOT NULL COMMENT '发送人员Id',
  `SendStaffName` varchar(32) DEFAULT NULL COMMENT '发送人员',
  `SendCompanyId` char(36) DEFAULT NULL COMMENT '发送公司ID',
  `SendCompanyName` varchar(32) DEFAULT NULL COMMENT '发送公司',
  `SendDeptId` char(36) DEFAULT NULL COMMENT '发送部门ID',
  `SendDeptName` varchar(32) DEFAULT NULL COMMENT '发送部门',
  `Title` varchar(32) DEFAULT NULL COMMENT '标题',
  `Content` text COMMENT '内容',
  `RecvDeptIds` varchar(2000) DEFAULT NULL COMMENT '接收部门ID（逗号分隔）',
  `RecvDeptNames` varchar(2000) DEFAULT NULL COMMENT '接收部门名称（逗号分隔）',
  `Attachment` varchar(512) DEFAULT NULL COMMENT '附件',
  `IsSend` tinyint(1) DEFAULT NULL COMMENT '是否发送',
  `PublishTime` datetime DEFAULT NULL COMMENT '发布时间',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='公告主表（发送通知表）';

/*Table structure for table `tb_notice_systemnotice` */

DROP TABLE IF EXISTS `tb_notice_systemnotice`;

CREATE TABLE `tb_notice_systemnotice` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `RecvStaffId` char(36) NOT NULL COMMENT '接收人员Id',
  `RecvStaffName` varchar(32) DEFAULT NULL COMMENT '接收人员',
  `NoticeType` varchar(32) DEFAULT NULL COMMENT '通知类型（预留）',
  `Title` varchar(32) DEFAULT NULL COMMENT '标题',
  `Content` text COMMENT '内容',
  `IsRead` tinyint(1) DEFAULT NULL COMMENT '是否已读',
  `ReadTime` datetime DEFAULT NULL COMMENT '阅读时间',
  `Attachment` varchar(512) DEFAULT NULL COMMENT '附件（预留）',
  `BusiType` varchar(32) DEFAULT NULL COMMENT '业务类型',
  `BusiId` char(36) DEFAULT NULL COMMENT '业务ID',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='系统通知（审核结果）';

/*Table structure for table `tb_org_educationexperience` */

DROP TABLE IF EXISTS `tb_org_educationexperience`;

CREATE TABLE `tb_org_educationexperience` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL COMMENT '人员Id',
  `SchoolName` varchar(32) DEFAULT NULL COMMENT '学校名称',
  `MajorName` varchar(16) DEFAULT NULL COMMENT '专业名称',
  `EducationLevel` int DEFAULT NULL COMMENT '学历',
  `EducationLevelName` varchar(32) DEFAULT NULL COMMENT '学历描述',
  `EducationNature` varchar(16) DEFAULT NULL COMMENT '学历性质',
  `Degree` int DEFAULT NULL COMMENT '学位',
  `DegreeName` varchar(32) DEFAULT NULL COMMENT '学位描述',
  `StartDate` date DEFAULT NULL COMMENT '开始日期',
  `EndDate` date DEFAULT NULL COMMENT '结束日期',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='教育经历';

/*Table structure for table `tb_org_qualificationcertificate` */

DROP TABLE IF EXISTS `tb_org_qualificationcertificate`;

CREATE TABLE `tb_org_qualificationcertificate` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) NOT NULL COMMENT '人员Id',
  `QualiTypeName` varchar(32) DEFAULT NULL COMMENT '资质类型名称',
  `JobName` varchar(32) DEFAULT NULL COMMENT '职称类别名称',
  `JobLevel` varchar(32) DEFAULT NULL COMMENT '职称级别',
  `CertNo` varchar(64) DEFAULT NULL COMMENT '证书编号',
  `CertificateName` varchar(32) DEFAULT NULL COMMENT '证书名称',
  `IssuingUnit` varchar(32) DEFAULT NULL COMMENT '颁发单位',
  `StartDate` date DEFAULT NULL COMMENT '颁发日期',
  `EndDate` date DEFAULT NULL COMMENT '失效日期',
  `AnnualTime` date DEFAULT NULL COMMENT '复审有效期',
  `CertificateImg` text COMMENT '资质图片',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='资质证书';

/*Table structure for table `tb_org_rewardpunishment` */

DROP TABLE IF EXISTS `tb_org_rewardpunishment`;

CREATE TABLE `tb_org_rewardpunishment` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) NOT NULL COMMENT '人员Id',
  `RpType` int DEFAULT NULL COMMENT '1-奖 2-罚',
  `Name` varchar(32) DEFAULT NULL COMMENT '奖惩名称',
  `HappenDate` date DEFAULT NULL COMMENT '奖惩日期',
  `Comment` varchar(200) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='工作经历';

/*Table structure for table `tb_org_staffannounce` */

DROP TABLE IF EXISTS `tb_org_staffannounce`;

CREATE TABLE `tb_org_staffannounce` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL COMMENT '发送人Id',
  `StaffName` varchar(32) DEFAULT NULL COMMENT '发送人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '发送人部门',
  `Title` varchar(32) DEFAULT NULL COMMENT '标题',
  `Content` text COMMENT '内容',
  `IsSend` bit(1) DEFAULT NULL COMMENT '是否已发送',
  `SendDeptIds` varchar(2000) DEFAULT NULL COMMENT '发送部门ID',
  `SendDeptNames` varchar(2000) DEFAULT NULL,
  `IncludeChildDept` bit(1) DEFAULT NULL COMMENT '是否包含子部门',
  `Attachment` varchar(512) DEFAULT NULL COMMENT '附件',
  `Status` int DEFAULT NULL,
  `PublishTime` datetime DEFAULT NULL COMMENT '发布时间',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='公告表';

/*Table structure for table `tb_org_staffbenefits` */

DROP TABLE IF EXISTS `tb_org_staffbenefits`;

CREATE TABLE `tb_org_staffbenefits` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) NOT NULL COMMENT '人员Id',
  `AccountName` varchar(32) DEFAULT NULL COMMENT '工资账户名',
  `BankName` varchar(32) DEFAULT NULL COMMENT '工资所在银行',
  `AccountNo` varchar(32) DEFAULT NULL COMMENT '工资账号',
  `HousingFundNo` varchar(32) DEFAULT NULL COMMENT '公积金账号',
  `SocialInsureNo` varchar(32) DEFAULT NULL COMMENT '社保账号',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='薪酬福利';

/*Table structure for table `tb_org_staffcontract` */

DROP TABLE IF EXISTS `tb_org_staffcontract`;

CREATE TABLE `tb_org_staffcontract` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ScStaffId` char(36) NOT NULL COMMENT '人员Id',
  `ScSignYear` varchar(32) DEFAULT NULL COMMENT '签订时间（年）',
  `ScContractCode` varchar(50) DEFAULT NULL COMMENT '合同编号',
  `ScCompanyId` char(36) DEFAULT NULL COMMENT '签订公司ID',
  `ScCompanyName` varchar(50) DEFAULT NULL COMMENT '签订公司',
  `ScStaffCode` varchar(50) DEFAULT NULL COMMENT '员工编号',
  `ScStaffName` varchar(32) DEFAULT NULL COMMENT '姓名',
  `ScStartTime` datetime DEFAULT NULL COMMENT '合同起始',
  `ScEndTime` datetime DEFAULT NULL COMMENT '合同终止',
  `ScAmount` decimal(11,2) DEFAULT NULL COMMENT '合同金额',
  `ScDeptId` char(36) DEFAULT NULL COMMENT '部门ID',
  `ScDeptName` varchar(32) DEFAULT NULL COMMENT '部门',
  `ScJobTitleId` char(36) DEFAULT NULL COMMENT '岗位ID',
  `ScJobTitle` varchar(32) DEFAULT NULL COMMENT '岗位',
  `ScSocialBase` decimal(11,2) DEFAULT NULL COMMENT '社保基数',
  `ScHouseBase` decimal(11,2) DEFAULT NULL COMMENT '公积金基数',
  `ScReason` varchar(1000) DEFAULT NULL COMMENT '签订原因',
  `Remark` varchar(1000) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='员工劳动合同';

/*Table structure for table `tb_org_stafffamily` */

DROP TABLE IF EXISTS `tb_org_stafffamily`;

CREATE TABLE `tb_org_stafffamily` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) NOT NULL COMMENT '人员Id',
  `Relation` varchar(16) DEFAULT NULL COMMENT '家庭关系',
  `Name` varchar(16) DEFAULT NULL COMMENT '姓名',
  `Job` varchar(16) DEFAULT NULL COMMENT '职业',
  `CompanyName` varchar(32) DEFAULT NULL COMMENT '任职单位',
  `Telephone` varchar(32) DEFAULT NULL COMMENT '联系电话',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='家庭信息';

/*Table structure for table `tb_org_stafflifecycle` */

DROP TABLE IF EXISTS `tb_org_stafflifecycle`;

CREATE TABLE `tb_org_stafflifecycle` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) NOT NULL COMMENT '人员Id',
  `CompanyId` char(36) DEFAULT NULL COMMENT '公司ID',
  `LaborCompany` varchar(32) DEFAULT NULL COMMENT '劳动合同公司',
  `FaceId` varchar(100) DEFAULT NULL COMMENT '脸ID',
  `SocialCompanyId` char(36) DEFAULT NULL COMMENT '社保公司ID',
  `EducationNature` varchar(16) DEFAULT NULL COMMENT '学历性质',
  `EducationLevel2` varchar(16) DEFAULT NULL COMMENT '学历',
  `Degree2` varchar(16) DEFAULT NULL COMMENT '学位',
  `ProbationPeriod` int DEFAULT NULL COMMENT '试用期',
  `InIsGoodsReceived` bit(1) DEFAULT NULL COMMENT '入职时岗位物品是都已领',
  `InIsLeaderConfirmed` bit(1) DEFAULT NULL COMMENT '入职时部门领导是否确认',
  `OnPlanDate` date DEFAULT NULL COMMENT '计划转正日期',
  `OnRealDate` date DEFAULT NULL COMMENT '实际转正日期',
  `OnIsLeaderConfirmed` bit(1) DEFAULT NULL COMMENT '转正时领导是否同意',
  `OnComment` varchar(255) DEFAULT NULL COMMENT '转正备注',
  `OffPlanDate` date DEFAULT NULL COMMENT '计划离职日期',
  `OffRealDate` date DEFAULT NULL COMMENT '实际离职日期',
  `OffReason` varchar(128) DEFAULT NULL COMMENT '离职原因',
  `OffIsGoodsReturned` bit(1) DEFAULT NULL COMMENT '离职时岗位物品是否归还',
  `OffIsLeaderConfirmed` bit(1) DEFAULT NULL COMMENT '离职时领导是否同意',
  `IsSave` bit(1) DEFAULT NULL COMMENT '是否存档',
  `OffComment` varchar(255) DEFAULT NULL COMMENT '离职备注',
  `AnnualLeaveDays` int DEFAULT NULL COMMENT '年假天数',
  `IsSyncedTencentIM` tinyint(1) DEFAULT NULL COMMENT '是否已同步腾讯IM',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='员工入职转正离职表';

/*Table structure for table `tb_org_staffnoticehub` */

DROP TABLE IF EXISTS `tb_org_staffnoticehub`;

CREATE TABLE `tb_org_staffnoticehub` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL COMMENT '人员Id',
  `ConnectionId` varchar(50) DEFAULT NULL COMMENT 'Hub链接Id',
  `ConnectionTime` datetime DEFAULT NULL COMMENT '最近链接活跃时间点',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='人员通知表Hub';

/*Table structure for table `tb_org_staffoffapply` */

DROP TABLE IF EXISTS `tb_org_staffoffapply`;

CREATE TABLE `tb_org_staffoffapply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL COMMENT '人员Id',
  `StaffName` varchar(32) DEFAULT NULL,
  `DeptId` char(36) DEFAULT NULL,
  `DeptName` varchar(32) DEFAULT NULL,
  `Reason` varchar(200) DEFAULT NULL,
  `CancelReason` varchar(200) DEFAULT NULL,
  `ApplyTime` datetime DEFAULT NULL,
  `ApplyStatus` int DEFAULT NULL,
  `CurrentReviewerId` char(36) DEFAULT NULL,
  `CurrentReviewerIds` varchar(200) DEFAULT NULL,
  `ReviewerIds` varchar(200) DEFAULT NULL,
  `HReviewerIds` varchar(200) DEFAULT NULL COMMENT '历史痕迹审核人',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='离职申请';

/*Table structure for table `tb_org_staffoffapplydetail` */

DROP TABLE IF EXISTS `tb_org_staffoffapplydetail`;

CREATE TABLE `tb_org_staffoffapplydetail` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffOffApplyId` char(36) NOT NULL COMMENT '主表Id',
  `ReviewerId` char(36) NOT NULL COMMENT '审批人Id',
  `ReviewerName` varchar(32) DEFAULT NULL COMMENT '审批人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `IsApproved` bit(1) DEFAULT NULL COMMENT '是否同意',
  `ApproveTime` datetime DEFAULT NULL COMMENT '同意/不同意时间',
  `Comment` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `TB_Org_StaffOffAudit` */

DROP TABLE IF EXISTS `TB_Org_StaffOffAudit`;

CREATE TABLE `TB_Org_StaffOffAudit` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '人员Id',
  `InnerStaffName` varchar(32) DEFAULT NULL COMMENT '姓名',
  `InnerCompanyId` char(36) DEFAULT NULL COMMENT '公司ID',
  `InnerCompanyName` varchar(32) DEFAULT NULL COMMENT '公司',
  `InnerDeptId` char(36) DEFAULT NULL COMMENT '部门ID',
  `InnerDeptName` varchar(32) DEFAULT NULL COMMENT '部门',
  `InnerCompayType` int DEFAULT NULL COMMENT '公司类型 1-总公司 2-子公司',
  `StartDate` date DEFAULT NULL COMMENT '入职日期',
  `EndDate` date DEFAULT NULL COMMENT '离职日期',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `ReqIsDisplay` tinyint(1) DEFAULT NULL COMMENT '申请人是否可见',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='员工辞职审批';

/*Table structure for table `TB_Org_StaffRenew` */

DROP TABLE IF EXISTS `TB_Org_StaffRenew`;

CREATE TABLE `TB_Org_StaffRenew` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ReqCompanyId` char(36) DEFAULT NULL COMMENT '所属公司ID',
  `ReqCompanyName` varchar(128) DEFAULT NULL COMMENT '所属公司',
  `ReqDeptId` char(36) DEFAULT NULL COMMENT '申请部门ID',
  `ReqDeptName` varchar(128) DEFAULT NULL COMMENT '申请部门',
  `Names` varchar(1024) DEFAULT NULL COMMENT '续签名单及续签劳动合同期限',
  `NameStaffIds` text COMMENT '续签名单ID组',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `ReqIsDisplay` tinyint(1) DEFAULT NULL COMMENT '申请人是否可见',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='续签申请单';

/*Table structure for table `TB_Org_StaffRenewAudit` */

DROP TABLE IF EXISTS `TB_Org_StaffRenewAudit`;

CREATE TABLE `TB_Org_StaffRenewAudit` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '人员Id',
  `InnerStaffName` varchar(32) DEFAULT NULL COMMENT '姓名',
  `InnerCompanyId` char(36) DEFAULT NULL COMMENT '公司ID',
  `InnerCompanyName` varchar(32) DEFAULT NULL COMMENT '公司',
  `InnerDeptId` char(36) DEFAULT NULL COMMENT '部门ID',
  `InnerDeptName` varchar(32) DEFAULT NULL COMMENT '部门',
  `InnerCompayType` int DEFAULT NULL COMMENT '公司类型 1-总公司 2-子公司',
  `JobTitleId` char(36) DEFAULT NULL COMMENT '职位ID',
  `JobTitleName` varchar(32) DEFAULT NULL COMMENT '职位',
  `IDCard` varchar(40) DEFAULT NULL COMMENT '身份证号',
  `SchoolName` varchar(32) DEFAULT NULL COMMENT '学校名称',
  `Major` varchar(32) DEFAULT NULL COMMENT '专业',
  `EducationLevel` varchar(32) DEFAULT NULL COMMENT '学历',
  `Degree` varchar(100) DEFAULT NULL COMMENT '学位',
  `HomeAddress` varchar(100) DEFAULT NULL COMMENT '家庭住址',
  `LocalAddress` varchar(100) DEFAULT NULL COMMENT '在京居住地',
  `PostCode1` varchar(100) DEFAULT NULL COMMENT '邮政编码1',
  `PostCode2` varchar(100) DEFAULT NULL COMMENT '邮政编码2',
  `Certs` varchar(1024) DEFAULT NULL COMMENT '已取得相关证书',
  `StartTime` datetime DEFAULT NULL COMMENT '开始时间',
  `EndTime` datetime DEFAULT NULL COMMENT '结束时间',
  `DeptRemark` varchar(1024) DEFAULT NULL COMMENT '部门评价',
  `ReqIsDisplay` tinyint(1) DEFAULT NULL COMMENT '申请人是否可见',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='续签审批单';

/*Table structure for table `tb_org_workexperience` */

DROP TABLE IF EXISTS `tb_org_workexperience`;

CREATE TABLE `tb_org_workexperience` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) NOT NULL COMMENT '人员Id',
  `CompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称',
  `JobTitle` varchar(16) DEFAULT NULL COMMENT '职位',
  `StartDate` date DEFAULT NULL COMMENT '开始日期',
  `EndDate` date DEFAULT NULL COMMENT '结束日期',
  `Salary` int DEFAULT NULL COMMENT '薪资',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='工作经历';

/*Table structure for table `tb_proj_bidcompany` */

DROP TABLE IF EXISTS `tb_proj_bidcompany`;

CREATE TABLE `tb_proj_bidcompany` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `ReBidCompanyId` char(36) DEFAULT NULL COMMENT '投标公司ID',
  `BidCompanyName` varchar(100) DEFAULT NULL COMMENT '投标单位',
  `BidPackage` varchar(100) DEFAULT NULL COMMENT '投标包件',
  `BidAmount` decimal(18,2) DEFAULT NULL COMMENT '投标金额',
  `BidBusiStaffId` char(36) DEFAULT NULL COMMENT '商务专员ID',
  `BidBusiStaffName` varchar(32) DEFAULT NULL COMMENT '商务专员',
  `BidTechStaffId` char(36) DEFAULT NULL COMMENT '技术人员ID',
  `BidTechStaffName` varchar(32) DEFAULT NULL COMMENT '技术人员',
  `BidBuyStaffId` char(36) DEFAULT NULL COMMENT '采购人员ID',
  `BidBuyStaffName` varchar(32) DEFAULT NULL COMMENT '采购人员',
  `BidReviewStaffId` char(36) DEFAULT NULL COMMENT '终审人员ID',
  `BidReviewStaffName` varchar(32) DEFAULT NULL COMMENT '终审人员',
  `BidCompanyComment` varchar(200) DEFAULT NULL COMMENT '备注',
  `BidAttachZbgg` text COMMENT '附件招标公告',
  `BidAttachBmzl` text COMMENT '附件报名资料',
  `BidAttachBmfp` text COMMENT '附件报名发票',
  `BidAttachZbwj` text COMMENT '附件招标文件',
  `BidAttachBywj` text COMMENT '附件补遗文件',
  `BidAttachDywj` text COMMENT '附件答疑文件',
  `BidAttachTbbzj` text COMMENT '附件投标保证金',
  `BidAttachTbwj` text COMMENT '附件投标文件',
  `BidAttachZbtzs` text COMMENT '附件中标通知书',
  `BidAttachZbfwf` text COMMENT '附件中标服务费及发票',
  `BidAttachCost` text COMMENT '附件成本',
  `BidAttachCjsqzl` text COMMENT '附件厂家授权资料',
  `BidAttachKbylb` text COMMENT '附件开标一览表',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目投标单位';

/*Table structure for table `tb_proj_bidding` */

DROP TABLE IF EXISTS `tb_proj_bidding`;

CREATE TABLE `tb_proj_bidding` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Title` varchar(100) DEFAULT NULL COMMENT '招标标题',
  `BusiStaffId` char(36) DEFAULT NULL COMMENT '商务专员ID',
  `BusiStaffName` varchar(32) DEFAULT NULL COMMENT '商务专员',
  `BuySubjectId` char(36) DEFAULT NULL COMMENT '采购主体ID',
  `Company` varchar(100) DEFAULT NULL COMMENT '采购主体',
  `Unit` varchar(100) DEFAULT NULL COMMENT '招标单位',
  `Amount` decimal(18,2) DEFAULT NULL COMMENT '中标金额',
  `BuyMethod` varchar(32) DEFAULT NULL COMMENT '采购方式',
  `NoticeType` varchar(32) DEFAULT NULL COMMENT '公告类型',
  `AreaCode` varchar(150) DEFAULT NULL COMMENT '省份地区Code',
  `AreaName` varchar(150) DEFAULT NULL COMMENT '省份地区名称',
  `StartTime` datetime DEFAULT NULL COMMENT '报名开始日期',
  `EndTime` datetime DEFAULT NULL COMMENT '报名截止日期',
  `Attach` varchar(512) DEFAULT NULL COMMENT '招标附件',
  `RichText` text COMMENT '富文本',
  `InStatus` smallint DEFAULT NULL COMMENT '参与状态',
  `BiddingStatus` smallint DEFAULT NULL COMMENT '投标状态',
  `IsInOnly` bit(1) DEFAULT NULL COMMENT '该数据是否只属于参与项目',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CreateStaffId` char(36) DEFAULT NULL COMMENT '创建人ID',
  `UpdateStaffId` char(36) DEFAULT NULL COMMENT '修改人ID',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目招标';

/*Table structure for table `tb_proj_buysubject` */

DROP TABLE IF EXISTS `tb_proj_buysubject`;

CREATE TABLE `tb_proj_buysubject` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ParentSubjectId` char(36) DEFAULT NULL COMMENT '采购主体父ID',
  `SubjectName` varchar(50) DEFAULT NULL COMMENT '名称',
  `SortOrder` int DEFAULT NULL COMMENT '序号',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购主体';

/*Table structure for table `tb_proj_dailyexpense` */

DROP TABLE IF EXISTS `tb_proj_dailyexpense`;

CREATE TABLE `tb_proj_dailyexpense` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `NonDailyExpenseId` char(36) DEFAULT NULL,
  `ProjId` char(36) DEFAULT NULL,
  `ProjName` varchar(100) DEFAULT NULL COMMENT '项目名称',
  `BelongCompanyId` char(36) DEFAULT NULL COMMENT '公司Id',
  `BelongCompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称',
  `Belong` int DEFAULT NULL COMMENT '1 项目 2 非项目',
  `AgentId` char(36) DEFAULT NULL COMMENT '填写人Id',
  `Agent` varchar(32) DEFAULT NULL COMMENT '填写人',
  `ExpenseCategory` varchar(24) DEFAULT NULL COMMENT '费用类别',
  `Amount` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `IsReimbursed` tinyint(1) DEFAULT '0' COMMENT '是否已报销',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='日常费用';

/*Table structure for table `tb_proj_dailyexpenseattach` */

DROP TABLE IF EXISTS `tb_proj_dailyexpenseattach`;

CREATE TABLE `tb_proj_dailyexpenseattach` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `DailyExpenseId` char(36) DEFAULT NULL,
  `InvoiceCategory` varchar(24) DEFAULT NULL COMMENT '发票类别',
  `InvoiceCode` varchar(56) DEFAULT NULL COMMENT '发票代码',
  `InvoiceNum` varchar(56) DEFAULT NULL COMMENT '发票号码',
  `Amount` decimal(10,2) DEFAULT NULL COMMENT '发票金额',
  `FileName` varchar(128) DEFAULT NULL COMMENT '文件名称',
  `FilePath` varchar(512) DEFAULT NULL COMMENT '发票路径',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='日常费用附件';

/*Table structure for table `tb_proj_fundapply` */

DROP TABLE IF EXISTS `tb_proj_fundapply`;

CREATE TABLE `tb_proj_fundapply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `FundNature` int DEFAULT NULL COMMENT '资金性质 1 因公借用备用金 2 因项目借用备用金',
  `ApplyFundDate` date DEFAULT NULL COMMENT '申请日期',
  `ApplyCompanyId` char(36) DEFAULT NULL COMMENT '申请公司Id',
  `ApplyCompanyName` varchar(32) DEFAULT NULL COMMENT '申请公司',
  `AgentId` char(36) DEFAULT NULL COMMENT '填写人Id',
  `Agent` varchar(32) DEFAULT NULL COMMENT '填写人',
  `Amount` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `AmountCN` varchar(56) DEFAULT NULL COMMENT '金额大写',
  `State` int DEFAULT NULL COMMENT '状态 1 待发放 2 已发放 3 已退回 4 已还款',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '经办人',
  `InnerStaffName` varchar(32) DEFAULT NULL COMMENT '经办人',
  `PreReturnTime` datetime DEFAULT NULL COMMENT '预计归还日期',
  `ProcessState` int DEFAULT NULL COMMENT '办理状态 1-待发放 2-已发放 3-已退回/已还款',
  `InnerState` int DEFAULT NULL COMMENT '审核状态冗余 0-非通过 1-通过',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='备用金/专项资金';

/*Table structure for table `tb_proj_fundpayrecord` */

DROP TABLE IF EXISTS `tb_proj_fundpayrecord`;

CREATE TABLE `tb_proj_fundpayrecord` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `FundApplyId` char(36) DEFAULT NULL COMMENT '备用金/专项资金Id',
  `PayTime` datetime DEFAULT NULL COMMENT '付款日期',
  `PayWay` int DEFAULT NULL COMMENT '付款方式 1 现金 2 支票',
  `CheckNo` varchar(32) DEFAULT NULL COMMENT '支票号',
  `VoucherNo` varchar(32) DEFAULT NULL COMMENT '凭单号',
  `PayAmount` decimal(10,2) DEFAULT NULL COMMENT '支付金额',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='备用金/专项资金付款记录';

/*Table structure for table `tb_proj_invoicecompany` */

DROP TABLE IF EXISTS `tb_proj_invoicecompany`;

CREATE TABLE `tb_proj_invoicecompany` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `CompanyName` varchar(50) DEFAULT NULL COMMENT '单位名称',
  `InvoiceType` varchar(32) DEFAULT NULL COMMENT '发票种类',
  `TaxRate` varchar(32) DEFAULT NULL COMMENT '税率',
  `TaxNo` varchar(32) DEFAULT NULL COMMENT '税号',
  `PlanCollectTime` datetime DEFAULT NULL COMMENT '预计收款时间',
  `Telephone` varchar(32) DEFAULT NULL COMMENT '电话',
  `Address` varchar(100) DEFAULT NULL COMMENT '地址',
  `Bank` varchar(100) DEFAULT NULL COMMENT '开户行',
  `BankAccount` varchar(32) DEFAULT NULL COMMENT '帐号',
  `FinanceProjectName` varchar(128) DEFAULT NULL COMMENT '财务立项',
  `SellContractCode` varchar(50) DEFAULT NULL COMMENT '销售合同编号',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='开票单位';

/*Table structure for table `tb_proj_nondailyexpense` */

DROP TABLE IF EXISTS `tb_proj_nondailyexpense`;

CREATE TABLE `tb_proj_nondailyexpense` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjId` char(36) DEFAULT NULL,
  `ProjName` varchar(100) DEFAULT NULL COMMENT '项目名称',
  `BelongCompanyId` char(36) DEFAULT NULL COMMENT '公司Id',
  `BelongCompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称',
  `Belong` int DEFAULT NULL COMMENT '1 项目 2 非项目',
  `AgentId` char(36) DEFAULT NULL COMMENT '填写人Id',
  `Agent` varchar(32) DEFAULT NULL COMMENT '填写人',
  `ExpenseCategory` varchar(24) DEFAULT NULL COMMENT '费用类别',
  `InvoiceCategory` varchar(24) DEFAULT NULL COMMENT '发票类别',
  `Amount` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='非日常费用';

/*Table structure for table `tb_proj_outstock` */

DROP TABLE IF EXISTS `tb_proj_outstock`;

CREATE TABLE `tb_proj_outstock` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `ReqInvoiceId` char(36) DEFAULT NULL COMMENT '开票ID',
  `OutStockCode` varchar(50) DEFAULT NULL COMMENT '出库单号',
  `OutStockTime` datetime DEFAULT NULL COMMENT '出库日期',
  `AuditTime` datetime DEFAULT NULL COMMENT '审核日期',
  `CustomerName` varchar(50) DEFAULT NULL COMMENT '单位名称/销售甲方名称',
  `SecondName` varchar(50) DEFAULT NULL COMMENT '乙方单位',
  `Amount` decimal(11,2) DEFAULT NULL COMMENT '开票金额',
  `AmountUnit` varchar(32) DEFAULT NULL COMMENT '开票金额单位',
  `HandStaffId` char(36) DEFAULT NULL COMMENT '经办人ID',
  `HandStaffName` varchar(50) DEFAULT NULL COMMENT '经办人',
  `KeepStaffId` char(36) DEFAULT NULL COMMENT '保管人ID',
  `KeepStaffName` varchar(50) DEFAULT NULL COMMENT '保管人',
  `FinaStaffId` char(36) DEFAULT NULL COMMENT '会计ID',
  `FinaStaffName` varchar(50) DEFAULT NULL COMMENT '会计',
  `Attach` varchar(1024) DEFAULT NULL COMMENT '附件',
  `CreateType` int DEFAULT NULL COMMENT '创建类型 1-自动 2-手动',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='出库';

/*Table structure for table `tb_proj_outstockitem` */

DROP TABLE IF EXISTS `tb_proj_outstockitem`;

CREATE TABLE `tb_proj_outstockitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractItemId` char(36) DEFAULT NULL COMMENT '销售合同明细ID',
  `OutStockId` char(36) DEFAULT NULL COMMENT '出库ID',
  `ReqInvoiceItemId` char(36) DEFAULT NULL COMMENT '开票明细ID',
  `PssManageId` char(36) DEFAULT NULL COMMENT '购销存ID',
  `Seq` varchar(32) DEFAULT NULL COMMENT '序号',
  `MaterialType` int DEFAULT NULL COMMENT '物资类型 1-正常 2-配件 3-额外采购',
  `PreId` char(36) DEFAULT NULL COMMENT '购物车明细ID（上一步）',
  `PreParentId` char(36) DEFAULT NULL COMMENT '购物车明细父ID（上一步）',
  `TaxCategory` varchar(100) DEFAULT NULL COMMENT '税收类别',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `MaterialParams` varchar(128) DEFAULT NULL COMMENT '参数要求',
  `MaterialPrice` decimal(18,2) DEFAULT NULL COMMENT '单价',
  `SubTotal` decimal(18,2) DEFAULT NULL COMMENT '小计',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='出库明细';

/*Table structure for table `tb_proj_proj` */

DROP TABLE IF EXISTS `tb_proj_proj`;

CREATE TABLE `tb_proj_proj` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(32) DEFAULT NULL,
  `Code` varchar(32) DEFAULT NULL,
  `DutyStaffId` char(36) DEFAULT NULL,
  `DutyStaffName` varchar(32) DEFAULT NULL,
  `ZsInfo` varchar(200) DEFAULT NULL,
  `TbInfo` varchar(300) DEFAULT NULL,
  `ProjContractId` char(36) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `ProjAddress` varchar(200) DEFAULT NULL,
  `ProjNature` varchar(200) DEFAULT NULL COMMENT '工程性质',
  `BuildUnit` varchar(200) DEFAULT NULL,
  `QualityUnit` varchar(200) DEFAULT NULL,
  `DesignUnit` varchar(200) DEFAULT NULL,
  `ContractUnit` varchar(200) DEFAULT NULL,
  `QualityLevel` varchar(200) DEFAULT NULL,
  `ProjAmount` decimal(18,2) DEFAULT NULL,
  `RealStartTime` datetime DEFAULT NULL,
  `RealEndTime` datetime DEFAULT NULL,
  `ProjScale` varchar(32) DEFAULT NULL COMMENT '工程规模',
  `ProjIncType` int DEFAULT NULL COMMENT '工程收款方式 1-时间进度 2-工程进度',
  `HtTotalAmount` decimal(18,2) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目';

/*Table structure for table `tb_proj_projbudget` */

DROP TABLE IF EXISTS `tb_proj_projbudget`;

CREATE TABLE `tb_proj_projbudget` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjId` char(36) NOT NULL,
  `TimeRange` datetime DEFAULT NULL,
  `StaffBudget` decimal(18,2) DEFAULT NULL,
  `OtherBudget` decimal(18,2) DEFAULT NULL,
  `ProjIncome` decimal(18,2) DEFAULT NULL,
  `ProjProfit` decimal(18,2) DEFAULT NULL,
  `Attach` varchar(300) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  `Column_15` char(10) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目预算';

/*Table structure for table `tb_proj_projbudgetother` */

DROP TABLE IF EXISTS `tb_proj_projbudgetother`;

CREATE TABLE `tb_proj_projbudgetother` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjBudgetId` char(36) DEFAULT NULL,
  `ProjId` char(36) DEFAULT NULL,
  `TimeRange` datetime DEFAULT NULL,
  `Name` varchar(32) DEFAULT NULL,
  `Total` decimal(18,2) DEFAULT NULL,
  `Comment` varchar(200) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目其他预算';

/*Table structure for table `tb_proj_projbudgetstaff` */

DROP TABLE IF EXISTS `tb_proj_projbudgetstaff`;

CREATE TABLE `tb_proj_projbudgetstaff` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjBudgetId` char(36) DEFAULT NULL,
  `ProjId` char(36) DEFAULT NULL,
  `TimeRange` datetime DEFAULT NULL,
  `JobTitleId` char(36) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `PerSalaryInsurance` decimal(18,2) DEFAULT NULL,
  `PerMealAmount` decimal(18,2) DEFAULT NULL,
  `SumSalaryInsurance` decimal(18,2) DEFAULT NULL,
  `SumMealAmount` decimal(18,2) DEFAULT NULL,
  `Total` decimal(18,2) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目人员预算';

/*Table structure for table `tb_proj_projcontract` */

DROP TABLE IF EXISTS `tb_proj_projcontract`;

CREATE TABLE `tb_proj_projcontract` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(32) DEFAULT NULL,
  `Code` varchar(32) DEFAULT NULL,
  `Type` int DEFAULT NULL,
  `ParentProjContractId` char(36) DEFAULT NULL,
  `ProjId` char(36) DEFAULT NULL,
  `ContractAmount` decimal(11,2) DEFAULT NULL,
  `ContractQty` int DEFAULT NULL,
  `ContractTime` datetime DEFAULT NULL,
  `ContractAttch` text,
  `ContractAttchTime` datetime DEFAULT NULL,
  `ContractBusi` varchar(500) DEFAULT NULL,
  `ContractBusiAttch` text,
  `ContractTech` varchar(500) DEFAULT NULL,
  `ContractTechAttch` text,
  `HtStartTime` datetime DEFAULT NULL,
  `HtEndTime` datetime DEFAULT NULL,
  `BidTime` datetime DEFAULT NULL,
  `BidStaffId` char(36) DEFAULT NULL,
  `BidStaffName` varchar(32) DEFAULT NULL,
  `BidQty` int DEFAULT NULL,
  `BidAmount` decimal(11,2) DEFAULT NULL,
  `BidNoticeAttach` text,
  `BidKeepStaffId` char(36) DEFAULT NULL,
  `BidKeepStaffName` varchar(32) DEFAULT NULL,
  `InvoiceAmount` decimal(11,2) DEFAULT NULL,
  `ReceiveAmount` decimal(11,2) DEFAULT NULL,
  `LeftContractAmout` decimal(11,2) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='合同';

/*Table structure for table `tb_proj_projcontractrel` */

DROP TABLE IF EXISTS `tb_proj_projcontractrel`;

CREATE TABLE `tb_proj_projcontractrel` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjId` char(36) DEFAULT NULL,
  `ProjContractId` char(36) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目、合同关系表（一对多）';

/*Table structure for table `tb_proj_projcost` */

DROP TABLE IF EXISTS `tb_proj_projcost`;

CREATE TABLE `tb_proj_projcost` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjId` char(36) NOT NULL,
  `TimeRange` datetime DEFAULT NULL,
  `StaffCost` decimal(18,2) DEFAULT NULL,
  `OtherCost` decimal(18,2) DEFAULT NULL,
  `ProjIncome` decimal(18,2) DEFAULT NULL,
  `ProjProfit` decimal(18,2) DEFAULT NULL,
  `Attach` varchar(300) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目成本';

/*Table structure for table `tb_proj_projcostother` */

DROP TABLE IF EXISTS `tb_proj_projcostother`;

CREATE TABLE `tb_proj_projcostother` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjCostId` char(36) DEFAULT NULL,
  `ProjId` char(36) NOT NULL,
  `TimeRange` datetime DEFAULT NULL,
  `Name` varchar(32) DEFAULT NULL,
  `Total` decimal(18,2) DEFAULT NULL,
  `Comment` varchar(200) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目其他成本';

/*Table structure for table `tb_proj_projcoststaff` */

DROP TABLE IF EXISTS `tb_proj_projcoststaff`;

CREATE TABLE `tb_proj_projcoststaff` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjCostId` char(36) DEFAULT NULL,
  `ProjId` char(36) DEFAULT NULL,
  `StaffId` char(36) DEFAULT NULL,
  `StaffName` varchar(32) DEFAULT NULL,
  `DeptId` char(36) DEFAULT NULL,
  `DeptName` varchar(32) DEFAULT NULL,
  `Mobile` varchar(32) DEFAULT NULL,
  `TimeRange` datetime DEFAULT NULL,
  `ControlSalary` decimal(18,2) DEFAULT NULL COMMENT '工资控制标准',
  `BasicSalary` decimal(18,2) DEFAULT NULL COMMENT '基本工资',
  `JobTitleSalary` decimal(18,2) DEFAULT NULL COMMENT '岗位工资',
  `BenefitSalary` decimal(18,2) DEFAULT NULL COMMENT '效益工资',
  `WorkSalary` decimal(18,2) DEFAULT NULL COMMENT '考勤工资',
  `PunishAmount` decimal(18,2) DEFAULT NULL COMMENT '罚款',
  `MealAmount` decimal(18,2) DEFAULT NULL COMMENT '餐补',
  `BxStandard` decimal(18,2) DEFAULT NULL COMMENT '基本报销标准',
  `BxBalance` decimal(18,2) DEFAULT NULL COMMENT '当月报销余额',
  `BxAmount` decimal(18,2) DEFAULT NULL COMMENT '当月实际报销',
  `BxReward` decimal(18,2) DEFAULT NULL COMMENT '奖励报销',
  `BxRewardComment` varchar(200) DEFAULT NULL COMMENT '奖励报销备注',
  `BxOther` decimal(18,2) DEFAULT NULL COMMENT '其他报销',
  `BxAvailable` decimal(18,2) DEFAULT NULL COMMENT '本月可报销额度',
  `Total1` decimal(18,2) DEFAULT NULL,
  `Total2` decimal(18,2) DEFAULT NULL,
  `ComSocialAmount` decimal(18,2) DEFAULT NULL COMMENT '社保（公司承担）',
  `ComHouseAmount` decimal(18,2) DEFAULT NULL COMMENT '公积金（公司承担）',
  `ComYearAmount` decimal(18,2) DEFAULT NULL COMMENT '年金（公司承担）',
  `StaffSocialAmount` decimal(18,2) DEFAULT NULL COMMENT '社保（个人承担）',
  `StaffHouseAmount` decimal(18,2) DEFAULT NULL COMMENT '公积金（个人承担）',
  `StaffYearAmount` decimal(18,2) DEFAULT NULL COMMENT '年金（个人承担）',
  `StaffTaxAmount` decimal(18,2) DEFAULT NULL COMMENT '个人所得税',
  `ShouldSalary` decimal(18,2) DEFAULT NULL COMMENT '本月应发',
  `RealSalary` decimal(18,2) DEFAULT NULL COMMENT '本月实发',
  `ReserveSalary` decimal(18,2) DEFAULT NULL COMMENT '本月预留',
  `Total` decimal(18,2) DEFAULT NULL COMMENT '人工成本合计',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目人员成本';

/*Table structure for table `tb_proj_projcredit` */

DROP TABLE IF EXISTS `tb_proj_projcredit`;

CREATE TABLE `tb_proj_projcredit` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `ReqCompany` varchar(50) DEFAULT NULL COMMENT '申请单位',
  `OppCompany` varchar(50) DEFAULT NULL COMMENT '对方公司',
  `PlanTime` datetime DEFAULT NULL COMMENT '预期日期',
  `BusiStaffId` char(36) DEFAULT NULL COMMENT '业务申请人ID',
  `BusiStaffName` varchar(32) DEFAULT NULL COMMENT '业务申请人',
  `FinaStaffId` char(36) DEFAULT NULL COMMENT '财务经办人ID',
  `FinaStaffName` varchar(32) DEFAULT NULL COMMENT '财务经办人',
  `FinaTime` datetime DEFAULT NULL COMMENT '财务经办时间',
  `FinaStatus` int DEFAULT NULL COMMENT '财务经办状态',
  `SpecialReq` varchar(200) DEFAULT NULL COMMENT '其他特殊要求',
  `Attach` varchar(512) DEFAULT NULL COMMENT '附件',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CreateStaffId` char(36) DEFAULT NULL COMMENT '创建人ID',
  `UpdateStaffId` char(36) DEFAULT NULL COMMENT '修改人ID',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '申请人',
  `InnerStaffName` varchar(32) DEFAULT NULL COMMENT '申请人',
  `ReturnTime` datetime DEFAULT NULL COMMENT '实际退回时间',
  `ProcessType` int DEFAULT NULL COMMENT '办理状态 1-待发放 2-已发放 3-已退回/已还款',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目资信';

/*Table structure for table `tb_proj_projdoclend` */

DROP TABLE IF EXISTS `tb_proj_projdoclend`;

CREATE TABLE `tb_proj_projdoclend` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `DocId` varchar(4000) DEFAULT NULL COMMENT '资料ID组(该ID比较特殊)',
  `DocType` int DEFAULT NULL COMMENT '资料类型 1-财务 2-综合 3-财务综合',
  `Name` varchar(4000) DEFAULT NULL COMMENT '资料名称',
  `UseDeptId` char(36) DEFAULT NULL COMMENT '使用部门ID',
  `UseDeptName` varchar(32) DEFAULT NULL COMMENT '使用部门',
  `LendTime` datetime DEFAULT NULL COMMENT '借阅日期',
  `LendMethod` varchar(32) DEFAULT NULL COMMENT '借阅方式',
  `LendCount` int DEFAULT NULL COMMENT '份数',
  `Purpose` varchar(32) DEFAULT NULL COMMENT '用途',
  `CcIds` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `LendStatus` int DEFAULT NULL COMMENT '借阅状态: 1-无 2-待借出 3-已借出 4-已归还',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CreateStaffId` char(36) DEFAULT NULL COMMENT '创建人ID',
  `UpdateStaffId` char(36) DEFAULT NULL COMMENT '修改人ID',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '申请人',
  `InnerStaffName` varchar(32) DEFAULT NULL COMMENT '申请人',
  `InnerState` int DEFAULT NULL COMMENT '状态 0-非通过 1-通过',
  `ReturnTime` datetime DEFAULT NULL COMMENT '实际归还时间',
  `PreReturnTime` datetime DEFAULT NULL COMMENT '预计归还时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目原件借阅';

/*Table structure for table `tb_proj_project` */

DROP TABLE IF EXISTS `tb_proj_project`;

CREATE TABLE `tb_proj_project` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BiddingId` char(36) DEFAULT NULL COMMENT '项目招标ID',
  `Code` varchar(32) DEFAULT NULL COMMENT '项目编号',
  `FullName` varchar(100) DEFAULT NULL COMMENT '项目名称',
  `ShortName` varchar(100) DEFAULT NULL COMMENT '项目名称',
  `DutyStaffId` char(36) DEFAULT NULL COMMENT '项目负责人ID',
  `DutyStaffName` varchar(32) DEFAULT NULL COMMENT '项目负责人',
  `BusiStaffId` char(36) DEFAULT NULL COMMENT '商务负责人ID',
  `BusiStaffName` varchar(32) DEFAULT NULL COMMENT '商务负责人',
  `OpenTime` datetime DEFAULT NULL COMMENT '开标时间',
  `OpenAddress` varchar(150) DEFAULT NULL COMMENT '开标地点',
  `BidStatus` int DEFAULT NULL COMMENT '投标状态',
  `BidCompanyId` char(36) DEFAULT NULL COMMENT '项目投标单位ID/项目明细ID',
  `ReBidCompanyId` char(36) DEFAULT NULL COMMENT '投标公司ID',
  `WinBidCompanyName` varchar(50) DEFAULT NULL COMMENT '中标单位',
  `BidCompanyBusiStaffIds` varchar(2000) DEFAULT NULL COMMENT '投标公司的商务专员数组（冗余字段）',
  `ProjStaffId` char(36) DEFAULT NULL COMMENT '投标文件项目经理ID',
  `ProjStaffName` varchar(32) DEFAULT NULL COMMENT '投标文件项目经理',
  `TechStaffId` char(36) DEFAULT NULL COMMENT '投标文件技术负责人ID',
  `TechStaffName` varchar(32) DEFAULT NULL COMMENT '投标文件技术负责人',
  `StartTime` datetime DEFAULT NULL COMMENT '开工日期',
  `EndTime` datetime DEFAULT NULL COMMENT '竣工日期',
  `BidComment` varchar(200) DEFAULT NULL COMMENT '投标备注',
  `WinBidComment` varchar(200) DEFAULT NULL COMMENT '中标备注',
  `IsWinBidOnly` bit(1) DEFAULT NULL COMMENT '该数据是否只属于中标',
  `CreateStaffId` char(36) DEFAULT NULL COMMENT '创建人ID',
  `UpdateStaffId` char(36) DEFAULT NULL COMMENT '修改人ID',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目';

/*Table structure for table `tb_proj_projectbudget` */

DROP TABLE IF EXISTS `tb_proj_projectbudget`;

CREATE TABLE `tb_proj_projectbudget` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `ProjectNature` int DEFAULT NULL COMMENT '项目性质',
  `BudgetAmount` decimal(18,2) DEFAULT NULL COMMENT '项目概算',
  `TotalAmount` decimal(18,2) DEFAULT NULL COMMENT '往来款合计',
  `RecvAmount` decimal(18,2) DEFAULT NULL COMMENT '收款金额合计',
  `PayAmount` decimal(18,2) DEFAULT NULL COMMENT '付款金额合计',
  `Balance` decimal(18,2) DEFAULT NULL COMMENT '余额',
  `MainContractAmount` decimal(18,2) DEFAULT NULL COMMENT '主合同金额',
  `SubContractAmount` decimal(18,2) DEFAULT NULL COMMENT '补充合同金额',
  `ContractTotal` decimal(18,2) DEFAULT NULL COMMENT '合同金额合计',
  `DeviceFee` decimal(18,2) DEFAULT NULL COMMENT '设备费',
  `ConstructFee` decimal(18,2) DEFAULT NULL COMMENT '施工费',
  `MaterialFee` decimal(18,2) DEFAULT NULL COMMENT '材料费',
  `TechFee` decimal(18,2) DEFAULT NULL COMMENT '技术服务费',
  `ProjectTax` decimal(18,2) DEFAULT NULL COMMENT '工程项目税金',
  `PrintTax` decimal(18,2) DEFAULT NULL COMMENT '印花税金',
  `CurculationTax` decimal(18,2) DEFAULT NULL COMMENT '流转税金',
  `ManageFee` decimal(18,2) DEFAULT NULL COMMENT '管理费',
  `OtherFee` decimal(18,2) DEFAULT NULL COMMENT '其他费',
  `TotalFee` decimal(18,2) DEFAULT NULL COMMENT '合计',
  `RealDeviceFee` decimal(18,2) DEFAULT NULL COMMENT '设备费',
  `RealConstructFee` decimal(18,2) DEFAULT NULL COMMENT '施工费',
  `RealMaterialFee` decimal(18,2) DEFAULT NULL COMMENT '材料费',
  `RealTechFee` decimal(18,2) DEFAULT NULL COMMENT '技术服务费',
  `RealPrintTax` decimal(18,2) DEFAULT NULL COMMENT '工程项目税金',
  `RealProjectTax` decimal(18,2) DEFAULT NULL COMMENT '工程项目税金',
  `RealCurculationTax` decimal(18,2) DEFAULT NULL COMMENT '流转税金',
  `RealManageFee` decimal(18,2) DEFAULT NULL COMMENT '管理费',
  `RealOtherFee` decimal(18,2) DEFAULT NULL COMMENT '其他费',
  `RealTotalFee` decimal(18,2) DEFAULT NULL COMMENT '合计',
  `ProjectProfit` decimal(18,2) DEFAULT NULL COMMENT '项目利润',
  `ProjectProfitPercent` varchar(32) DEFAULT NULL COMMENT '项目利润率',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CreateStaffId` char(36) DEFAULT NULL COMMENT '创建人ID',
  `UpdateStaffId` char(36) DEFAULT NULL COMMENT '修改人ID',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目收付款预算';

/*Table structure for table `tb_proj_projectext` */

DROP TABLE IF EXISTS `tb_proj_projectext`;

CREATE TABLE `tb_proj_projectext` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `AttachCustomer` varchar(1024) DEFAULT NULL COMMENT '附件甲方信息',
  `AttachZbtzs` text COMMENT '附件中标通知书',
  `AttachLybh` varchar(1024) DEFAULT NULL COMMENT '附件履约保函',
  `AttachKgbgwj` varchar(1024) DEFAULT NULL COMMENT '附件开工报告文件',
  `AttachSjbgwj` varchar(1024) DEFAULT NULL COMMENT '附件设计变更文件',
  `AttachXmbywj` varchar(1024) DEFAULT NULL COMMENT '附件项目报验文件',
  `AttachYgjj` varchar(1024) DEFAULT NULL COMMENT '附件验工计价',
  `AttachJgyswj` varchar(1024) DEFAULT NULL COMMENT '附件竣工验收文件',
  `AttachDagyjwj` varchar(1024) DEFAULT NULL COMMENT '附件档案管移交文件',
  `AttachGchthj` varchar(1024) DEFAULT NULL COMMENT '附件过程红头函件',
  `AttachWzht` varchar(1024) DEFAULT NULL COMMENT '附件物资合同',
  `AttachKpsqd` varchar(1024) DEFAULT NULL COMMENT '附件开票申请单',
  `AttachInvoice` varchar(1024) DEFAULT NULL COMMENT '附件发票',
  `AttachWzhtqd` varchar(1024) DEFAULT NULL COMMENT '附件物资合同清单',
  `IsWzhtqdMapping` bit(1) DEFAULT NULL COMMENT '物资合同清单是否已字段映射',
  `ItemsJson` text COMMENT '销售合同明细json',
  `FieldMappingJson` varchar(1024) DEFAULT NULL COMMENT '字段映射关系Json',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目扩展';

/*Table structure for table `tb_proj_projincapply` */

DROP TABLE IF EXISTS `tb_proj_projincapply`;

CREATE TABLE `tb_proj_projincapply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjId` char(36) DEFAULT NULL,
  `ProjContractId` char(36) DEFAULT NULL,
  `StaffId` char(36) DEFAULT NULL,
  `StaffName` varchar(32) DEFAULT NULL,
  `Mobile` varchar(32) DEFAULT NULL,
  `DeptName` varchar(32) DEFAULT NULL,
  `Amount` decimal(11,2) DEFAULT NULL,
  `Progress` varchar(32) DEFAULT NULL,
  `Content` text,
  `Reason` varchar(200) DEFAULT NULL,
  `ApplyStatus` int DEFAULT NULL,
  `ApplyTime` datetime DEFAULT NULL,
  `CurrentReviewerId` char(36) DEFAULT NULL,
  `CurrentReviewerIds` varchar(200) DEFAULT NULL,
  `ReviewerIds` varchar(200) DEFAULT NULL,
  `HReviewerIds` varchar(200) DEFAULT NULL COMMENT '历史痕迹审核人',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目收入申请';

/*Table structure for table `tb_proj_projincapplydetail` */

DROP TABLE IF EXISTS `tb_proj_projincapplydetail`;

CREATE TABLE `tb_proj_projincapplydetail` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjIncApplyId` char(36) NOT NULL COMMENT '主表Id',
  `ReviewerId` char(36) NOT NULL COMMENT '审批人Id',
  `ReviewerName` varchar(32) DEFAULT NULL COMMENT '审批人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `IsApproved` bit(1) DEFAULT NULL COMMENT '是否同意',
  `ApproveTime` datetime DEFAULT NULL COMMENT '同意/不同意时间',
  `Comment` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_proj_projincfinance` */

DROP TABLE IF EXISTS `tb_proj_projincfinance`;

CREATE TABLE `tb_proj_projincfinance` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjIncInvoiceId` char(36) DEFAULT NULL COMMENT '主表Id',
  `RealReceiveTime` datetime DEFAULT NULL,
  `RealReceiveAmount` decimal(18,2) DEFAULT NULL,
  `Comment` varchar(200) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_proj_projincinvoice` */

DROP TABLE IF EXISTS `tb_proj_projincinvoice`;

CREATE TABLE `tb_proj_projincinvoice` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjContractId` char(36) DEFAULT NULL,
  `ProjId` char(36) DEFAULT NULL,
  `StaffId` char(36) DEFAULT NULL,
  `StaffName` varchar(32) DEFAULT NULL,
  `Mobile` varchar(32) DEFAULT NULL,
  `DeptName` varchar(32) DEFAULT NULL,
  `Amount` decimal(18,2) DEFAULT NULL,
  `Reason` varchar(200) DEFAULT NULL,
  `ApplyStatus` int DEFAULT NULL,
  `ApplyTime` datetime DEFAULT NULL,
  `ReceiveStaffId` char(36) DEFAULT NULL,
  `ReceiveDeptName` varchar(32) DEFAULT NULL,
  `ReceiveTime` datetime DEFAULT NULL,
  `CurrentReviewerId` char(36) DEFAULT NULL,
  `CurrentReviewerIds` varchar(200) DEFAULT NULL,
  `ReviewerIds` varchar(200) DEFAULT NULL,
  `HReviewerIds` varchar(200) DEFAULT NULL COMMENT '历史痕迹审核人',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目开票申请';

/*Table structure for table `tb_proj_projincinvoicedetail` */

DROP TABLE IF EXISTS `tb_proj_projincinvoicedetail`;

CREATE TABLE `tb_proj_projincinvoicedetail` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjIncInvoiceId` char(36) DEFAULT NULL COMMENT '主表Id',
  `ReviewerId` char(36) DEFAULT NULL COMMENT '审批人Id',
  `ReviewerName` varchar(32) DEFAULT NULL COMMENT '审批人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `IsApproved` bit(1) DEFAULT NULL COMMENT '是否同意',
  `ApproveTime` datetime DEFAULT NULL COMMENT '同意/不同意时间',
  `Comment` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_proj_projitem` */

DROP TABLE IF EXISTS `tb_proj_projitem`;

CREATE TABLE `tb_proj_projitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjId` char(36) DEFAULT NULL,
  `Name` varchar(32) DEFAULT NULL,
  `Area` decimal(18,1) DEFAULT NULL,
  `StructType` varchar(32) DEFAULT NULL,
  `FloorQty` decimal(18,1) DEFAULT NULL,
  `Height` decimal(18,3) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目(子表)';

/*Table structure for table `tb_proj_projprogress` */

DROP TABLE IF EXISTS `tb_proj_projprogress`;

CREATE TABLE `tb_proj_projprogress` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL,
  `StaffName` varchar(32) DEFAULT NULL,
  `Mobile` varchar(32) DEFAULT NULL,
  `DeptName` varchar(32) DEFAULT NULL,
  `ProjId` char(36) DEFAULT NULL,
  `ProjIncType` int DEFAULT NULL,
  `NodeName` varchar(80) DEFAULT NULL,
  `TimeValue` datetime DEFAULT NULL,
  `NameValue` varchar(80) DEFAULT NULL,
  `Reason` varchar(200) DEFAULT NULL,
  `SortOrder` int DEFAULT NULL,
  `PlanReceiveTime` datetime DEFAULT NULL,
  `PlanReceiveAmount` decimal(18,2) DEFAULT NULL,
  `ApplyTime` datetime DEFAULT NULL,
  `ApplyStatus` int DEFAULT NULL,
  `CurApplyConfigItemId` char(36) DEFAULT NULL,
  `CurReviewerIds` varchar(2000) DEFAULT NULL COMMENT '下一个审核人组（无论ApplyConfigItem节点中配置的是角色、部门，其实最终都是配置哪些人）',
  `ReviewerIds` varchar(2000) DEFAULT NULL COMMENT '已审核过的人们（逗号分隔）（退回后会缩短）',
  `HReviewerIds` varchar(2000) DEFAULT NULL COMMENT '历史痕迹审核人（不会缩短）（后期可以设想把NextReviewerIds全部填入该字段，意味着所有涉及到的人员都可以查看）',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目进度';

/*Table structure for table `tb_proj_projprogressdetail` */

DROP TABLE IF EXISTS `tb_proj_projprogressdetail`;

CREATE TABLE `tb_proj_projprogressdetail` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ApplyId` char(36) DEFAULT NULL COMMENT '主表Id',
  `ReviewerId` char(36) DEFAULT NULL COMMENT '审批人Id',
  `ReviewerName` varchar(32) DEFAULT NULL COMMENT '审批人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `IsApproved` bit(1) DEFAULT NULL COMMENT '是否同意',
  `ApproveTime` datetime DEFAULT NULL COMMENT '同意/不同意时间',
  `Comment` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `TB_Proj_ProjRegister` */

DROP TABLE IF EXISTS `TB_Proj_ProjRegister`;

CREATE TABLE `TB_Proj_ProjRegister` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `InCompany` varchar(100) DEFAULT NULL COMMENT '收款单位',
  `PayMethod` varchar(32) DEFAULT NULL COMMENT '支出类型',
  `PayAmount` decimal(18,2) DEFAULT NULL COMMENT '支出金额',
  `EmergencyType` varchar(32) DEFAULT NULL COMMENT '紧急类型',
  `PayTime` datetime DEFAULT NULL COMMENT '申请日期',
  `DrawStaffId` char(36) DEFAULT NULL COMMENT '领款人ID',
  `DrawStaff` varchar(32) DEFAULT NULL COMMENT '领款人',
  `HandStaffId` char(36) DEFAULT NULL COMMENT '经办人ID',
  `HandStaff` varchar(32) DEFAULT NULL COMMENT '经办人',
  `Attach` varchar(1024) DEFAULT NULL COMMENT '报名支出附件',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CreateStaffId` char(36) DEFAULT NULL COMMENT '创建人ID',
  `UpdateStaffId` char(36) DEFAULT NULL COMMENT '修改人ID',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  `ReturnTime` datetime DEFAULT NULL COMMENT '实际退回时间',
  `ProcessType` int DEFAULT NULL COMMENT '办理状态 1-待发放 2-已发放 3-已退回/已还款',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '申请人',
  `InnerStaffName` varchar(32) DEFAULT NULL COMMENT '申请人',
  `InnerState` int DEFAULT NULL COMMENT '申请状态冗余 0-未通过 1-已通过',
  `CollectAccount` varchar(32) DEFAULT NULL COMMENT '收款账号',
  `LatestPayDate` datetime DEFAULT NULL COMMENT '最晚付款日期',
  `OpenBank` varchar(100) DEFAULT NULL COMMENT '开户行',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目报名（报名费/投标保证金）';

/*Table structure for table `tb_proj_projstaff` */

DROP TABLE IF EXISTS `tb_proj_projstaff`;

CREATE TABLE `tb_proj_projstaff` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjId` char(36) DEFAULT NULL,
  `StaffId` char(36) DEFAULT NULL,
  `StaffName` varchar(32) DEFAULT NULL,
  `DeptId` char(36) DEFAULT NULL,
  `DeptName` varchar(32) DEFAULT NULL,
  `Mobile` varchar(32) DEFAULT NULL,
  `InTime` datetime DEFAULT NULL,
  `OutTime` datetime DEFAULT NULL,
  `TotalDays` decimal(18,1) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目人员';

/*Table structure for table `tb_proj_projtimeprogress` */

DROP TABLE IF EXISTS `tb_proj_projtimeprogress`;

CREATE TABLE `tb_proj_projtimeprogress` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjId` char(36) DEFAULT NULL,
  `ReceiveCount` int DEFAULT NULL,
  `PlanReceiveTime` datetime DEFAULT NULL,
  `PlanReceiveAmount` decimal(18,2) DEFAULT NULL,
  `SortOrder` int DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='时间进度';

/*Table structure for table `tb_proj_pssmanage` */

DROP TABLE IF EXISTS `tb_proj_pssmanage`;

CREATE TABLE `tb_proj_pssmanage` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Seq` int DEFAULT NULL COMMENT '序号',
  `AccTime` datetime DEFAULT NULL COMMENT '统计年月',
  `InStockTime` datetime DEFAULT NULL COMMENT '入库日期',
  `ProjectId` char(36) NOT NULL COMMENT '项目ID',
  `ProjectName` varchar(100) DEFAULT NULL COMMENT '项目名称',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractItemId` char(36) NOT NULL COMMENT '销售合同明细ID',
  `PreId` char(36) DEFAULT NULL COMMENT '灵魂ID（上一步）',
  `PreParentId` char(36) DEFAULT NULL COMMENT '灵魂父ID（上一步）',
  `SupplyId` char(36) DEFAULT NULL COMMENT '供应商ID',
  `SupplyName` varchar(100) DEFAULT NULL COMMENT '供应商',
  `CustomerName` varchar(100) DEFAULT NULL COMMENT '甲方名称',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialParams` varchar(4096) DEFAULT NULL COMMENT '参数要求',
  `InitialQty` decimal(18,4) DEFAULT NULL COMMENT '（期初）数量',
  `InitialPrice` decimal(18,2) DEFAULT NULL COMMENT '（期初）单价',
  `InitialSubTotal` decimal(18,2) DEFAULT NULL COMMENT '（期初）金额',
  `InQty` decimal(18,4) DEFAULT NULL COMMENT '（入库）数量',
  `InPrice` decimal(18,2) DEFAULT NULL COMMENT '（入库）单价',
  `InSubTotal` decimal(18,2) DEFAULT NULL COMMENT '（入库）金额',
  `OutQty` decimal(18,4) DEFAULT NULL COMMENT '（出库）数量',
  `OutPrice` decimal(18,2) DEFAULT NULL COMMENT '（出库）单价',
  `OutSubTotal` decimal(18,2) DEFAULT NULL COMMENT '（出库）金额',
  `FinalQty` decimal(18,4) DEFAULT NULL COMMENT '（期末）数量',
  `FinalPrice` decimal(18,2) DEFAULT NULL COMMENT '（期末）单价',
  `FinalSubTotal` decimal(18,2) DEFAULT NULL COMMENT '（期末）金额',
  `SellMaterialName` varchar(100) DEFAULT NULL COMMENT '销售货物名称',
  `InTax` decimal(18,2) DEFAULT NULL COMMENT '进项税',
  `PriceTaxTotal` decimal(18,2) DEFAULT NULL COMMENT '价税合计',
  `InvoiceAmount` decimal(18,2) DEFAULT NULL COMMENT '开票金额',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='购销存管理';

/*Table structure for table `tb_proj_pssmanagelog` */

DROP TABLE IF EXISTS `tb_proj_pssmanagelog`;

CREATE TABLE `tb_proj_pssmanagelog` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AccTime` datetime DEFAULT NULL COMMENT '统计年月',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='购销存管理结转日志';

/*Table structure for table `tb_proj_rebidcompany` */

DROP TABLE IF EXISTS `tb_proj_rebidcompany`;

CREATE TABLE `tb_proj_rebidcompany` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BidCompanyName` varchar(100) DEFAULT NULL COMMENT '投标单位',
  `SortOrder` int DEFAULT NULL COMMENT '排序',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='投标公司';

/*Table structure for table `tb_proj_reqinvoice` */

DROP TABLE IF EXISTS `tb_proj_reqinvoice`;

CREATE TABLE `tb_proj_reqinvoice` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `InvoiceCompanyId` char(36) DEFAULT NULL COMMENT '开票单位ID',
  `InvoiceTime` datetime DEFAULT NULL COMMENT '开票日期',
  `PlanReturnTime` datetime DEFAULT NULL COMMENT '预计收款日期',
  `InvoiceAmount` decimal(18,2) DEFAULT NULL COMMENT '开票金额（小写）',
  `InvoiceAmountCHN` varchar(50) DEFAULT NULL COMMENT '开票金额（大写）',
  `InvoiceLeft` decimal(18,2) DEFAULT NULL COMMENT '未开金额',
  `InvoicePercent` varchar(32) DEFAULT NULL COMMENT '开票比例',
  `InvoiceRemark` varchar(128) DEFAULT NULL COMMENT '备注',
  `Attach` varchar(1024) DEFAULT NULL COMMENT '发票附件',
  `ReqCode` varchar(100) DEFAULT NULL COMMENT '申请单编号',
  `InnerStatus` int DEFAULT NULL COMMENT '内部状态 0-审批前  1-审批通过',
  `OutStockId` char(36) DEFAULT NULL COMMENT '出库ID',
  `NeedOutStock` tinyint(1) DEFAULT NULL COMMENT '是否需要自动生成出库单',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CreateStaffId` char(36) DEFAULT NULL COMMENT '创建人ID',
  `UpdateStaffId` char(36) DEFAULT NULL COMMENT '修改人ID',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '经办人ID',
  `InnerStaffName` varchar(32) DEFAULT NULL COMMENT '经办人ID',
  `IsCollect` tinyint DEFAULT NULL COMMENT '是否已收款',
  `CollectTime` datetime DEFAULT NULL COMMENT '收款时间',
  `InnerApproveTime` datetime DEFAULT NULL COMMENT '审核通过时间溶于',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='开票申请';

/*Table structure for table `tb_proj_reqinvoiceitem` */

DROP TABLE IF EXISTS `tb_proj_reqinvoiceitem`;

CREATE TABLE `tb_proj_reqinvoiceitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `ReqInvoiceId` char(36) DEFAULT NULL COMMENT '开票申请ID',
  `SellContractItemId` char(36) DEFAULT NULL COMMENT '销售合同明细ID',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `MaterialPrice` decimal(18,2) DEFAULT NULL COMMENT '单价',
  `SubTotal` decimal(18,2) DEFAULT NULL COMMENT '小计',
  `OutStockQty` decimal(18,4) DEFAULT NULL COMMENT '已出库数量（当前单据的当前商品）',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='开票申请明细';

/*Table structure for table `tb_proj_sellcontract` */

DROP TABLE IF EXISTS `tb_proj_sellcontract`;

CREATE TABLE `tb_proj_sellcontract` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `ContractType` int DEFAULT NULL COMMENT '合同类型  1-主合同 2-子合同',
  `CustomerName` varchar(50) DEFAULT NULL COMMENT '甲方名称',
  `ContractName` varchar(50) DEFAULT NULL COMMENT '甲方合同名称',
  `ContractCode` varchar(50) DEFAULT NULL COMMENT '甲方合同编号',
  `ReBidCompanyId` char(36) DEFAULT NULL COMMENT '乙方公司ID/投标公司ID',
  `SecondName` varchar(50) DEFAULT NULL COMMENT '乙方名称',
  `SecondCode` varchar(50) DEFAULT NULL COMMENT '乙方合同编号',
  `ThirdName` varchar(50) DEFAULT NULL COMMENT '丙方名称',
  `ThirdCode` varchar(50) DEFAULT NULL COMMENT '丙方合同编号',
  `ContractAmount` decimal(18,2) DEFAULT NULL COMMENT '合同金额',
  `PayCondition` varchar(128) DEFAULT NULL COMMENT '合同付款条件',
  `UnInvoiceAmount` decimal(18,2) DEFAULT NULL COMMENT '未开金额',
  `QualityAmount` decimal(18,2) DEFAULT NULL COMMENT '质保金额',
  `QualityPercent` varchar(32) DEFAULT NULL COMMENT '质保比例',
  `QualityStartTime` datetime DEFAULT NULL COMMENT '质保开始日期',
  `QualityEndTime` datetime DEFAULT NULL COMMENT '质保结束日期',
  `EnsureAmount` decimal(18,2) DEFAULT NULL COMMENT '履约保证金',
  `ProjectAddress` varchar(200) DEFAULT NULL COMMENT '项目地址',
  `PlanPayNode` varchar(200) DEFAULT NULL COMMENT '预估付款节点',
  `Attach` varchar(512) DEFAULT NULL COMMENT '附件',
  `OriginAttach` varchar(512) DEFAULT NULL COMMENT '原始附件',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CreateStaffId` char(36) DEFAULT NULL COMMENT '创建人ID',
  `UpdateStaffId` char(36) DEFAULT NULL COMMENT '修改人ID',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='销售合同/甲方合同';

/*Table structure for table `tb_proj_sellcontractitem` */

DROP TABLE IF EXISTS `tb_proj_sellcontractitem`;

CREATE TABLE `tb_proj_sellcontractitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `Seq` varchar(32) DEFAULT NULL COMMENT '序号',
  `InnerSeq` int DEFAULT NULL COMMENT '内部序号',
  `MaterialName` varchar(100) DEFAULT NULL COMMENT '物资名称',
  `MaterialSpec` varchar(2048) DEFAULT NULL COMMENT '规格型号',
  `MaterialUnit` varchar(32) DEFAULT NULL COMMENT '单位',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `MaterialParams` varchar(4096) DEFAULT NULL COMMENT '参数要求',
  `MaterialPrice` decimal(18,2) DEFAULT NULL COMMENT '单价',
  `Amount` decimal(18,2) DEFAULT NULL COMMENT '总金额',
  `ApprovingQty` decimal(18,4) DEFAULT NULL COMMENT '下采单申请中数量',
  `ApprovedQty` decimal(18,4) DEFAULT NULL COMMENT '下采单申请通过数量',
  `BuyQty` decimal(18,4) DEFAULT NULL COMMENT '已采数量（采购会签合同审核通过后）',
  `InvoApprovingQty` decimal(18,4) DEFAULT NULL COMMENT '开票申请数量',
  `InvoApprovedQty` decimal(18,4) DEFAULT NULL COMMENT '已开票数量',
  `RecvSignQty` decimal(18,4) DEFAULT NULL COMMENT '已发货数量',
  `DrawingQty` decimal(18,4) DEFAULT NULL COMMENT '图纸数量',
  `InStockQty` decimal(18,4) DEFAULT NULL COMMENT '已入库数量',
  `OutStockQty` decimal(18,4) DEFAULT NULL COMMENT '已出库数量',
  `IsOrgin` tinyint(1) DEFAULT NULL COMMENT '是否原始（来自上传的原始清单）',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='销售合同明细';

/*Table structure for table `tb_proj_sellcontractitemattach` */

DROP TABLE IF EXISTS `tb_proj_sellcontractitemattach`;

CREATE TABLE `tb_proj_sellcontractitemattach` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `AttachWzhtqd` varchar(1024) DEFAULT NULL COMMENT '附件物资合同清单',
  `IsWzhtqdMapping` bit(1) DEFAULT NULL COMMENT '物资合同清单是否已字段映射',
  `ItemsJson` text COMMENT '销售合同明细json',
  `FieldMappingJson` varchar(1024) DEFAULT NULL COMMENT '字段映射关系Json',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='销售合同清单附件';

/*Table structure for table `tb_proj_sellcontractitemsite` */

DROP TABLE IF EXISTS `tb_proj_sellcontractitemsite`;

CREATE TABLE `tb_proj_sellcontractitemsite` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `SellContractItemId` char(36) DEFAULT NULL COMMENT '销售合同明细ID',
  `SiteId` char(36) DEFAULT NULL COMMENT '站点ID',
  `MaterialQty` decimal(18,4) DEFAULT NULL COMMENT '数量',
  `ApprovingQty` decimal(18,4) DEFAULT NULL COMMENT '下采单申请中数量',
  `ApprovedQty` decimal(18,4) DEFAULT NULL COMMENT '下采单申请通过数量',
  `BuyQty` decimal(18,4) DEFAULT NULL COMMENT '已采数量（采购会签合同审核通过后）',
  `RecvSignQty` decimal(18,4) DEFAULT NULL COMMENT '已发货数量',
  `DrawingQty` decimal(18,4) DEFAULT NULL COMMENT '图纸数量',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='销售合同明细站点';

/*Table structure for table `tb_proj_sellcontractitemtmp` */

DROP TABLE IF EXISTS `tb_proj_sellcontractitemtmp`;

CREATE TABLE `tb_proj_sellcontractitemtmp` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ItemsJson` text COMMENT '销售合同明细json',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='销售合同明细临时表';

/*Table structure for table `tb_proj_sellcontracttemplate` */

DROP TABLE IF EXISTS `tb_proj_sellcontracttemplate`;

CREATE TABLE `tb_proj_sellcontracttemplate` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `CustomerName` varchar(56) DEFAULT NULL COMMENT '客户名称',
  `TemplateName` varchar(128) DEFAULT NULL COMMENT '模板名称',
  `TemplateAttach` varchar(2048) DEFAULT NULL COMMENT '模板附件（多个附件逗号分隔）',
  `TemplateVersion` varchar(16) DEFAULT NULL COMMENT '模板版本',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `StaffName` varchar(32) DEFAULT NULL COMMENT '创建人姓名',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='合同模板';

/*Table structure for table `tb_proj_sellinvoice` */

DROP TABLE IF EXISTS `tb_proj_sellinvoice`;

CREATE TABLE `tb_proj_sellinvoice` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `InvoiceTime` datetime DEFAULT NULL COMMENT '开票日期',
  `InvoiceAmount` decimal(18,2) DEFAULT NULL COMMENT '开票金额',
  `InvoiceLeft` decimal(18,2) DEFAULT NULL COMMENT '未开金额',
  `InvoicePercent` varchar(32) DEFAULT NULL COMMENT '开票比例',
  `InvoiceRemark` varchar(128) DEFAULT NULL COMMENT '备注',
  `Attach` varchar(1024) DEFAULT NULL COMMENT '发票附件',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='销售开票';

/*Table structure for table `tb_proj_sellinvoicereturn` */

DROP TABLE IF EXISTS `tb_proj_sellinvoicereturn`;

CREATE TABLE `tb_proj_sellinvoicereturn` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `SellContractId` char(36) DEFAULT NULL COMMENT '销售合同ID',
  `ReqInvoiceId` char(36) DEFAULT NULL COMMENT '销售开票ID',
  `ReturnType` int DEFAULT NULL COMMENT '回款方式',
  `ReturnTotal` decimal(18,2) DEFAULT NULL COMMENT '款项',
  `ReturnTime` datetime DEFAULT NULL COMMENT '回款日期',
  `ReturnAmount` decimal(18,2) DEFAULT NULL COMMENT '回款收款金额',
  `ReturnLeft` decimal(18,2) DEFAULT NULL COMMENT '未收金额',
  `Attach` varchar(1024) DEFAULT NULL COMMENT '附件',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='销售回款';

/*Table structure for table `tb_proj_site` */

DROP TABLE IF EXISTS `tb_proj_site`;

CREATE TABLE `tb_proj_site` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `Name` varchar(50) DEFAULT NULL COMMENT '名称',
  `Address` varchar(200) DEFAULT NULL COMMENT '地点',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目站点';

/*Table structure for table `tb_property_applynote` */

DROP TABLE IF EXISTS `tb_property_applynote`;

CREATE TABLE `tb_property_applynote` (
  `Id` char(36) NOT NULL COMMENT '申请id',
  `PropertyId` char(36) DEFAULT NULL COMMENT '关联物品的id',
  `UserId` varchar(36) DEFAULT NULL COMMENT '申请人Id',
  `ApplyDepartment` varchar(36) DEFAULT NULL COMMENT '申请部门',
  `ApplyName` varchar(32) DEFAULT NULL COMMENT '申请人名称',
  `ApplyPhone` varchar(16) DEFAULT NULL COMMENT '申请人手机号码',
  `ApplyAmount` int DEFAULT NULL COMMENT '申请数量',
  `ApplyReason` varchar(255) DEFAULT NULL COMMENT '申请用途',
  `ApplyStatus` int DEFAULT NULL COMMENT '0.表示申请中 1.表示通过 2.表示失败 3-已取消 4-已归还',
  `GoodsLabel` varchar(64) DEFAULT NULL COMMENT '资产标签',
  `ApplyResult` varchar(255) DEFAULT NULL COMMENT '审核结果说明  如果是审核通过则为空，如果是审核失败则是失败原因',
  `AuthUserId` varchar(36) DEFAULT NULL COMMENT '审核人Id',
  `ApplyDate` datetime DEFAULT NULL COMMENT '申请时间',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='资产申请记录';

/*Table structure for table `tb_property_category` */

DROP TABLE IF EXISTS `tb_property_category`;

CREATE TABLE `tb_property_category` (
  `CategoryId` char(36) NOT NULL COMMENT '类别id',
  `ParentId` char(36) DEFAULT NULL COMMENT '父类别id',
  `CategoryName` varchar(32) DEFAULT NULL COMMENT '类别名称',
  `ParentName` varchar(32) DEFAULT NULL COMMENT '父类名称',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`CategoryId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='资产类别';

/*Table structure for table `tb_property_flownote` */

DROP TABLE IF EXISTS `tb_property_flownote`;

CREATE TABLE `tb_property_flownote` (
  `Id` char(36) NOT NULL,
  `PropertyId` char(36) DEFAULT NULL COMMENT '物品id',
  `GoodsLabel` varchar(64) NOT NULL COMMENT '商品标签',
  `UserId` varchar(36) DEFAULT NULL COMMENT '使用者Id',
  `UserName` varchar(16) DEFAULT NULL COMMENT '使用者名称',
  `UserPhone` varchar(16) DEFAULT NULL COMMENT '使用者电话',
  `UseDate` datetime DEFAULT NULL COMMENT '使用时间',
  `UseStatus` int DEFAULT NULL COMMENT '资产使用状态，0-未使用，1-使用中，2-已归还',
  `BackDate` datetime DEFAULT NULL COMMENT '归还时间',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='流转记录';

/*Table structure for table `tb_property_info` */

DROP TABLE IF EXISTS `tb_property_info`;

CREATE TABLE `tb_property_info` (
  `Id` char(36) NOT NULL,
  `PropertyName` varchar(32) DEFAULT NULL COMMENT '物资名称',
  `PropertyPic` varchar(1024) DEFAULT NULL COMMENT '物资图片',
  `CategoryName` varchar(32) DEFAULT NULL COMMENT '物资所属类别',
  `CategoryId` char(36) DEFAULT NULL COMMENT '物资所属类别id',
  `PropertyBuyDate` date DEFAULT NULL COMMENT '物资购买时间',
  `InventoryNum` int DEFAULT NULL COMMENT '库存数量',
  `AllocationDate` date DEFAULT NULL COMMENT '分配时间',
  `NeedReturn` int DEFAULT '1' COMMENT '是否需要归还，0-不需要，1-需要',
  `BackDate` date DEFAULT NULL COMMENT '归还时间',
  `UserName` varchar(16) DEFAULT NULL COMMENT '使用者名称',
  `UserPhone` varchar(16) DEFAULT NULL COMMENT '使用者电话',
  `PreUserName` varchar(16) DEFAULT NULL COMMENT '最近一次使用者名称',
  `PreUserPhone` varchar(16) DEFAULT NULL COMMENT '最近一次使用者电话',
  `PropertyDetail` varchar(255) DEFAULT NULL COMMENT '物资详情介绍',
  `InStorageOperator` varchar(16) DEFAULT NULL COMMENT '入库操作人',
  `InStorageDate` date DEFAULT NULL COMMENT '入库时间',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='资产详情';

/*Table structure for table `tb_property_materiallabel` */

DROP TABLE IF EXISTS `tb_property_materiallabel`;

CREATE TABLE `tb_property_materiallabel` (
  `Id` varchar(36) NOT NULL,
  `MaterialId` varchar(36) NOT NULL COMMENT '资产Id',
  `GoodsLabel` varchar(64) DEFAULT NULL COMMENT '商品标签',
  `IsValid` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效',
  `CreateTime` datetime NOT NULL COMMENT '创建时间',
  `Creater` varchar(36) DEFAULT NULL COMMENT '创建人',
  `UpdateTime` datetime DEFAULT NULL COMMENT '更新时间',
  `Modifier` varchar(36) DEFAULT NULL COMMENT '修改人',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='资产标签表';

/*Table structure for table `tb_purchase_applynote` */

DROP TABLE IF EXISTS `tb_purchase_applynote`;

CREATE TABLE `tb_purchase_applynote` (
  `Id` char(36) NOT NULL,
  `CategoryId` varchar(36) DEFAULT NULL COMMENT '类型Id',
  `ApplyUserId` varchar(36) DEFAULT NULL COMMENT '申请人Id',
  `ApplyName` varchar(16) DEFAULT NULL COMMENT '申请人姓名',
  `DepartmentId` varchar(36) DEFAULT NULL COMMENT '申请人部门Id',
  `DepartmentName` varchar(36) DEFAULT NULL COMMENT '申请人部门名称',
  `ApplyPhone` varchar(16) DEFAULT NULL COMMENT '申请人电话',
  `ApplyExplain` varchar(255) DEFAULT NULL COMMENT '申请物资说明',
  `ApplyReason` varchar(255) DEFAULT NULL COMMENT '申请用途',
  `ApplyAmount` int DEFAULT NULL COMMENT '申请数量',
  `ApplyDate` datetime DEFAULT NULL COMMENT '申请时间',
  `ApplyStatus` int DEFAULT NULL COMMENT '采购状态，0-申请中，1-审核通过，2-审核失败，3-已取消，4-待支付，5-待发货，6-已发货，7-已完成',
  `AuthUserId` varchar(36) DEFAULT NULL COMMENT '审核人Id',
  `ApplyResult` varchar(255) DEFAULT NULL COMMENT '当审核失败后 填写的审核失败原因',
  `SupplierId` varchar(36) DEFAULT NULL COMMENT '供应商Id',
  `LogisticsInfo` varchar(255) DEFAULT NULL COMMENT '物流信息',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='采购申请信息\n';

/*Table structure for table `tb_supplier_categoryenum` */

DROP TABLE IF EXISTS `tb_supplier_categoryenum`;

CREATE TABLE `tb_supplier_categoryenum` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(32) DEFAULT NULL,
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_supplier_info` */

DROP TABLE IF EXISTS `tb_supplier_info`;

CREATE TABLE `tb_supplier_info` (
  `Id` char(36) NOT NULL,
  `SupplierCategoryId` char(36) DEFAULT NULL,
  `SupplierName` varchar(32) DEFAULT NULL COMMENT '供应商名称',
  `SupplierContact` varchar(32) DEFAULT NULL COMMENT '供应商联系人',
  `SupplierPhone` varchar(32) DEFAULT NULL COMMENT '供应商联系电话',
  `SupplierAddDate` date DEFAULT NULL COMMENT '添加时间',
  `SignDate` date DEFAULT NULL COMMENT '签约时间',
  `CancelDate` date DEFAULT NULL COMMENT '解约时间',
  `SignStatus` int DEFAULT NULL COMMENT '签约状态，0-未签约，1-已签约',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='供应商信息\r\n';

/*Table structure for table `tb_supplier_suppliercategory` */

DROP TABLE IF EXISTS `tb_supplier_suppliercategory`;

CREATE TABLE `tb_supplier_suppliercategory` (
  `Id` varchar(36) NOT NULL COMMENT '主键',
  `SupplierId` varchar(36) NOT NULL COMMENT '供应商Id',
  `CategoryId` varchar(36) NOT NULL COMMENT '资产类别Id',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_user_baseinfo` */

DROP TABLE IF EXISTS `tb_user_baseinfo`;

CREATE TABLE `tb_user_baseinfo` (
  `Id` char(36) NOT NULL,
  `UserName` varchar(32) DEFAULT NULL COMMENT '用户名称',
  `UserLevel` int DEFAULT NULL COMMENT '9:超级管理员 1.普通员工 2.车辆管理员 3.房屋管理员 4.资产管理员 5.采购管理员',
  `UserPhone` varchar(16) DEFAULT NULL COMMENT '用户电话',
  `UserIdCard` varchar(32) DEFAULT NULL COMMENT '用户身份证号',
  `UserAddress` varchar(128) DEFAULT NULL COMMENT '家庭住址',
  `UserNation` varchar(128) DEFAULT NULL COMMENT '祖籍地址',
  `UserJoinDate` date DEFAULT NULL COMMENT '用户加入公司时间',
  `IsVaild` tinyint(1) DEFAULT NULL,
  `Creater` varchar(16) DEFAULT NULL,
  `CreatTime` datetime DEFAULT NULL,
  `Modifier` varchar(16) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Table structure for table `tb_work_attendaccrecord` */

DROP TABLE IF EXISTS `tb_work_attendaccrecord`;

CREATE TABLE `tb_work_attendaccrecord` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AttYear` int DEFAULT NULL COMMENT '年',
  `AttMonth` int DEFAULT NULL COMMENT '月',
  `AttStaffId` char(36) DEFAULT NULL COMMENT '员工ID',
  `Seq` int DEFAULT NULL COMMENT '序号',
  `HasAttendGroup` tinyint(1) DEFAULT NULL COMMENT '是否已绑定考勤组',
  `AttStaffName` varchar(32) DEFAULT NULL COMMENT '员工姓名',
  `AttStaffCode` varchar(32) DEFAULT NULL COMMENT '员工编号',
  `AttStaffIDCard` varchar(32) DEFAULT NULL COMMENT '员工身份证号',
  `AttMobile` varchar(32) DEFAULT NULL COMMENT '联系电话',
  `AttStaffStartDate` datetime DEFAULT NULL COMMENT '员工入职日期',
  `AttStaffEndDate` datetime DEFAULT NULL COMMENT '员工离职日期',
  `AttDeptId` char(36) DEFAULT NULL COMMENT '部门ID',
  `AttDeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `AttCompanyId` char(36) DEFAULT NULL COMMENT '公司ID',
  `AttCompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称',
  `AttSocialCompanyId` char(36) DEFAULT NULL COMMENT '社保公司ID',
  `AttSocialCompanyName` varchar(32) DEFAULT NULL COMMENT '社保公司名称',
  `AttJobTitleId` char(36) DEFAULT NULL COMMENT '岗位ID',
  `AttJobTitleName` varchar(32) DEFAULT NULL COMMENT '岗位名称',
  `RealWorkDays` decimal(11,1) DEFAULT NULL COMMENT '实际出勤',
  `ThisMonthWorkDays` decimal(11,1) DEFAULT NULL COMMENT '当月应出勤天数',
  `BusiTripDays` decimal(11,1) DEFAULT NULL COMMENT '公差',
  `AreaHelpAmount` decimal(11,1) DEFAULT NULL COMMENT '地区补助合计',
  `AfterSellDays` decimal(11,1) DEFAULT NULL COMMENT '售后维保出勤天数合计',
  `ProjWorkDays` decimal(11,1) DEFAULT NULL COMMENT '项目出勤天数',
  `NormalExtraHours` decimal(11,1) DEFAULT NULL COMMENT '（加班）工作日',
  `WeekendExtraHours` decimal(11,1) DEFAULT NULL COMMENT '（加班）周末',
  `FestivalExtraHours` decimal(11,1) DEFAULT NULL COMMENT '（加班）节假日',
  `LegalRestDays` decimal(11,1) DEFAULT NULL COMMENT '法定休息日(国假+周末)',
  `SkipWorkDays` decimal(11,1) DEFAULT NULL COMMENT '旷工',
  `HurtWorkDays` decimal(11,1) DEFAULT NULL COMMENT '工伤',
  `ForgotAttCount` int DEFAULT NULL COMMENT '（打卡）忘记打卡次数',
  `AttIn5Count` int DEFAULT NULL COMMENT '（打卡）迟到/早退<=5分钟次数',
  `AttIn30Count` int DEFAULT NULL COMMENT '（打卡）迟到/早退>5分钟次数，<=30分钟次数',
  `AttOver30Count` int DEFAULT NULL COMMENT '（打卡）迟到/早退>30分钟次数',
  `AttOver30Count2` int DEFAULT NULL COMMENT '（打卡）迟到/早退>30分钟，<=1h次数',
  `TimePeriodJson` text COMMENT '时间段json数据',
  `CanCalculate` tinyint(1) DEFAULT NULL COMMENT '是否参与自动计算',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark2` varchar(128) DEFAULT NULL COMMENT '备注2',
  `Remark3` varchar(128) DEFAULT NULL COMMENT '地区补助合计',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='考勤统计（需要每隔一段时间计算）';

/*Table structure for table `tb_work_attendaccrecorditem` */

DROP TABLE IF EXISTS `tb_work_attendaccrecorditem`;

CREATE TABLE `tb_work_attendaccrecorditem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AttendAccRecordId` char(36) DEFAULT NULL COMMENT '考勤统计主表ID',
  `LeaveTypeId` char(36) DEFAULT NULL COMMENT '请假类型ID',
  `TotalValue` decimal(11,1) DEFAULT NULL COMMENT '统计数量',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='考勤统计(请假类型子表)';

/*Table structure for table `tb_work_attendfestival` */

DROP TABLE IF EXISTS `tb_work_attendfestival`;

CREATE TABLE `tb_work_attendfestival` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AttYear` datetime DEFAULT NULL COMMENT '年度',
  `FestivalName` varchar(32) DEFAULT NULL COMMENT '假期名称',
  `StartTime` datetime DEFAULT NULL COMMENT '开始日期（含前）',
  `EndTime` datetime DEFAULT NULL COMMENT '结束日期（含后）',
  `FestivalType` int DEFAULT NULL COMMENT '假期类型（暂时未定义）',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='考勤国假';

/*Table structure for table `TB_Work_AttendFixRecord` */

DROP TABLE IF EXISTS `TB_Work_AttendFixRecord`;

CREATE TABLE `TB_Work_AttendFixRecord` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AttStaffId` char(36) DEFAULT NULL COMMENT '员工ID',
  `AttType` int DEFAULT NULL COMMENT '考勤类型 1-上班 2-下班',
  `AttDate` datetime DEFAULT NULL COMMENT '考勤日期',
  `CcIds` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CcRemark` varchar(128) DEFAULT NULL COMMENT '抄送人备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='补卡申请表';

/*Table structure for table `TB_Work_AttendGroup` */

DROP TABLE IF EXISTS `TB_Work_AttendGroup`;

CREATE TABLE `TB_Work_AttendGroup` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(32) DEFAULT NULL COMMENT '考勤组名称',
  `StaffIds` text COMMENT '员工ID组（英文逗号分隔）',
  `StaffNames` text COMMENT '员工组（英文逗号分隔）',
  `StaffCount` int DEFAULT NULL COMMENT '员工数量',
  `HitAddress` tinyint(1) DEFAULT NULL COMMENT '考勤方式(地点打卡)',
  `HitWiFi` tinyint(1) DEFAULT NULL COMMENT '考勤方式(WiFi打卡)',
  `HitFace` tinyint(1) DEFAULT NULL COMMENT '考勤方式(人脸打卡)',
  `Day1Period` varchar(32) DEFAULT NULL COMMENT '周一班次时间段',
  `Day1Flag` tinyint(1) DEFAULT NULL COMMENT '周一启用',
  `Day2Period` varchar(32) DEFAULT NULL COMMENT '周二班次时间段',
  `Day2Flag` tinyint(1) DEFAULT NULL COMMENT '周二启用',
  `Day3Period` varchar(32) DEFAULT NULL COMMENT '周三班次时间段',
  `Day3Flag` tinyint(1) DEFAULT NULL COMMENT '周三启用',
  `Day4Period` varchar(32) DEFAULT NULL COMMENT '周四班次时间段',
  `Day4Flag` tinyint(1) DEFAULT NULL COMMENT '周四启用',
  `Day5Period` varchar(32) DEFAULT NULL COMMENT '周五班次时间段',
  `Day5Flag` tinyint(1) DEFAULT NULL COMMENT '周五启用',
  `Day6Period` varchar(32) DEFAULT NULL COMMENT '周六班次时间段',
  `Day6Flag` tinyint(1) DEFAULT NULL COMMENT '周六启用',
  `Day7Period` varchar(32) DEFAULT NULL COMMENT '周日班次时间段',
  `Day7Flag` tinyint(1) DEFAULT NULL COMMENT '周日启用',
  `DayFestFlag` tinyint(1) DEFAULT NULL COMMENT '法定节假日自动排休',
  `DayRestFlag` tinyint(1) DEFAULT NULL COMMENT '休息日打卡需审批',
  `ExWorkFlag` tinyint(1) DEFAULT NULL COMMENT '（工作日）是否允许加班',
  `ExWorkAllowType` int DEFAULT NULL COMMENT '（工作日）允许加班类型 1-允许班前班后 2-仅班前 3-仅班后',
  `ExWorkCalcWay` int DEFAULT NULL COMMENT '（工作日）加班计算方式',
  `ExWorkStartTime` int DEFAULT NULL COMMENT '（工作日）加班起算时间（分钟）',
  `ExWorkOnMinTime` int DEFAULT NULL COMMENT '（工作日）班前加班最小时间（分钟）',
  `ExWorkOffMinTime` int DEFAULT NULL COMMENT '（工作日）班后加班最小时间（分钟）',
  `ExWorkSumMinTime` int DEFAULT NULL COMMENT '（工作日）累计加班最小时间（分钟）',
  `ExWorkMinusRest` tinyint(1) DEFAULT NULL COMMENT '（工作日）是否扣除休息时间',
  `ExWorkBonus` tinyint(1) DEFAULT NULL COMMENT '（工作日）加班时长记为调休或加班费',
  `ExWorkBonusType` int DEFAULT NULL COMMENT '（工作日）1-记为调休 2-记为加班费',
  `ExWorkBonusTypeA` varchar(32) DEFAULT NULL COMMENT '（工作日）按照x:x记为调休时长',
  `ExRestFlag` tinyint(1) DEFAULT NULL COMMENT '（休息日）是否允许加班',
  `ExRestCalcWay` int DEFAULT NULL COMMENT '（休息日）加班计算方式',
  `ExRestSumMinTime` int DEFAULT NULL COMMENT '（休息日）累计加班最小时间（分钟）',
  `ExRestMinusRest` tinyint(1) DEFAULT NULL COMMENT '（休息日）是否扣除休息时间',
  `ExRestStartTime` varchar(32) DEFAULT NULL COMMENT '（休息日）开始',
  `ExRestEndTime` varchar(32) DEFAULT NULL COMMENT '（休息日）结束',
  `ExRestBonus` tinyint(1) DEFAULT NULL COMMENT '（休息日）加班时长记为调休或加班费',
  `ExRestBonusType` int DEFAULT NULL COMMENT '（休息日）1-记为调休 2-记为加班费',
  `ExRestBonusTypeA` varchar(32) DEFAULT NULL COMMENT '（休息日）按照x:x记为调休时长',
  `ExFestFlag` tinyint(1) DEFAULT NULL COMMENT '（节假日）是否允许加班',
  `ExFestCalcWay` int DEFAULT NULL COMMENT '（节假日）加班计算方式',
  `ExFestSumMinTime` int DEFAULT NULL COMMENT '（节假日）累计加班最小时间（分钟）',
  `ExFestMinusRest` tinyint(1) DEFAULT NULL COMMENT '（节假日）是否扣除休息时间',
  `ExFestStartTime` varchar(32) DEFAULT NULL COMMENT '（节假日）开始',
  `ExFestEndTime` varchar(32) DEFAULT NULL COMMENT '（节假日）结束',
  `ExFestBonus` tinyint(1) DEFAULT NULL COMMENT '（节假日）加班时长记为调休或加班费',
  `ExFestBonusType` int DEFAULT NULL COMMENT '（节假日）1-记为调休 2-记为加班费',
  `ExFestBonusTypeA` varchar(32) DEFAULT NULL COMMENT '（节假日）按照x:x记为调休时长',
  `OutFlag` tinyint(1) DEFAULT NULL COMMENT '是否允许外勤打卡',
  `OutAuditFlag` tinyint(1) DEFAULT NULL COMMENT '外勤打卡是否需要审批',
  `OutAuditWay` int DEFAULT NULL COMMENT '外勤打卡需要审批类型 1-先审批后打卡 2-先打卡后审批',
  `OutCommentFlag` tinyint(1) DEFAULT NULL COMMENT '外勤打卡需要填写备注',
  `OutPhotoFlag` tinyint(1) DEFAULT NULL COMMENT '外勤打卡需要拍照',
  `OutAddrFlag` tinyint(1) DEFAULT NULL COMMENT '外勤打卡需要详细地址',
  `RestStartTime` varchar(32) DEFAULT NULL COMMENT '休息日打卡开始时间',
  `RestWay` int DEFAULT NULL COMMENT '休息日打卡方式 1-标准打卡模式 2-严格打卡模式',
  `RestOnInterval` int DEFAULT NULL COMMENT '上班打卡间隔（分钟）上班打卡xx分钟后可下班打卡',
  `RestOffInterval` int DEFAULT NULL COMMENT '下班打卡间隔（分钟）下班打卡xx分钟后可上班打卡',
  `RestAuditFlag` tinyint(1) DEFAULT NULL COMMENT '休息日打卡需审批',
  `FixCount` int DEFAULT NULL COMMENT '补卡次数',
  `FixTime` int DEFAULT NULL COMMENT '补卡时间(天)',
  `FixType` varchar(50) DEFAULT NULL COMMENT '补卡类型',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='考勤组';

/*Table structure for table `tb_work_attendgrouphitaddr` */

DROP TABLE IF EXISTS `tb_work_attendgrouphitaddr`;

CREATE TABLE `tb_work_attendgrouphitaddr` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AttendGroupId` char(36) DEFAULT NULL COMMENT '考勤组ID',
  `Name` varchar(100) DEFAULT NULL COMMENT '名称',
  `Address` varchar(100) DEFAULT NULL COMMENT '详细地址',
  `Longitude` decimal(11,6) DEFAULT NULL COMMENT '经度',
  `Latitude` decimal(11,6) DEFAULT NULL COMMENT '纬度',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='考勤方式（地点）';

/*Table structure for table `tb_work_attendgrouphitwifi` */

DROP TABLE IF EXISTS `tb_work_attendgrouphitwifi`;

CREATE TABLE `tb_work_attendgrouphitwifi` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AttendGroupId` char(36) DEFAULT NULL COMMENT '考勤组ID',
  `Name` varchar(32) DEFAULT NULL COMMENT '名称',
  `Mac` varchar(50) DEFAULT NULL COMMENT 'Mac地址',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='考勤方式（WiFi）';

/*Table structure for table `TB_Work_AttendRecord` */

DROP TABLE IF EXISTS `TB_Work_AttendRecord`;

CREATE TABLE `TB_Work_AttendRecord` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AttStaffId` char(36) DEFAULT NULL COMMENT '员工ID',
  `AttStaffName` varchar(32) DEFAULT NULL COMMENT '员工姓名',
  `AttStaffCode` varchar(32) DEFAULT NULL COMMENT '员工编号',
  `AttMobile` varchar(32) DEFAULT NULL COMMENT '联系电话（预留）',
  `AttDeptId` char(36) DEFAULT NULL COMMENT '部门ID（预留）',
  `AttDeptName` varchar(32) DEFAULT NULL COMMENT '部门名称（预留）',
  `AttCompanyId` char(36) DEFAULT NULL COMMENT '公司ID（预留）',
  `AttCompanyName` varchar(32) DEFAULT NULL COMMENT '公司名称（预留）',
  `AttJobTitleId` char(36) DEFAULT NULL COMMENT '岗位ID（预留）',
  `AttJobTitleName` varchar(32) DEFAULT NULL COMMENT '岗位名称（预留）',
  `AttType` int DEFAULT NULL COMMENT '考勤类型 1-上班 2-下班',
  `AttDate` datetime DEFAULT NULL COMMENT '考勤日期',
  `AttTime` datetime DEFAULT NULL COMMENT '考勤时间',
  `AttAddress` varchar(100) DEFAULT NULL COMMENT '打卡地址',
  `AttIP` varchar(32) DEFAULT NULL COMMENT 'IP地址',
  `AttFrom` varchar(512) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '打卡方式',
  `AttDeviceCode` varchar(100) DEFAULT NULL COMMENT '设备识别码',
  `Longitude` decimal(11,6) DEFAULT NULL COMMENT '经度',
  `Latitude` decimal(11,6) DEFAULT NULL COMMENT '纬度',
  `AttBusiType` int DEFAULT NULL COMMENT '业务类型 1-正常 2-补卡',
  `IsOut` tinyint(1) DEFAULT NULL COMMENT '是否外勤',
  `OutImg` varchar(1024) DEFAULT NULL COMMENT '外勤图片',
  `IsValid` tinyint(1) DEFAULT NULL COMMENT '是否有效 1-有效 0-无效',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='考勤记录';

/*Table structure for table `TB_Work_AttendWorkDay` */

DROP TABLE IF EXISTS `TB_Work_AttendWorkDay`;

CREATE TABLE `TB_Work_AttendWorkDay` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `WorkDayName` varchar(32) DEFAULT NULL COMMENT '名称',
  `WorkDate` datetime DEFAULT NULL COMMENT '日期',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='考勤工作日';

/*Table structure for table `TB_Work_BusiTripApply` */

DROP TABLE IF EXISTS `TB_Work_BusiTripApply`;

CREATE TABLE `TB_Work_BusiTripApply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ApplyType` varchar(32) DEFAULT NULL COMMENT '出差类型',
  `StartTime` datetime DEFAULT NULL COMMENT '起始时间',
  `EndTime` datetime DEFAULT NULL COMMENT '截止时间',
  `PreEndTime` datetime DEFAULT NULL COMMENT '预计截止时间',
  `RealStartTime` datetime DEFAULT NULL COMMENT '实际起始时间',
  `RealEndTime` datetime DEFAULT NULL COMMENT '实际截止时间',
  `JuStartTime` datetime DEFAULT NULL COMMENT '判断',
  `JuEndTime` datetime DEFAULT NULL COMMENT '判断',
  `TotalDays` decimal(10,1) DEFAULT NULL COMMENT '共计天数',
  `TripFrom` varchar(32) DEFAULT NULL COMMENT '出差目的地',
  `TripDest` varchar(32) DEFAULT NULL COMMENT '出差目的地',
  `TripMethod` varchar(32) DEFAULT NULL COMMENT '出差目的地',
  `TripTickets` bit(1) DEFAULT NULL COMMENT '代购往返票 1-需要 0-不需要',
  `CcIds` varchar(512) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `CcIdsFinal` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '申请人（冗余）',
  `InnerApplyStatus` int DEFAULT NULL COMMENT '申请状态（冗余）',
  `ActualEndTime` datetime DEFAULT NULL COMMENT '申请人自己填写的结束时间',
  `EndTimeState` int DEFAULT NULL COMMENT '结束时间确认状态 1-初始 2-申请中 3-申请通过',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `CcRemark` varchar(128) DEFAULT NULL COMMENT '抄送人备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `MODIFIER` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='出差审批';

/*Table structure for table `tb_work_busitripapplydetail` */

DROP TABLE IF EXISTS `tb_work_busitripapplydetail`;

CREATE TABLE `tb_work_busitripapplydetail` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `BusiTripApplyId` char(36) NOT NULL COMMENT '请假表Id',
  `ReviewerId` char(36) NOT NULL COMMENT '审批人Id',
  `ReviewerName` varchar(32) DEFAULT NULL COMMENT '审批人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `IsApproved` bit(1) DEFAULT NULL COMMENT '是否同意',
  `IsReturnBack` bit(1) DEFAULT NULL COMMENT '是否退回',
  `ApproveTime` datetime DEFAULT NULL COMMENT '同意/不同意时间',
  `Comment` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='出差审批明细';

/*Table structure for table `TB_Work_ClockInConfig` */

DROP TABLE IF EXISTS `TB_Work_ClockInConfig`;

CREATE TABLE `TB_Work_ClockInConfig` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) DEFAULT NULL COMMENT '人员ID',
  `StaffName` varchar(32) DEFAULT NULL COMMENT '人员',
  `DeptId` char(36) DEFAULT NULL COMMENT '部门ID',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门',
  `CompanyId` char(36) DEFAULT NULL COMMENT '公司ID',
  `CompanyName` varchar(32) DEFAULT NULL COMMENT '公司',
  `Mobile` varchar(32) DEFAULT NULL COMMENT '手机',
  `AmFlag` tinyint(1) DEFAULT NULL COMMENT '上班打卡提醒',
  `AmMinutes` int DEFAULT NULL COMMENT '上班提前打卡分钟数',
  `PmFlag` tinyint(1) DEFAULT NULL COMMENT '下班打卡提醒',
  `PmMinutes` int DEFAULT NULL COMMENT '下班提前打卡分钟数',
  `JsonStr` varchar(1024) DEFAULT NULL COMMENT '星期一到星期日的上下班提醒时间',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目人员';

/*Table structure for table `TB_Work_ExtraWork` */

DROP TABLE IF EXISTS `TB_Work_ExtraWork`;

CREATE TABLE `TB_Work_ExtraWork` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StartTime` datetime DEFAULT NULL COMMENT '开始时间',
  `EndTime` datetime DEFAULT NULL COMMENT '结束时间',
  `TotalHours` decimal(10,1) DEFAULT NULL COMMENT '共计时长（小时）',
  `Attach` varchar(1000) DEFAULT NULL COMMENT '附件',
  `CcIds` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '申请人（冗余）',
  `InnerApplyStatus` int DEFAULT NULL COMMENT '申请状态（冗余）',
  `Remark` varchar(128) DEFAULT NULL,
  `CcRemark` varchar(128) DEFAULT NULL COMMENT '抄送人备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `MODIFIER` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  `DaysJson` text COMMENT 'json',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='加班审批';

/*Table structure for table `TB_Work_LeaveApply` */

DROP TABLE IF EXISTS `TB_Work_LeaveApply`;

CREATE TABLE `TB_Work_LeaveApply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `LeaveType` char(36) DEFAULT NULL COMMENT '请假类型 1-年假 2-事假 3-病假 4-产假 5-婚假 6-丧假 7-出差',
  `LeaveTypeName` varchar(32) DEFAULT NULL COMMENT '请假类型描述',
  `StartTime` datetime DEFAULT NULL COMMENT '请假起始时间',
  `EndTime` datetime DEFAULT NULL COMMENT '请假截止时间',
  `RealStartTime` datetime DEFAULT NULL COMMENT '实际请假起始时间',
  `RealEndTime` datetime DEFAULT NULL COMMENT '实际请假截止时间',
  `JuStartTime` datetime DEFAULT NULL COMMENT '判断开始时间',
  `JuEndTime` datetime DEFAULT NULL COMMENT '判断结束时间',
  `TotalDays` decimal(10,1) DEFAULT NULL COMMENT '共计天数',
  `Attach` text,
  `CcIds` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `CcIdsFinal` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '申请人（冗余）',
  `InnerApplyStatus` int DEFAULT NULL COMMENT '申请状态（冗余）',
  `DaysJson` text COMMENT '请假天Json',
  `Remark` varchar(128) DEFAULT NULL,
  `CcRemark` varchar(128) DEFAULT NULL COMMENT '抄送人备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `MODIFIER` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='请假审批';

/*Table structure for table `tb_work_leaveapplycond` */

DROP TABLE IF EXISTS `tb_work_leaveapplycond`;

CREATE TABLE `tb_work_leaveapplycond` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Days` int DEFAULT NULL COMMENT '阈值天数',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='请假审批条件';

/*Table structure for table `tb_work_leaveapplydetail` */

DROP TABLE IF EXISTS `tb_work_leaveapplydetail`;

CREATE TABLE `tb_work_leaveapplydetail` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `LeaveApplyId` char(36) NOT NULL COMMENT '请假表Id',
  `ReviewerId` char(36) NOT NULL COMMENT '审批人Id',
  `ReviewerName` varchar(32) DEFAULT NULL COMMENT '审批人姓名',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门名称',
  `IsApproved` bit(1) DEFAULT NULL COMMENT '是否同意',
  `IsReturnBack` bit(1) DEFAULT NULL COMMENT '是否退回',
  `ApproveTime` datetime DEFAULT NULL COMMENT '同意/不同意时间',
  `Comment` varchar(128) DEFAULT NULL COMMENT '备注',
  `Remark` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='请假审批明细';

/*Table structure for table `tb_work_leavetype` */

DROP TABLE IF EXISTS `tb_work_leavetype`;

CREATE TABLE `tb_work_leavetype` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `Name` varchar(32) DEFAULT NULL COMMENT '假期名称',
  `Unit` int DEFAULT NULL COMMENT '请假单位 1-按天请假 2-按半天请假 3-按小时请假',
  `RuleFlag` tinyint(1) DEFAULT NULL COMMENT '是否启用规则',
  `BalWay` int DEFAULT NULL COMMENT '余额发放方式 1-每年自动发放一次 2-每月自动发放一次 3-手动发放',
  `BalTime` int DEFAULT NULL COMMENT '余额发放日期 1-每年员工入职日 2-每年一月一日',
  `BalRule` int DEFAULT NULL COMMENT '余额额度配置规则 1-固定额度 2-按社会工龄 3-按司龄',
  `BalDayQty` int DEFAULT NULL COMMENT '额度',
  `DeadTimeType` int DEFAULT NULL COMMENT '有效期 1-自发放日起一年 2-按入职日期起12个月 3-按自然年1月1日到12月31日',
  `DeadTimeFlag` tinyint(1) DEFAULT NULL COMMENT '允许延长有效期',
  `RetainQty` int DEFAULT NULL COMMENT '保留数量（天、月）',
  `RetainType` int DEFAULT NULL COMMENT '保留类型 1-月 2-天',
  `FitComment` varchar(128) DEFAULT NULL COMMENT '适用范围',
  `SortOrder` int DEFAULT NULL COMMENT '排序号',
  `Calculate` int DEFAULT NULL COMMENT '请假计算方式 1-按自然日计算 2-按工作日计算',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='请假规则（请假类型）';

/*Table structure for table `TB_Work_OutApply` */

DROP TABLE IF EXISTS `TB_Work_OutApply`;

CREATE TABLE `TB_Work_OutApply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StartTime` datetime DEFAULT NULL COMMENT '起始时间',
  `EndTime` datetime DEFAULT NULL COMMENT '截止时间',
  `TotalDays` decimal(10,1) DEFAULT NULL COMMENT '共计天数',
  `TripFrom` varchar(32) DEFAULT NULL COMMENT '出差目的地',
  `TripDest` varchar(32) DEFAULT NULL COMMENT '出差目的地',
  `CcIds` varchar(512) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `CcIdsFinal` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `InnerStaffId` char(36) DEFAULT NULL COMMENT '申请人（冗余）',
  `InnerApplyStatus` int DEFAULT NULL COMMENT '申请状态（冗余）',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='出差审批';

/*Table structure for table `TB_Work_OutAttendApply` */

DROP TABLE IF EXISTS `TB_Work_OutAttendApply`;

CREATE TABLE `TB_Work_OutAttendApply` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AttStaffId` char(36) DEFAULT NULL COMMENT '员工ID',
  `AttStaffName` varchar(32) DEFAULT NULL COMMENT '员工',
  `AttType` int DEFAULT NULL COMMENT '考勤类型 1-上班 2-下班',
  `AttDate` datetime DEFAULT NULL COMMENT '考勤日期',
  `CcIds` varchar(2000) DEFAULT NULL COMMENT '抄送人(由英文点号分隔)',
  `Address` varchar(128) DEFAULT NULL COMMENT '地点',
  `OutImg` varchar(2000) DEFAULT NULL COMMENT '图片',
  `AttendRecordId` char(36) DEFAULT NULL COMMENT '打卡主键ID',
  `InnerApplyStatus` int DEFAULT NULL COMMENT '审核状态',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='外勤打卡申请表';

/*Table structure for table `tb_work_projattend` */

DROP TABLE IF EXISTS `tb_work_projattend`;

CREATE TABLE `tb_work_projattend` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `ProjectId` char(36) DEFAULT NULL COMMENT '项目ID',
  `AttDate` datetime DEFAULT NULL COMMENT '考勤月',
  `Attach` varchar(1024) DEFAULT NULL COMMENT '附件',
  `ProjAttendAttachId` char(36) DEFAULT NULL COMMENT '附件ID',
  `AttachTitle` varchar(100) DEFAULT NULL COMMENT '附件标题',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目出勤';

/*Table structure for table `tb_work_projattendattach` */

DROP TABLE IF EXISTS `tb_work_projattendattach`;

CREATE TABLE `tb_work_projattendattach` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `JsonData` longtext COMMENT 'json',
  `AttachTitle` varchar(100) DEFAULT NULL COMMENT '附件标题',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='项目出勤附件';

/*Table structure for table `tb_work_staffannualleave` */

DROP TABLE IF EXISTS `tb_work_staffannualleave`;

CREATE TABLE `tb_work_staffannualleave` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffId` char(36) NOT NULL COMMENT '人员Id',
  `Year` varchar(4) DEFAULT NULL COMMENT '通知类型',
  `LeftDays` decimal(10,1) DEFAULT NULL COMMENT '标题',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` bit(1) DEFAULT b'0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='人员年假统计';

/*Table structure for table `tb_work_staffleavebalance` */

DROP TABLE IF EXISTS `tb_work_staffleavebalance`;

CREATE TABLE `tb_work_staffleavebalance` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `AttStaffId` char(36) DEFAULT NULL COMMENT '员工ID',
  `AttStaffName` varchar(32) DEFAULT NULL COMMENT '员工姓名',
  `CompanyId` char(36) DEFAULT NULL COMMENT '公司ID（拷贝）',
  `CompanyName` varchar(32) DEFAULT NULL COMMENT '公司（拷贝）',
  `DeptId` char(36) DEFAULT NULL COMMENT '部门ID（拷贝）',
  `DeptName` varchar(32) DEFAULT NULL COMMENT '部门（拷贝）',
  `JobTitleId` char(36) DEFAULT NULL COMMENT '岗位ID（拷贝）',
  `JobTitleName` varchar(32) DEFAULT NULL COMMENT '岗位名称（拷贝）',
  `StartDate` datetime DEFAULT NULL COMMENT '入职时间（拷贝）',
  `StartWorkDate` datetime DEFAULT NULL COMMENT '首次工作时间（暂无）',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='员工假期余额(主表)';

/*Table structure for table `tb_work_staffleavebalanceitem` */

DROP TABLE IF EXISTS `tb_work_staffleavebalanceitem`;

CREATE TABLE `tb_work_staffleavebalanceitem` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffLeaveBalanceId` char(36) DEFAULT NULL COMMENT '员工假期余额ID',
  `AttStaffId` char(36) DEFAULT NULL COMMENT '员工ID(冗余)',
  `LeaveTypeId` char(36) DEFAULT NULL COMMENT '请假类型ID',
  `TotalValue` decimal(11,1) DEFAULT NULL COMMENT '总数',
  `LeftValue` decimal(11,1) DEFAULT NULL COMMENT '剩余',
  `IsLimit` tinyint(1) DEFAULT NULL COMMENT '剩余天数是否有限制',
  `LastGrandTime` datetime DEFAULT NULL COMMENT '上次发放日期',
  `DeadTime` datetime DEFAULT NULL COMMENT '截止日期',
  `RetainValue` decimal(11,1) DEFAULT NULL COMMENT '保留的请假天数',
  `RetainDeadTime` datetime DEFAULT NULL COMMENT '保留的截止日期',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='员工假期余额(子表)';

/*Table structure for table `tb_work_staffleavebalanceitemlog` */

DROP TABLE IF EXISTS `tb_work_staffleavebalanceitemlog`;

CREATE TABLE `tb_work_staffleavebalanceitemlog` (
  `Id` char(36) NOT NULL COMMENT '主键ID',
  `StaffLeaveBalanceItemId` char(36) DEFAULT NULL COMMENT '员工假期余额(子表)ID',
  `DeltaValue` decimal(11,1) DEFAULT NULL COMMENT 'delta值',
  `BusiRemark` varchar(128) DEFAULT NULL COMMENT '业务备注',
  `AvailRemark` varchar(128) DEFAULT NULL COMMENT '有效期备注',
  `Remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `IsDeleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除',
  `Creator` varchar(16) DEFAULT NULL COMMENT '创建人',
  `CreateTime` datetime DEFAULT NULL COMMENT '创建时间',
  `Modifier` varchar(16) DEFAULT NULL COMMENT '修改人',
  `ModifiedTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='员工假期余额日志表';

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
